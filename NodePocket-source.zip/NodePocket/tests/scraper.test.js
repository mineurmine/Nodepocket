// La lecture des pages web résiste-t-elle à des mises en page différentes ? (Playwright)
const { chromium } = require('playwright');
const path = require('path');
const J = f => path.resolve(__dirname, '../app/src/main/assets/js/' + f);
let pass = 0, fail = 0; const out = [];
const ok = (c, n, x) => { if (c) pass++; else { fail++; out.push('ÉCHEC : ' + n + (x !== undefined ? ' -> ' + JSON.stringify(x).slice(0, 500) : '')); } };

const PAGES = {
  // tableau à onglets (comme dmx-tools), IP en 4 cases
  table: `<div class="tab"><button onclick="openTable(event,'g0')">IP Setting</button><button onclick="openTable(event,'g1')">DMX 1 Setting</button><button onclick="openTable(event,'g2')">Device Setting</button><button onclick="openTable(event,'g3')">Infos</button></div>
   <div id="g0"><table><tr><td>DHCP or STATIC :</td><td><select id="ID0"><option>DHCP</option><option selected>STATIC</option></select></td></tr>
   <tr><td>Device IP (static) :</td><td><input id="ID1_IP0" value="2">.<input id="ID1_IP1" value="0">.<input id="ID1_IP2" value="0">.<input id="ID1_IP3" value="11"></td></tr>
   <tr><td>Device IP MASK (static) :</td><td><input id="ID2_IP0" value="255">.<input id="ID2_IP1" value="0">.<input id="ID2_IP2" value="0">.<input id="ID2_IP3" value="0"></td></tr>
   <tr><td>DMX Protocol :</td><td><select id="ID3"><option selected>Art-Net</option><option>sACN</option></select></td></tr></table></div>
   <div id="g1" style="display:none"><table><tr><td>DMX :</td><td><select id="ID4"><option selected>XLR Output</option><option>XLR Input</option></select></td></tr><tr><td>Universe OUT ( 0 to 255):</td><td><input id="ID5" type="number" value="7"></td></tr></table></div>
   <div id="g2" style="display:none"><table><tr><td>Long Device Name :</td><td><input id="ID6" value="Mon node"></td></tr><tr><td>Short Device Name :</td><td><input id="ID7" value="NODE7"></td></tr><tr><td>Fps Fixed DMX OUT ( 16 to 44):</td><td><input id="ID8" value="30"></td></tr></table></div>
   <div id="g3" style="display:none"><table><tr><td>Firmware Version :</td><td><input id="ID9" readonly value="Oct 10 2024"></td></tr><tr><td>Serial number :</td><td><input id="ID10" readonly value="EC1"></td></tr></table></div>
   <button id="apply">Apply</button> <a href="#">Save Parameters</a>`,
  // libellés <label for>, sections avec titres, IP en une case, cases radio
  labels: `<section><h2>Réseau</h2><p><input type="radio" name="m" id="r1" value="dhcp"><label for="r1">DHCP</label> <input type="radio" name="m" id="r2" value="st" checked><label for="r2">IP statique</label></p>
   <label for="ip">Adresse IP</label><input id="ip" value="10.0.0.5"><label for="mk">Masque</label><input id="mk" value="255.255.255.0"></section>
   <section><h2>DMX</h2><label>Protocole <select id="p"><option>Art-Net</option><option selected>sACN</option></select></label></section>
   <section><h2>Port 1</h2><label>Mode <select id="d1"><option>Sortie</option><option selected>Entrée</option></select></label><label>Univers IN <input id="u1" type="number" value="3"></label></section>
   <section><h2>Système</h2><label>Nom long <input id="n" value="Régie"></label><label>Page login <input type="checkbox" id="lp" checked></label></section>
   <input type="submit" value="Enregistrer">`,
  // page dans un cadre (frameset)
  frame: `<iframe id="f" srcdoc="&lt;fieldset&gt;&lt;legend&gt;Device Setting&lt;/legend&gt;Long Device Name : &lt;input name='ln' value='Dans un cadre'&gt;&lt;br&gt;Short Device Name : &lt;input name='sn' value='CADRE'&gt;&lt;/fieldset&gt;&lt;button&gt;Apply&lt;/button&gt;"></iframe>`,
  // page de login
  login: `<form><input name="user" placeholder="User"><input type="password" name="pw"><button type="submit">Login</button></form>`
};

(async () => {
  const b = await chromium.launch();
  const p = await b.newPage();
  await p.goto('about:blank');
  for (const f of ['util.js', 'model.js', 'scraper.js']) await p.addScriptTag({ path: J(f) });
  const run = async (html) => {
    await p.setContent('<!doctype html><html><head><meta charset="utf-8"><title>Node</title></head><body>' + html + '</body></html>');
    await p.waitForTimeout(250);
    await p.addScriptTag({ path: J('util.js') }); await p.addScriptTag({ path: J('model.js') }); await p.addScriptTag({ path: J('scraper.js') });
    return p.evaluate(() => {
      eval(Scraper.SCRIPT);
      const scan = JSON.parse(window.__NP.scan());
      const t = Scraper.toTable(scan);
      const m = Model.mapTable(t);
      return { scan, canon: m.canon, refs: Object.keys(m.refs), unmapped: m.unmapped.map(i => t.params[i].label), groups: t.groups.map(g => g.name) };
    });
  };
  let r = await run(PAGES.table);
  ok(JSON.stringify(r.groups) === JSON.stringify(['IP Setting', 'DMX 1 Setting', 'Device Setting', 'Infos']), 'onglets reconnus (tableau)', r.groups);
  ok(r.canon.ipMode === 'static' && r.canon.ip === '2.0.0.11' && r.canon.mask === '255.0.0.0' && r.canon.protocol === 'artnet', 'réseau (tableau, IP en 4 cases)', r.canon);
  ok(r.canon.ports[0] && r.canon.ports[0].dir === 'out' && r.canon.ports[0].univOut === 7, 'port (tableau)', r.canon.ports);
  ok(r.canon.longName === 'Mon node' && r.canon.shortName === 'NODE7' && r.canon.fps === 30 && r.canon.firmware === 'Oct 10 2024' && r.canon.serial === 'EC1', 'appareil (tableau)', r.canon);
  ok(r.scan.buttons.some(x => x.text === 'Apply'), 'bouton Apply trouvé');
  const clicked = await p.evaluate(() => JSON.parse(window.__NP.click(Scraper.APPLY, Scraper.APPLY_EXCLUDE)).clicked);
  ok(clicked === 'Apply', 'clic sur Apply et pas sur Save Parameters', clicked);
  const set = await p.evaluate(() => { const r = JSON.parse(window.__NP.set(JSON.stringify([{ key: 'ID1', value: '2.0.0.99' }, { key: 'ID3', value: 1 }, { key: 'ID7', value: 'NEW' }]))); return [r, document.getElementById('ID1_IP3').value, document.getElementById('ID3').selectedIndex, document.getElementById('ID7').value]; });
  ok(set[0].ok.length === 3 && set[1] === '99' && set[2] === 1 && set[3] === 'NEW', 'remplissage (IP en 4 cases, liste, texte)', set);

  r = await run(PAGES.labels);
  ok(r.canon.ipMode === 'static' && r.canon.ip === '10.0.0.5' && r.canon.mask === '255.255.255.0', 'réseau (labels, radios)', r.canon);
  ok(r.canon.protocol === 'sacn' && r.canon.longName === 'Régie' && r.canon.loginPage === true, 'protocole, nom, case à cocher', r.canon);
  // champ unique en sACN : numéroté depuis 0 comme sur les anciens firmwares -> univers sACN 4
  ok(r.canon.ports[0] && r.canon.ports[0].dir === 'in' && r.canon.ports[0].univIn === 4, 'port (sections, sACN depuis 0)', r.canon.ports);
  const clicked2 = await p.evaluate(() => JSON.parse(window.__NP.click(Scraper.APPLY, Scraper.APPLY_EXCLUDE)).clicked);
  ok(clicked2 === 'Enregistrer', 'bouton Enregistrer', clicked2);

  r = await run(PAGES.frame);
  await p.waitForTimeout(200);
  r = await p.evaluate(() => { delete window.__NP; eval(Scraper.SCRIPT); const s = JSON.parse(window.__NP.scan()); const m = Model.mapTable(Scraper.toTable(s)); return { canon: m.canon, n: s.fields.length, b: s.buttons.map(x => x.text) }; });
  ok(r.canon.longName === 'Dans un cadre' && r.canon.shortName === 'CADRE', 'page dans un cadre', r);
  ok(r.b.indexOf('Apply') >= 0, 'bouton dans le cadre', r.b);

  r = await run(PAGES.login);
  ok(r.scan.isLogin === true, 'page de login détectée', r.scan.isLogin);
  const lg = await p.evaluate(() => { let sent = null; document.querySelector('form').addEventListener('submit', e => { e.preventDefault(); sent = [document.querySelector('[name=user]').value, document.querySelector('[name=pw]').value]; }); window.__NP.login('admin', 'secret'); return sent; });
  ok(lg && lg[0] === 'admin' && lg[1] === 'secret', 'formulaire de login rempli et envoyé', lg);

  await b.close();
  console.log(out.join('\n'));
  console.log((fail ? '❌ ' : '✅ ') + pass + ' réussis, ' + fail + ' en échec');
  process.exit(fail ? 1 : 0);
})();
