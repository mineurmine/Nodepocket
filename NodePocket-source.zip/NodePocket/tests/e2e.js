// Tests de bout en bout en mode démo (nodes simulés) — PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers node tests/e2e.js
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
const OUT = process.env.OUT || '/tmp/np-e2e';
fs.mkdirSync(OUT, { recursive: true });
const URL = 'file://' + path.resolve(__dirname, '../app/src/main/assets/index.html');
const ONLY = process.env.ONLY ? process.env.ONLY.split(',') : null;

let pass = 0, fail = 0;
const lines = [];
function ok(c, name, extra) {
  if (c) pass++; else { fail++; lines.push('ÉCHEC : ' + name + (extra !== undefined ? ' -> ' + JSON.stringify(extra).slice(0, 400) : '')); }
}

async function fresh(browser, opts) {
  const ctx = await browser.newContext({ viewport: (opts && opts.viewport) || { width: 960, height: 540 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message + '\n' + (e.stack || '').split('\n').slice(0, 3).join('\n')));
  page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto(URL + ((opts && opts.query) || ''));
  await page.waitForTimeout(500);
  if (!(opts && opts.noDemo)) {
    await page.click('.modal .btn.primary', { timeout: 5000 });
    await page.waitForTimeout(2300);
  }
  page.errors = errors;
  return { ctx, page };
}
const ev = (page, fn, arg) => page.evaluate(fn, arg);
const nodeId = (page, name) => ev(page, n => Store.nodes().find(x => Store.label(x) === n).id, name);
const sim = (page, short) => ev(page, s => { const n = Bridge.sim.fleet.find(x => x.s.shortName === s || x.serial === s); return n ? JSON.parse(JSON.stringify({ s: n.s, fw: n.fw, mode: n.mode })) : null; }, short);
async function openNode(page, name) {
  const id = await nodeId(page, name);
  await ev(page, id => App.go('fiche', { id }), id);
  await page.waitForTimeout(200);
  return id;
}
/** attend la fin d'une fenêtre de progression ; renvoie son texte et son journal */
async function waitProgress(page, timeout) {
  const t0 = Date.now();
  await page.waitForSelector('.prog .ptxt.ok, .prog .ptxt.err', { timeout: timeout || 30000 });
  if (process.env.TRACE) console.log('    progression terminée en ' + (Date.now() - t0) + ' ms');
  const r = await ev(page, () => ({ txt: document.querySelector('.prog .ptxt').textContent, cls: document.querySelector('.prog .ptxt').className, log: document.querySelector('.plog').innerText }));
  await ev(page, () => UI.closeTop());
  await page.waitForTimeout(150);
  return r;
}
async function setField(page, pathKey, value) {
  await ev(page, ([p, v]) => { const el = document.querySelector('[data-path="' + p + '"]'); el.value = v; el.dispatchEvent(new Event('change', { bubbles: true })); }, [pathKey, value]);
  await page.waitForTimeout(120);
}
async function clickSeg(page, name, value) {
  await page.click('.seg[data-seg="' + name + '"] .seg-b[data-v="' + value + '"]');
  await page.waitForTimeout(120);
}
async function answer(page, sel) {
  await page.waitForSelector('.modal', { timeout: 5000 });
  await page.click(sel || '.modal:last-of-type .dlg-f .btn:last-child');
  await page.waitForTimeout(150);
}
async function choose(page, text) {
  await page.waitForSelector('.modal .choice', { timeout: 5000 });
  await page.click('.modal .choice:has-text("' + text + '")');
  await page.waitForTimeout(200);
}

const T = {};
const step = (m) => { if (process.env.TRACE) console.log('  · ' + m); };

T.webRead = async browser => {
  const { ctx, page } = await fresh(browser);
  const nodes = await ev(page, () => Store.nodes().length);
  ok(nodes === 7, 'parc de démo : 7 nodes en IP fixe', nodes);
  const online = await ev(page, () => Store.nodes().filter(n => RT.isOnline(n)).length);
  ok(online === 7, 'tous en ligne (Art-Net)', online);
  const card = await ev(page, () => document.querySelector('.card.node .ports').innerText);
  ok(/1▸0/.test(card.replace(/\s/g, '')), 'univers annoncés en Art-Net sur la carte avant toute lecture', card);
  await openNode(page, 'JAR-FACE');
  await page.click('[data-act="read"]');
  const r = await waitProgress(page);
  ok(/Lu via page web/.test(r.txt), 'lecture par la page web', r);
  const last = await ev(page, () => { const n = Store.nodes().find(x => Store.label(x) === 'JAR-FACE'); return n.last; });
  ok(last && last.via === 'web' && last.canon.longName === 'Node Jardin Face' && last.canon.firmware === 'Mar 3 2025' && last.canon.serial === 'EC240412', 'valeurs lues', last && last.canon);
  ok(last && JSON.stringify(last.canon.ports.map(p => p.univOut)) === '[0,1,2,3]', 'univers lus', last && last.canon.ports);
  ok(last && last.canon.ipMode === 'static' && last.canon.ip === '2.0.0.11' && last.canon.mask === '255.0.0.0', 'réseau lu', last && last.canon);
  await page.screenshot({ path: OUT + '/web-read.png' });
  // modification + écriture
  await setField(page, 'shortName', 'JAR-NEW');
  await setField(page, 'ports.1.univOut', '20');
  await ev(page, () => { const s = document.querySelector('[data-path="outMode"]'); if (s) { s.value = 'fixed'; s.dispatchEvent(new Event('change', { bubbles: true })); } });
  await page.waitForTimeout(150);
  await setField(page, 'fps', '30');
  const pend = await ev(page, () => Store.pending(Store.nodes().find(x => Store.label(x) === 'JAR-FACE')).map(d => d.path));
  ok(JSON.stringify(pend.sort()) === JSON.stringify(['fps', 'outMode', 'ports.1.univOut', 'shortName']), 'écarts prévus', pend);
  await page.screenshot({ path: OUT + '/web-pending.png' });
  await page.click('[data-act="apply"]');
  const r2 = await waitProgress(page);
  ok(/vérifié/.test(r2.txt), 'écriture par la page web vérifiée', r2);
  const s = await sim(page, 'JAR-NEW');
  ok(s && s.s.ports[1].univOut === 20 && s.s.outMode === 'fixed' && s.s.fps === 30, 'le node simulé a changé', s && s.s);
  const pend2 = await ev(page, () => Store.pending(Store.nodes().find(x => x.ip === '2.0.0.11')).length);
  ok(pend2 === 0, 'plus d\'écart après écriture', pend2);
  // passage en sACN : univers sACN 5 -> champ 4 sur un ancien firmware
  await clickSeg(page, 'protocol', 'sacn');
  await setField(page, 'ports.0.univOut', '5');
  await page.click('[data-act="apply"]');
  const r3 = await waitProgress(page);
  const s3 = await sim(page, 'JAR-NEW');
  ok(/vérifié/.test(r3.txt) && s3.s.protocol === 'sacn' && s3.s.ports[0].univOut === 4, 'sACN : univers 5 écrit comme 4 dans le champ du node', { r3, p: s3.s.ports[0], proto: s3.s.protocol });
  const c3 = await ev(page, () => Store.nodes().find(x => x.ip === '2.0.0.11').last.canon.ports[0].univOut);
  ok(c3 === 5, 'relu comme univers sACN 5', c3);
  // univers sACN 0 refusé
  await setField(page, 'ports.0.univOut', '0');
  const bad = await ev(page, () => document.querySelector('[data-row="ports.0.univOut"]').className);
  ok(/bad/.test(bad), 'univers sACN 0 signalé', bad);
  await page.click('[data-act="apply"]');
  const r4 = await waitProgress(page);
  ok(/Échec/.test(r4.txt) && /sACN 0/.test(r4.log), 'univers sACN 0 refusé à l\'écriture', r4);
  ok(!page.errors.length, 'aucune erreur JS (lecture/écriture web)', page.errors);
  await ctx.close();
};

T.login = async browser => {
  const { ctx, page } = await fresh(browser);
  await openNode(page, 'LOINTAIN');
  await page.click('[data-act="read"]');
  const r = await waitProgress(page);
  ok(/Lu via page web/.test(r.txt) && /login/.test(r.log), 'page de login passée avec les identifiants', r);
  // mauvais mot de passe
  await ev(page, () => { const n = Store.nodes().find(x => Store.label(x) === 'LOINTAIN'); n.login.pass = 'faux'; });
  await ev(page, () => { const n = Store.nodes().find(x => Store.label(x) === 'LOINTAIN'); Bridge.pageClose('node_' + n.id); delete RemotePage.all['node_' + n.id]; Bridge.sim.fleet[3].sessions = {}; });
  await page.click('[data-act="read"]');
  const r2 = await waitProgress(page);
  ok(/impossible/.test(r2.txt) && /refusé/.test(r2.log), 'mauvais mot de passe signalé', r2);
  ok(!page.errors.length, 'aucune erreur JS (login)', page.errors);
  await ctx.close();
};

T.web2026 = async browser => {
  const { ctx, page } = await fresh(browser);
  await openNode(page, 'PLATEAU');
  await page.click('[data-act="read"]');
  const r = await waitProgress(page);
  const c = await ev(page, () => Store.nodes().find(x => Store.label(x) === 'PLATEAU').last);
  ok(/Lu via page web/.test(r.txt) && c && c.family === '2026', 'interface 2026 lue par le réseau', { r, fam: c && c.family });
  ok(c && c.canon.protocol === 'sacn' && JSON.stringify(c.canon.ports.map(p => p.univOut)) === '[13,14,15,16]' && c.canon.outMode === 'fixed' && c.canon.fps === 40 && c.canon.ip === '2.0.0.41' && c.canon.firmware === 'Jul 15 2026', 'valeurs 2026', c && c.canon);
  await setField(page, 'ports.2.univOut', '30');
  await setField(page, 'longName', 'Plateau modifié');
  await page.click('[data-act="apply"]');
  const r2 = await waitProgress(page);
  const s = await sim(page, 'PLATEAU');
  ok(/vérifié/.test(r2.txt) && s.s.ports[2].univOut === 30 && s.s.longName === 'Plateau modifié', 'écriture dans l\'interface 2026 (réseau)', { r2, s: s.s });
  // passage en Art-Net : ce sont les champs Art-Net qui doivent être écrits
  await clickSeg(page, 'protocol', 'artnet');
  await setField(page, 'ports.0.univOut', '7');
  await page.click('[data-act="apply"]');
  const r3 = await waitProgress(page);
  const s3 = await sim(page, 'PLATEAU');
  ok(/vérifié/.test(r3.txt) && s3.s.protocol === 'artnet' && s3.s.ports[0].univOut === 7, '2026 : bascule Art-Net + univers', { r3, s: s3.s });
  ok(!page.errors.length, 'aucune erreur JS (2026)', page.errors);
  await ctx.close();
};

T.usb = async browser => {
  const { ctx, page } = await fresh(browser);
  await ev(page, () => { Bridge.sim.plug(1); });
  await page.waitForTimeout(1500);
  const st = await ev(page, () => ({ state: USB.state, kind: USB.info && USB.info.kind, serial: USB.info && USB.info.serial, nodeId: USB.nodeId }));
  ok(st.state === 'ready' && st.kind === 'table' && st.serial === 'EC240413' && !st.nodeId, 'node USB lu, pas encore associé', st);
  await ev(page, () => App.go('usb'));
  await page.waitForTimeout(200);
  await page.screenshot({ path: OUT + '/usb-new.png' });
  await page.click('[data-act="link"]');
  await choose(page, 'COUR-FACE');
  const st2 = await ev(page, () => ({ nodeId: USB.nodeId, serial: Store.nodes().find(x => Store.label(x) === 'COUR-FACE').serial, via: Store.nodes().find(x => Store.label(x) === 'COUR-FACE').last.via }));
  ok(st2.nodeId && st2.serial === 'EC240413' && st2.via === 'usb', 'associé au node du parc', st2);
  await page.screenshot({ path: OUT + '/usb-linked.png' });
  // écriture USB depuis la fiche
  await openNode(page, 'COUR-FACE');
  const routes = await ev(page, () => Ops.routes(Store.nodes().find(x => Store.label(x) === 'COUR-FACE')));
  ok(routes[0] === 'usb', 'USB choisi en priorité quand le node est branché', routes);
  await setField(page, 'ports.3.univOut', '42');
  await clickSeg(page, 'ports.2.dir', 'in');
  await setField(page, 'ports.2.univIn', '9');
  await clickSeg(page, 'ipMode', 'static');
  await setField(page, 'ip', '2.0.0.112');
  await page.click('[data-act="apply"]');
  await answer(page);
  const r = await waitProgress(page);
  const s = await sim(page, 'EC240413');
  ok(/vérifié/.test(r.txt) && s.s.ports[3].univOut === 42 && s.s.ports[2].dir === 'in' && s.s.ports[2].univIn === 9 && s.s.ip === '2.0.0.112', 'écriture USB vérifiée (y compris l\'IP)', { r, s: s.s });
  // relecture : une seule écriture effective (seulement les champs changés)
  const log = await ev(page, () => Store.state.journal.slice(-1)[0]);
  ok(log.ok && /USB/.test(log.what), 'journal : écriture USB', log);
  // reset usine par USB
  await ev(page, () => USB.action('reset', null, Store.node(USB.nodeId)));
  await page.waitForTimeout(1200);
  const s2 = await sim(page, 'EC240413');
  ok(s2.s.ipMode === 'dhcp' && s2.s.ports[3].univOut === 3, 'reset usine par USB', s2.s);
  const pend = await ev(page, () => Store.pending(Store.node(USB.nodeId)).length);
  ok(pend > 0, 'après reset : écarts avec le prévu détectés', pend);
  await ev(page, () => App.go('usb'));
  await page.waitForTimeout(200);
  await page.click('[data-act="writePlan"]');
  const r3 = await waitProgress(page);
  const s3 = await sim(page, 'EC240413');
  ok(/vérifié/.test(r3.txt) && s3.s.ipMode === 'static' && s3.s.ip === '2.0.0.112' && s3.s.ports[3].univOut === 42, 'config prévue réécrite par USB après reset', { r3, s: s3.s });
  // débranchement
  await ev(page, () => Bridge.sim.unplug());
  await page.waitForTimeout(300);
  ok(await ev(page, () => USB.state === 'none' && !USB.client), 'débranchement détecté');
  ok(!page.errors.length, 'aucune erreur JS (USB)', page.errors);
  await ctx.close();
};

T.prepare = async browser => {
  const { ctx, page } = await fresh(browser);
  // série de 2 nodes neufs préparés dans l'appli
  step('série');
  await ev(page, () => { App.Pages.parc.series(); });
  await page.waitForSelector('.modal input[name=count]');
  await page.fill('.modal input[name=count]', '2');
  await page.selectOption('.modal select[name=model]', '1');
  await page.fill('.modal input[name=ip]', '2.0.0.50');
  await page.fill('.modal input[name=name]', 'NEUF-##');
  await page.fill('.modal input[name=univ]', '100');
  await answer(page);
  await answer(page); // message de confirmation
  step('série créée');
  const made = await ev(page, () => Store.nodes().filter(n => /^NEUF/.test(n.name)).map(n => ({ name: n.name, plan: n.plan })));
  ok(made.length === 2 && made[1].plan.ip === '2.0.0.51' && made[1].plan.ports[0].univOut === 101, 'série préparée', made);
  // un node neuf (DHCP, inconnu) branché en USB
  await ev(page, () => Bridge.sim.plug(7));
  await page.waitForTimeout(1300);
  await ev(page, () => App.go('usb'));
  await page.waitForTimeout(200);
  step('préparer');
  await page.click('[data-act="prepare"]');
  await choose(page, 'NEUF-02');
  step('choisi');
  await answer(page);
  const r = await waitProgress(page);
  const s = await sim(page, 'EC250199');
  ok(/vérifié/.test(r.txt) && s.s.ipMode === 'static' && s.s.ip === '2.0.0.51' && s.s.shortName === 'NEUF-02' && s.s.ports[0].univOut === 101, 'node neuf préparé par USB', { r, s: s.s });
  const n = await ev(page, () => { const x = Store.nodes().find(y => y.name === 'NEUF-02'); return { serial: x.serial, pend: Store.pending(x).length }; });
  ok(n.serial === 'EC250199' && n.pend === 0, 'numéro de série enregistré, plus d\'écart', n);
  await page.screenshot({ path: OUT + '/usb-prepared.png' });
  ok(!page.errors.length, 'aucune erreur JS (préparation)', page.errors);
  await ctx.close();
};

T.usb2026 = async browser => {
  const { ctx, page } = await fresh(browser);
  await ev(page, () => Bridge.sim.plug(6));
  await page.waitForTimeout(3500);
  const st = await ev(page, () => ({ state: USB.state, kind: USB.info && USB.info.kind, err: USB.error, canon: USB.info && USB.info.mapped && USB.info.mapped.canon, nodeId: USB.nodeId }));
  ok(st.state === 'ready' && st.kind === 'gui' && st.canon && st.canon.serial === 'EC260401' && st.canon.protocol === 'sacn', 'node 2026 lu par son interface USB', st);
  await ev(page, () => App.go('usb'));
  await page.waitForTimeout(200);
  await page.click('[data-act="link"]');
  await choose(page, 'PLATEAU');
  await openNode(page, 'PLATEAU');
  await setField(page, 'shortName', 'PLAT-USB');
  await setField(page, 'ports.1.univOut', '33');
  await page.click('[data-act="apply"]');
  const r = await waitProgress(page, 40000);
  const s = await sim(page, 'EC260401');
  ok(/vérifié/.test(r.txt) && s.s.shortName === 'PLAT-USB' && s.s.ports[1].univOut === 33, 'écriture 2026 par l\'interface USB', { r, s: s.s });
  // affichage de l'interface du node
  await ev(page, () => App.go('usb'));
  await page.waitForTimeout(200);
  await page.click('[data-act="gui"]');
  await page.waitForTimeout(800);
  const vis = await ev(page, () => document.querySelector('.guihost.show') !== null);
  ok(vis, 'interface du node affichée en plein écran');
  await page.screenshot({ path: OUT + '/usb-gui.png' });
  await ev(page, () => App.back());
  ok(!page.errors.length, 'aucune erreur JS (USB 2026)', page.errors);
  await ctx.close();
};

T.firmware = async browser => {
  const { ctx, page } = await fresh(browser);
  await ev(page, () => App.go('firmware'));
  await page.waitForTimeout(200);
  await page.click('[data-act="readAll"]');
  const r = await waitProgress(page, 60000);
  ok(/7 \/ 7/.test(r.txt), 'versions lues', r);
  const st = await ev(page, () => { const f = Model.firmwareStatus(Store.nodes(), Store.state.fwPinned).byNode; return Store.nodes().map(n => Store.label(n) + ':' + f[n.id].status); });
  ok(st.indexOf('RAMPE:old') >= 0 && st.indexOf('COUR-FACE:old') >= 0 && st.indexOf('SALLE:ok') >= 0, 'nodes en retard repérés', st);
  await page.screenshot({ path: OUT + '/fw-list.png' });
  // mise à jour de RAMPE par USB
  await ev(page, () => Bridge.sim.plug(5));
  await page.waitForTimeout(1300);
  const assoc = await ev(page, () => USB.nodeId && Store.label(Store.node(USB.nodeId)));
  ok(assoc === 'RAMPE', 'node USB reconnu par son n° de série', assoc);
  await ev(page, () => App.go('firmware', { id: USB.nodeId }));
  await page.waitForTimeout(200);
  await ev(page, () => { Bridge.nextPick = { name: 'node1-2026-09.dfu', bytes: Sim.SimNode.demoFirmware('Sep 1 2026') }; });
  step('choix du fichier');
  await page.click('[data-act="pick"]');
  await page.waitForTimeout(300);
  await page.screenshot({ path: OUT + '/fw-ready.png' });
  step('lancer');
  await page.click('[data-act="go"]');
  await answer(page);
  const r2 = await waitProgress(page, 60000);
  const s = await sim(page, 'EC240107');
  ok(/mis à jour/.test(r2.txt) && s.fw === 'Sep 1 2026' && s.mode === 'app', 'firmware envoyé par DFU et relu', { r2, s: s && s.fw });
  const fwn = await ev(page, () => Store.nodes().find(x => Store.label(x) === 'RAMPE').firmware);
  ok(fwn === 'Sep 1 2026', 'nouvelle version enregistrée', fwn);
  await page.screenshot({ path: OUT + '/fw-done.png' });
  // fichier corrompu : refusé avant envoi
  const bad = await ev(page, () => { const b = Sim.SimNode.demoFirmware('Oct 1 2026'); b[200] ^= 0xff; const f = DFU.parseFile(b, 'x.dfu'); return DFU.check(f, null).map(c => c.level + ':' + c.msg); });
  ok(bad.some(x => /^err:.*CRC/.test(x)), 'fichier abîmé refusé', bad);
  ok(!page.errors.length, 'aucune erreur JS (firmware)', page.errors);
  await ctx.close();
};

T.lot = async browser => {
  const { ctx, page } = await fresh(browser);
  const ids = await ev(page, () => Store.nodes().filter(n => ['JAR-FACE', 'COUR-FACE', 'PERCHES'].indexOf(Store.label(n)) >= 0).map(n => n.id));
  await ev(page, ids => App.go('lot', { ids }), ids);
  await page.waitForTimeout(200);
  await page.selectOption('select[data-lot="outMode"]', 'fixed');
  await page.waitForTimeout(150);
  await page.fill('input[data-lot="fps"]', '25');
  await page.dispatchEvent('input[data-lot="fps"]', 'change');
  await page.waitForTimeout(150);
  await page.selectOption('select[data-lot="univ"]', 'seq');
  await page.waitForTimeout(150);
  await page.fill('input[data-lot="univVal"]', '40');
  await page.dispatchEvent('input[data-lot="univVal"]', 'change');
  await page.waitForTimeout(200);
  await page.screenshot({ path: OUT + '/lot.png', fullPage: true });
  const prev = await ev(page, () => document.querySelector('.box:nth-of-type(2) table') ? document.querySelectorAll('.box table tr').length : 0);
  ok(prev === 3, 'aperçu : 3 nodes modifiés', prev);
  await page.click('[data-act="saveApply"]');
  await answer(page);
  const r = await waitProgress(page, 60000);
  ok(/3 \/ 3/.test(r.txt), 'lot appliqué sur 3 nodes', r);
  const a = await sim(page, 'JAR-FACE'), b = await sim(page, 'COUR-FACE'), c = await sim(page, 'PERCHES');
  // tri par IP : JAR (2.0.0.11) 40-43, COUR (.12) 44-47, PERCHES (.21) 48-49
  ok(a.s.outMode === 'fixed' && a.s.fps === 25 && JSON.stringify(a.s.ports.map(p => p.univOut)) === '[40,41,42,43]', 'lot node 1', a.s);
  ok(JSON.stringify(b.s.ports.map(p => p.univOut)) === '[44,45,46,47]' && b.s.fps === 25, 'lot node 2', b.s.ports);
  ok(JSON.stringify(c.s.ports.map(p => p.univOut)) === '[48,49]', 'lot node 3', c.s.ports);
  ok(!page.errors.length, 'aucune erreur JS (lot)', page.errors);
  await ctx.close();
};

T.plan = async browser => {
  const { ctx, page } = await fresh(browser);
  await ev(page, () => App.go('univers'));
  await page.waitForTimeout(300);
  const txt = await ev(page, () => document.querySelector('.content').innerText);
  ok(/boucle/.test(txt), 'plan : node qui renvoie son univers (LOINTAIN)', txt.slice(0, 300));
  ok(/MA 13/.test(txt) && /SALLE/.test(txt) && /RAMPE/.test(txt), 'plan : univers partagé par deux nodes en sortie', txt.slice(0, 600));
  // conflit d'IP prévu
  await ev(page, () => { const n = Store.nodes().find(x => Store.label(x) === 'PERCHES'); n.plan.ipMode = 'static'; n.plan.ip = '2.0.0.11'; Store.save(); App.render(); });
  await page.waitForTimeout(300);
  const txt2 = await ev(page, () => document.querySelector('.issues').innerText);
  ok(/2\.0\.0\.11 utilisée par/.test(txt2), 'plan : IP en double détectée', txt2);
  await page.screenshot({ path: OUT + '/univers.png', fullPage: true });
  const badge = await ev(page, () => document.querySelector('.nv[data-arg="univers"] .cnt') !== null);
  ok(badge, 'pastille d\'alerte sur l\'onglet Univers');
  ok(!page.errors.length, 'aucune erreur JS (univers)', page.errors);
  await ctx.close();
};

T.prods = async browser => {
  const { ctx, page } = await fresh(browser);
  await ev(page, () => App.go('prods'));
  await page.waitForTimeout(200);
  await page.click('[data-act="snap"]');
  await page.waitForSelector('.modal select[name=src]');
  await page.selectOption('.modal select[name=src]', 'readnow');
  await answer(page);
  const r = await waitProgress(page, 60000);
  ok(/7 \/ 7/.test(r.txt), 'sauvegarde : lecture de tous les nodes', r);
  await page.waitForTimeout(300);
  const p = await ev(page, () => ({ n: Store.state.prods.length, nodes: Object.keys(Store.state.prods[0].nodes).length }));
  ok(p.n === 1 && p.nodes === 7, 'sauvegarde créée', p);
  // un node est modifié "à la main" sur sa page web
  await ev(page, () => { const n = Bridge.sim.fleet[2]; n.s.ports[0].univOut = 77; n.s.shortName = 'ABIME'; });
  await openNode(page, 'PERCHES');
  await page.click('[data-act="read"]');
  await waitProgress(page);
  await ev(page, () => App.go('prods'));
  await page.waitForTimeout(200);
  await page.click('.card[data-act="openProd"]');
  await page.waitForTimeout(200);
  const det = await ev(page, () => document.querySelector('.content').innerText);
  ok(/2 différences/.test(det), 'sauvegarde : différence détectée', det.slice(0, 500));
  await page.click('[data-act="restore"]');
  await answer(page);
  await answer(page);
  const r2 = await waitProgress(page, 60000);
  const s = await sim(page, 'PERCHES');
  ok(/1 \/ 1/.test(r2.txt) && s && s.s.ports[0].univOut === 8, 'config remise depuis la sauvegarde', { r2, s: s && s.s });
  // export / import des données
  const exp = await ev(page, () => Store.exportAll());
  const back = await ev(page, txt => { const before = Store.nodes().length; Store.importAll(txt, 'replace'); return [before, Store.nodes().length, Store.state.prods.length]; }, exp);
  ok(back[0] === back[1] && back[2] === 1, 'export puis import complet', back);
  const csv = await ev(page, () => Store.csv());
  ok(/^Nom;IP;/.test(csv) && csv.split('\n').length > 10, 'feuille de patch CSV', csv.slice(0, 200));
  ok(!page.errors.length, 'aucune erreur JS (sauvegardes)', page.errors);
  await ctx.close();
};

T.artnet = async browser => {
  const { ctx, page } = await fresh(browser);
  const id = await openNode(page, 'PERCHES');
  await clickSeg(page, 'via', 'artnet');
  await setField(page, 'shortName', 'PERCH-AN');
  await setField(page, 'ports.1.univOut', '11');
  await page.click('[data-act="apply"]');
  const r = await waitProgress(page);
  const s = await sim(page, 'PERCH-AN');
  ok(/vérifié|Terminé et/.test(r.txt) && s && s.s.ports[1].univOut === 11, 'écriture Art-Net standard (ArtAddress)', { r, s: s && s.s });
  // node qui ne gère pas ArtAddress
  await openNode(page, 'LOINTAIN');
  await clickSeg(page, 'via', 'artnet');
  await setField(page, 'shortName', 'LOIN-AN');
  await page.click('[data-act="apply"]');
  const r2 = await waitProgress(page);
  ok(/écarts|Échec/.test(r2.txt) && /ArtAddress/.test(r2.log), 'node sans ArtAddress : écart signalé avec conseil', r2);
  // identification
  await ev(page, id => Ops.action(Store.node(id), 'identify'), id);
  await page.waitForTimeout(200);
  const ident = await ev(page, () => Bridge.sim.fleet[2].identify > Date.now());
  ok(ident, 'identification envoyée (AcLedLocate)');
  ok(!page.errors.length, 'aucune erreur JS (Art-Net)', page.errors);
  await ctx.close();
};

T.reboot = async browser => {
  const { ctx, page } = await fresh(browser);
  await ev(page, () => { Bridge.sim.fleet[4].rebootOnApply = 2500; });
  await openNode(page, 'SALLE');
  await setField(page, 'shortName', 'SALLE-2');
  await page.click('[data-act="apply"]');
  const r = await waitProgress(page, 60000);
  const s = await sim(page, 'SALLE-2');
  ok(/vérifié/.test(r.txt) && /redémarre/.test(r.log) && s, 'node qui redémarre après Appliquer : page rouverte et vérifiée', r);
  ok(!page.errors.length, 'aucune erreur JS (redémarrage)', page.errors);
  await ctx.close();
};

T.pad = async browser => {
  const { ctx, page } = await fresh(browser, { query: '?pad=1' });
  ok(await ev(page, () => document.body.classList.contains('pad')), 'mode manette activé');
  // la croix déplace le focus sur les cartes, A ouvre la fiche
  await ev(page, () => { const c = document.querySelector('.card.node'); UI.focus(c); });
  await page.keyboard.press('ArrowRight');
  await page.waitForTimeout(120);
  const f1 = await ev(page, () => document.activeElement.querySelector && document.activeElement.querySelector('.nm') && document.activeElement.querySelector('.nm').textContent);
  ok(f1 === 'COUR-FACE', 'croix → : carte voisine', f1);
  await page.keyboard.press('ArrowDown');
  await page.waitForTimeout(120);
  const f2 = await ev(page, () => document.activeElement.querySelector && document.activeElement.querySelector('.nm') && document.activeElement.querySelector('.nm').textContent);
  ok(f2 === 'LOINTAIN', 'croix ↓ : carte du dessous', f2);
  await page.keyboard.press('Enter');
  await page.waitForTimeout(300);
  ok(await ev(page, () => App.page === 'fiche'), 'A ouvre la fiche');
  await page.keyboard.press('e'); // R1 : onglet suivant
  await page.waitForTimeout(200);
  ok(await ev(page, () => App.Pages.fiche.tab === 'raw'), 'R1 : onglet suivant');
  await page.keyboard.press('Escape'); // B
  await page.waitForTimeout(200);
  ok(await ev(page, () => App.page === 'parc'), 'B : retour au parc');
  await page.keyboard.press('Tab'); // Select : aide
  await page.waitForTimeout(200);
  ok(await ev(page, () => !!document.querySelector('.modal table.keys')), 'Select : aide des boutons');
  await page.screenshot({ path: OUT + '/pad-help.png' });
  await page.keyboard.press('Escape');
  await page.waitForTimeout(150);
  // champ nombre : ← → change la valeur
  await openNode(page, 'SALLE');
  await ev(page, () => UI.focus(document.querySelector('[data-path="ports.0.univOut"]')));
  await page.keyboard.press('ArrowRight');
  await page.keyboard.press('ArrowRight');
  await page.waitForTimeout(250);
  const v = await ev(page, () => Store.nodes().find(x => Store.label(x) === 'SALLE').plan.ports[0].univOut);
  ok(v === 14, 'croix → sur un univers : +1 à chaque appui', v);
  await page.screenshot({ path: OUT + '/pad-fiche.png' });
  ok(!page.errors.length, 'aucune erreur JS (manette)', page.errors);
  await ctx.close();
};

T.phone = async browser => {
  const { ctx, page } = await fresh(browser, { viewport: { width: 390, height: 844 } });
  await page.screenshot({ path: OUT + '/phone-parc.png' });
  await openNode(page, 'JAR-FACE');
  await page.screenshot({ path: OUT + '/phone-fiche.png' });
  const overflow = await ev(page, () => document.documentElement.scrollWidth > innerWidth + 1 || document.querySelector('.content').scrollWidth > document.querySelector('.content').clientWidth + 1);
  ok(!overflow, 'téléphone : pas de débordement horizontal');
  for (const p of ['univers', 'lot', 'firmware', 'usb', 'prods', 'reglages']) {
    await ev(page, p => App.go(p), p);
    await page.waitForTimeout(250);
    const o = await ev(page, () => document.querySelector('.content').scrollWidth > document.querySelector('.content').clientWidth + 1);
    ok(!o, 'téléphone : ' + p + ' sans débordement');
  }
  await ev(page, () => App.go('univers'));
  await page.waitForTimeout(200);
  await page.screenshot({ path: OUT + '/phone-univers.png' });
  ok(!page.errors.length, 'aucune erreur JS (téléphone)', page.errors);
  await ctx.close();
};

(async () => {
  const browser = await chromium.launch();
  for (const k of Object.keys(T)) {
    if (ONLY && ONLY.indexOf(k) < 0) continue;
    const t0 = Date.now();
    const before = fail;
    try { await T[k](browser); } catch (e) { fail++; lines.push('ÉCHEC : ' + k + ' a planté : ' + e.message.split('\n')[0]); }
    console.log((fail > before ? '✗ ' : '✓ ') + k + ' (' + ((Date.now() - t0) / 1000).toFixed(1) + ' s)');
  }
  await browser.close();
  console.log(lines.join('\n'));
  console.log((fail ? '❌ ' : '✅ ') + pass + ' réussis, ' + fail + ' en échec');
  process.exit(fail ? 1 : 0);
})();
