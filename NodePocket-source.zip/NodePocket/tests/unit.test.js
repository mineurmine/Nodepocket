/* Tests unitaires des modules de protocole — node tests/unit.test.js */
'use strict';
const path = require('path');
const J = f => path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'js', f);
global.self = global;
const U = require(J('util.js')); global.U = U;
const A = require(J('artnet.js')); global.ArtNet = A;
const H = require(J('hidproto.js'));
const M = require(J('model.js'));
const D = require(J('dfu.js'));
const S = require(J('scraper.js'));
const Sim = require(J('sim.js'));
const zlib = require('zlib');

let pass = 0, fail = 0;
const results = [];
function ok(cond, name, extra) {
  if (cond) { pass++; } else { fail++; results.push('ÉCHEC : ' + name + (extra !== undefined ? ' -> ' + JSON.stringify(extra) : '')); }
}
function eq(a, b, name) { ok(JSON.stringify(a) === JSON.stringify(b), name, { got: a, want: b }); }

(async () => {
  // ------------------------------------------------------------ util
  eq(U.parseFirmware('Oct 10 2024').date, '2024-10-10', 'firmware __DATE__');
  eq(U.parseFirmware('Mar  3 2025 14:02:11').date, '2025-03-03', 'firmware __DATE__ + heure');
  eq(U.parseFirmware('15/07/2026').date, '2026-07-15', 'firmware JJ/MM/AAAA');
  eq(U.parseFirmware('2026-07-15').date, '2026-07-15', 'firmware ISO');
  eq(U.parseFirmware('V1.2.10').nums, [1, 2, 10], 'firmware version');
  eq(U.parseFirmware('15 juillet 2026').date, '2026-07-15', 'firmware date en français');
  ok(U.compareFirmware('Oct 10 2024', 'Mar 3 2025') < 0, 'firmware plus ancien');
  ok(U.compareFirmware('V1.10', 'V1.9') > 0, 'version 1.10 > 1.9');
  ok(U.compareFirmware('Mar 3 2025', '03/03/2025') === 0, 'même date, formats différents');
  ok(U.compareFirmware('abc', 'Mar 3 2025') === null, 'non comparable');
  ok(U.isIp('2.0.0.11') && !U.isIp('2.0.0.256') && !U.isIp('2.0.0'), 'isIp');
  ok(U.isMask('255.0.0.0') && !U.isMask('255.0.255.0'), 'isMask');
  eq(U.broadcast('2.0.0.11', '255.0.0.0'), '2.255.255.255', 'broadcast');
  eq(U.nextIp('2.0.0.255', 1), '2.0.1.0', 'nextIp');
  eq(U.norm('Max Total Universe ( 1 to 4):'), 'max total universe', 'norm');
  eq(U.norm('Priorité sACN'), 'priorite sacn', 'norm accents');
  eq(U.crc32(U.utf8('123456789')), 0xCBF43926, 'crc32 standard');

  // ------------------------------------------------------------ Art-Net
  const fleet = Sim.demoFleet();
  const n0 = fleet[0];
  const poll = A.buildPoll();
  eq(A.opcode(poll), A.OP.POLL, 'ArtPoll opcode');
  const replies = n0.artnet(poll);
  eq(replies.length, 1, 'un seul ArtPollReply pour 4 ports du même bloc');
  const r0 = A.parsePollReply(replies[0], '2.0.0.11');
  eq(r0.ip, '2.0.0.11', 'reply ip');
  eq(r0.shortName, 'JAR-FACE', 'reply short name');
  eq(r0.longName, 'Node Jardin Face', 'reply long name');
  eq(r0.numPorts, 4, 'reply 4 ports');
  eq(r0.ports.map(p => p.univOut), [0, 1, 2, 3], 'reply univers');
  eq(r0.mac, n0.mac, 'reply mac');
  ok(!r0.dhcp && r0.dhcpCapable, 'reply statut DHCP');
  const merged = A.mergeReplies([r0]);
  eq(merged.protocolGuess, 'artnet', 'protocole deviné');
  const c0 = M.fromPoll(merged);
  eq(c0.ports.map(p => p.univOut), [0, 1, 2, 3], 'fromPoll univers');
  eq(c0.ipMode, 'static', 'fromPoll adressage');

  // ports dans des blocs différents -> un reply par port (BindIndex)
  const n4 = fleet[3]; // ports 10 out et 10 in
  n4.s.ports[0].univOut = 3; n4.s.ports[1].univIn = 40;
  const rs = n4.artnet(poll).map(b => A.parsePollReply(b, n4.ipNow));
  eq(rs.length, 2, 'deux replies (BindIndex)');
  const m4 = A.mergeReplies(rs);
  eq(m4.ports.length, 2, 'fusion BindIndex : 2 ports');
  eq([m4.ports[0].univOut, m4.ports[1].univIn], [3, 40], 'fusion BindIndex : univers');

  // ArtAddress
  const plan = A.planUniverses([{ index: 0, univOut: 16 }, { index: 1, univOut: 17 }, { index: 2, univOut: 18 }, { index: 3, univOut: 19 }], { shortName: 'TEST', longName: 'Test long', command: A.AC.ACN_SEL });
  ok(!plan.error && plan.packets.length === 1, 'plan ArtAddress', plan.error);
  const back = n0.artnet(plan.packets[0]).map(b => A.parsePollReply(b));
  eq(n0.s.ports.map(p => p.univOut), [16, 17, 18, 19], 'ArtAddress appliqué au node simulé');
  eq(n0.s.shortName, 'TEST', 'ArtAddress nom court');
  eq(n0.s.protocol, 'sacn', 'ArtAddress AcAcnSel');
  eq(back[0].ports.map(p => p.univOut), [16, 17, 18, 19], 'ArtAddress : réponse relue');
  const bad = A.planUniverses([{ index: 0, univOut: 3 }, { index: 1, univOut: 40 }]);
  ok(!!bad.error, 'ArtAddress refuse deux blocs différents sur un même BindIndex');
  // ArtIpProg
  const ipr = n0.artnet(A.buildIpProg({ ip: '2.0.0.99', mask: '255.0.0.0' }));
  eq(A.parseIpProgReply(ipr[0]).ip, '2.0.0.99', 'ArtIpProg');
  // ArtDmx
  const dmx = A.buildDmx(5, new Uint8Array([1, 2, 3]), 7);
  const pd = A.parseDmx(dmx);
  eq([pd.universe, pd.data.length, pd.data[0], pd.seq], [5, 4, 1, 7], 'ArtDmx aller-retour (longueur paire)');
  // sACN
  const sacn = new Uint8Array(126 + 512);
  sacn.set([0x00, 0x10, 0x00, 0x00, 0x41, 0x53, 0x43, 0x2d, 0x45, 0x31, 0x2e, 0x31, 0x37, 0, 0, 0], 0);
  sacn.set([0, 0, 0, 4], 18); sacn.set([0, 0, 0, 2], 40); sacn.set(U.utf8('Console'), 44);
  sacn[108] = 100; sacn[113] = 0; sacn[114] = 7; sacn[123] = 0x02; sacn[124] = 0x01; sacn[126] = 255;
  const ps = A.parseSacn(sacn);
  eq([ps.universe, ps.priority, ps.sourceName, ps.data.length, ps.data[0]], [7, 100, 'Console', 512, 255], 'sACN lecture');
  eq(A.sacnGroup(1), '239.255.0.1', 'groupe multicast sACN');

  // ------------------------------------------------------------ HID (protocole dmx-tools) contre le node simulé
  const n1 = Sim.demoFleet()[1];
  const io = { xfer: async req => n1.hid(req) };
  const cli = new H.Client(io);
  const table = await cli.readAll();
  eq(table.name, 'NODE 4 ARTNET PoE', 'HID nom produit');
  eq(table.groups.map(g => g.name), ['IP Setting', 'DMX 1 Setting', 'DMX 2 Setting', 'DMX 3 Setting', 'DMX 4 Setting', 'Device Setting', 'Infos'], 'HID groupes');
  const pLong = table.params.find(p => p.label === 'Long Device Name');
  eq(pLong.value, 'Node Cour Face', 'HID texte');
  const pProto = table.params.find(p => p.label === 'DMX Protocol');
  eq(pProto.options, ['Art-Net', 'sACN'], 'HID options de liste');
  const pIp = table.params.find(p => p.label === 'Device IP (static)');
  eq(pIp.value, '2.0.0.12', 'HID adresse IP');
  const pFps = table.params.find(p => /^Fps/.test(p.label));
  eq([pFps.min, pFps.max], [16, 44], 'HID min/max');
  ok(table.params.find(p => p.label === 'Firmware Version').readonly, 'HID lecture seule');

  // modèle commun
  const mp = M.mapTable(table);
  const c = mp.canon;
  eq([c.longName, c.shortName, c.ipMode, c.ip, c.mask, c.protocol, c.outMode, c.fps, c.firmware, c.serial, c.loginPage], ['Node Cour Face', 'COUR-FACE', 'static', '2.0.0.12', '255.0.0.0', 'artnet', 'sync', 44, 'Oct 10 2024', 'EC240413', false], 'canon global (classique)');
  eq(c.ports.map(p => [p.dir, p.univOut]), [['out', 4], ['out', 5], ['out', 6], ['out', 7]], 'canon ports (classique)');
  eq(mp.ports, 4, 'canon nombre de ports');
  ok(mp.actions.reset != null && mp.actions.dfu != null, 'actions reset/dfu trouvées');
  eq(mp.unmapped.length, 0, 'aucun paramètre classique non reconnu', mp.unmapped.map(i => table.params[i].label));

  // changements -> écriture -> relecture
  const target = { shortName: 'COUR-2', protocol: 'sacn', outMode: 'fixed', fps: 30, ports: [{ univOut: 1 }, { dir: 'in', univIn: 2 }] };
  const ch = M.changesFor(mp, target);
  eq(ch.errors, [], 'pas d\'erreur de conversion');
  // sACN univers 1 sur ancien firmware (numéroté depuis 0) -> champ = 0
  const chU = ch.changes.find(x => x.path === 'ports.0.univOut');
  eq(chU.value, 0, 'univers sACN 1 -> champ 0 (ancien firmware)');
  const rep = await cli.apply(ch.changes.map(x => ({ param: x.param, value: x.value })));
  ok(rep.every(r => r.ok), 'écriture HID vérifiée', rep.filter(r => !r.ok));
  const table2 = await cli.readAll();
  const c2 = M.mapTable(table2).canon;
  eq([c2.shortName, c2.protocol, c2.outMode, c2.fps, c2.ports[0].univOut, c2.ports[1].dir, c2.ports[1].univIn], ['COUR-2', 'sacn', 'fixed', 30, 1, 'in', 2], 'relecture après écriture');
  eq(M.diff(target, c2), [], 'plus aucun écart');
  const errU = M.changesFor(M.mapTable(table2), { protocol: 'sacn', ports: [{ univOut: 0 }] });
  ok(errU.errors.length === 1, 'univers sACN 0 refusé');
  const errFps = M.changesFor(M.mapTable(table2), { fps: 60 });
  ok(errFps.errors.length === 1, 'fps hors limites refusé');
  const errLong = M.changesFor(M.mapTable(table2), { shortName: 'X'.repeat(30) });
  ok(errLong.errors.length === 1, 'nom court trop long refusé');
  // action DFU
  const pDfu = table2.params[mp.actions.dfu];
  eq(M.actionValue(pDfu, true), 1, 'valeur DFU = YES');
  eq(M.actionValue(table2.params[mp.actions.reset], false), 0, 'valeur reset = NO');
  // tous les paramètres comme dmx-tools (ne doit rien casser)
  await cli.applyAllLikeDmxTools(table2.params);
  const c3 = M.mapTable(await cli.readAll()).canon;
  eq(M.diff(c2, c3), [], 'Appliquer façon dmx-tools : rien ne change');
  ok(n1.mode === 'app', 'le node reste en marche (DFU/Reset non déclenchés)');

  // décoration compatible dmx-tools
  const deco = H.decorate(n1.hid(H.req(H.CMD.PARAM_DEF, 1)));
  ok(deco.ParamName === 'Device IP (static)' && deco.Type === 2 && deco.ParamGroupe === 0, 'propriétés dmx-tools');

  // texte trop long refusé avant envoi
  let threw = false;
  try { H.encodeValue({ type: 1, index: 0, label: 'x' }, 'é'.repeat(40)); } catch (e) { threw = true; }
  ok(threw, 'texte > 61 octets refusé');

  // fichiers de l'interface web (famille 2026) + gzip
  const n7 = Sim.demoFleet()[6];
  const cli7 = new H.Client({ xfer: async req => n7.hid(req) });
  ok(await cli7.hasWebInterface(), 'interface web HID détectée (2026)');
  ok(!(await cli.hasWebInterface()), 'pas d\'interface web sur un node classique');
  const idx = await cli7.getFile('index.html');
  ok(idx && /Configuration DMX/.test(U.utf8dec(idx.data)) && idx.mime === 'text/html', 'index.html via HID');
  const apiGet = await cli7.getFile('api/get');
  eq(JSON.parse(U.utf8dec(apiGet.data)).serial, 'EC260401', 'API via HID');
  const t7 = await cli7.readAll();
  eq([t7.groups.length, t7.params.length], [0, 0], 'famille 2026 : aucune table de paramètres');
  // gzip
  const gz = new Uint8Array(zlib.gzipSync(Buffer.from('<html>bonjour</html>')));
  const fake = { file: () => ({ mime: 'text/html', data: gz }) };
  const n7b = Sim.demoFleet()[6];
  n7b.file = fake.file;
  const g = await new H.Client({ xfer: async req => n7b.hid(req) }).getFile('index.html');
  eq(U.utf8dec(g.data), '<html>bonjour</html>', 'fichier gzip décompressé');

  // ------------------------------------------------------------ plan d'univers
  const entries = [
    { id: 'a', name: 'A', canon: { protocol: 'artnet', ipMode: 'static', ip: '2.0.0.1', shortName: 'A', ports: [{ dir: 'out', univOut: 0 }, { dir: 'in', univIn: 5 }] } },
    { id: 'b', name: 'B', canon: { protocol: 'artnet', ipMode: 'static', ip: '2.0.0.1', shortName: 'A', ports: [{ dir: 'in', univIn: 5 }] } },
    { id: 'c', name: 'C', canon: { protocol: 'sacn', ipMode: 'static', ip: '10.0.0.3', shortName: 'C', ports: [{ dir: 'out', univOut: 1 }] } }
  ];
  const up = M.universePlan(entries, { expected: [1, 2, 3], subnet: { ip: '2.0.0.100', mask: '255.0.0.0' } });
  ok(up.rows.length === 3, 'plan : 3 lignes', up.rows);
  ok(up.issues.some(i => /entrées DMX envoient Art-Net 5/.test(i.msg) && i.level === 'err'), 'plan : conflit de sources');
  ok(up.issues.some(i => /2\.0\.0\.1 utilisée/.test(i.msg)), 'plan : IP en double');
  ok(up.issues.some(i => /Univers 2 \(console\)/.test(i.msg)), 'plan : univers attendu manquant');
  ok(up.issues.some(i => /Univers 1 utilisé à la fois/.test(i.msg)), 'plan : Art-Net 0 et sACN 1 = même univers console');
  ok(up.issues.some(i => /hors du réseau/.test(i.msg)), 'plan : hors réseau');
  ok(up.issues.some(i => /Nom court/.test(i.msg)), 'plan : nom en double');
  eq(M.parseRanges('1-3, 7,9-8'), [1, 2, 3, 7, 8, 9], 'plages');

  // ------------------------------------------------------------ opérations par lot
  const ops = [{ path: 'protocol', value: 'sacn' }, { path: 'ports.*.univOut', op: 'seq', value: 1 }, { path: 'ip', op: 'seq', value: '2.0.0.10' }, { path: 'shortName', op: 'seq', value: 'NODE-##' }];
  const b0 = M.applyOps({ ports: [{}, {}] }, ops, { idx: 0, portOffset: 0, nPorts: 2 });
  const b1 = M.applyOps({ ports: [{}, {}, {}, {}] }, ops, { idx: 1, portOffset: 2, nPorts: 4 });
  eq([b0.protocol, b0.ports.map(p => p.univOut), b0.ip, b0.shortName], ['sacn', [1, 2], '2.0.0.10', 'NODE-01'], 'lot node 1');
  eq([b1.ports.map(p => p.univOut), b1.ip, b1.shortName], [[3, 4, 5, 6], '2.0.0.11', 'NODE-02'], 'lot node 2');
  const off = M.applyOps({ ports: [{ univOut: 3 }, { univOut: 4 }] }, [{ path: 'ports.*.univOut', op: 'offset', value: 16 }], { idx: 0 });
  eq(off.ports.map(p => p.univOut), [19, 20], 'décalage d\'univers');
  eq(M.validate({ ipMode: 'static', ip: '', fps: 50, protocol: 'sacn', ports: [{ dir: 'out', univOut: 0 }] }).map(x => x.path), ['ip', 'fps', 'ports.0.univOut'], 'validation');

  // ------------------------------------------------------------ firmware
  const nodes = [{ id: '1', model: 4, last: { canon: { firmware: 'Mar 3 2025' } } }, { id: '2', model: 4, last: { canon: { firmware: 'Oct 10 2024' } } }, { id: '3', model: 1, last: { canon: { firmware: 'Jan 15 2024' } } }, { id: '4', model: 4 }];
  const fs = M.firmwareStatus(nodes);
  eq([fs.byNode['1'].status, fs.byNode['2'].status, fs.byNode['3'].status, fs.byNode['4'].status], ['ok', 'old', 'ok', 'unknown'], 'état firmware');
  const fs2 = M.firmwareStatus(nodes, { '1p': 'Mar 3 2025' });
  eq(fs2.byNode['3'].status, 'old', 'référence fixée à la main');

  // ------------------------------------------------------------ fichiers dmx-tools
  const jt = M.toDmxToolsJson(table2);
  ok(jt.ID1_IP0 && jt.ID1_IP3 && jt.ID0, 'export JSON dmx-tools');
  const back2 = M.parseDmxToolsJson(jt, table2);
  eq(back2.find(x => x.index === 1).value, table2.params[1].value, 'import JSON dmx-tools (IP regroupée)');
  eq(M.parseDmxToolsJson({ ID3: '2' }, table2)[0], { index: 3, value: 2, name: undefined }, 'ancien format JSON dmx-tools');

  // ------------------------------------------------------------ DFU
  const fwFile = Sim.SimNode.demoFirmware('Sep 1 2026');
  const pf = D.parseFile(fwFile, 'node.dfu');
  ok(pf.kind === 'dfu' && pf.suffix && pf.suffix.crcOk && pf.suffix.vid === 0x1fc9, 'fichier DFU avec suffixe', pf.suffix);
  const corrupt = fwFile.slice(); corrupt[100] ^= 1;
  ok(!D.parseFile(corrupt, 'x.dfu').suffix.crcOk, 'CRC faux détecté');
  const n6 = Sim.demoFleet()[5];
  const sd = new Sim.SimDfu(n6);
  const ifs = D.findInterfaces(sd.descriptors());
  ok(ifs.length === 1 && ifs[0].func.transferSize === 1024 && ifs[0].func.canDnload, 'descripteur fonctionnel DFU', ifs);
  const dev = new D.Device({ control: async (t, r, v, i, d) => sd.control(t, r, v, i, d) }, { iface: 0, transferSize: ifs[0].func.transferSize });
  let lastP = 0;
  const res = await dev.download(D.flatPayload(pf), p => { lastP = p; });
  ok(res === 'dfuMANIFEST-WAIT-RESET' || res === 'redémarrage', 'téléchargement DFU terminé', res);
  ok(lastP === 1, 'progression jusqu\'à 100 %');
  await U.sleep(80);
  eq(n6.fw, 'Sep 1 2026', 'le node simulé a le nouveau firmware');
  // fichier refusé
  const sd2 = new Sim.SimDfu(Sim.demoFleet()[5]);
  const dev2 = new D.Device({ control: async (t, r, v, i, d) => sd2.control(t, r, v, i, d) }, { iface: 0, transferSize: 1024 });
  let refused = null;
  try { await dev2.download(new Uint8Array(3000).fill(1)); } catch (e) { refused = e.message; }
  ok(refused && /refusé/.test(refused), 'fichier refusé par le node', refused);
  // DfuSe
  const el = new Uint8Array(300).fill(0xab);
  const parts = [];
  const pre = new Uint8Array(11); pre.set(U.utf8('DfuSe'), 0); pre[5] = 1; pre[10] = 1;
  const tgt = new Uint8Array(274); tgt.set(U.utf8('Target'), 0); tgt[6] = 0; tgt.set([1, 0, 0, 0], 7); tgt.set(U.utf8('ST...'), 11);
  tgt.set([1, 0, 0, 0], 270);
  const elh = new Uint8Array(8); elh.set([0x00, 0x00, 0x00, 0x08], 0); elh.set([44, 1, 0, 0], 4);
  parts.push(pre, tgt, elh, el);
  const dfuse = U.concat(parts);
  const pdse = D.parseFile(dfuse, 'fw.dfu');
  ok(pdse.kind === 'dfuse' && pdse.images[0].elements[0].addr === 0x08000000 && pdse.images[0].elements[0].data.length === 300, 'fichier DfuSe', pdse);
  const lay = D.parseDfuseLayout('@Internal Flash  /0x08000000/04*016Kg,01*064Kg,07*128Kg');
  ok(lay && lay.segs.length === 12 && lay.segs[4].start === 0x08010000 && lay.segs[0].erasable, 'plan mémoire DfuSe', lay && lay.segs.slice(0, 5));
  const hex = ':020000040800F2\n:10000000000102030405060708090A0B0C0D0E0F78\n:00000001FF\n';
  const ph = D.parseFile(U.utf8(hex), 'fw.hex');
  ok(ph.kind === 'hex' && ph.images[0].elements[0].addr === 0x08000000 && ph.images[0].elements[0].data[15] === 15, 'fichier Intel HEX', ph.images[0].elements[0]);
  ok(D.check(pf, { vid: 0x1fc9, pid: 0x54, func: ifs[0].func }).filter(x => x.level === 'err').length === 0, 'vérifications DFU ok');

  // ------------------------------------------------------------ table de page web -> modèle (structure 2026)
  const scan = {
    url: 'http://2.0.0.41/', title: 'Node', isLogin: false, buttons: [],
    fields: [
      { key: 'a', kind: 'list', label: 'Protocole', group: 'Paramètres DMX', options: ['sACN (E1.31)', 'Art-Net'], value: 0 },
      { key: 'b', kind: 'list', label: 'Mode', group: 'Configuration DMX 1', options: ['DMX OUT (émission)', 'DMX IN (réception)'], value: 0 },
      { key: 'c', kind: 'number', label: 'Univers OUT (Art-Net)', group: 'Configuration DMX 1', value: '12', min: 0, max: 32767 },
      { key: 'd', kind: 'number', label: 'Univers OUT (sACN)', group: 'Configuration DMX 1', value: '13', min: 1, max: 63999 },
      { key: 'e', kind: 'number', label: 'Priorité sACN', group: 'Configuration DMX 1', value: '100' },
      { key: 'f', kind: 'list', label: 'Mode sortie', group: 'Sortie réseau (global)', options: ['Continue', 'Sur changement', 'Continu (sans arrêt)'], value: 2 },
      { key: 'g', kind: 'number', label: 'FPS max', group: 'Sortie réseau (global)', value: '40' },
      { key: 'h', kind: 'ip', label: 'IP Actuelle', group: 'Paramètres Réseau', value: '2.0.0.41', readonly: true },
      { key: 'i', kind: 'list', label: 'Mode', group: 'Paramètres Réseau', options: ['IP Statique', 'DHCP'], value: 0 },
      { key: 'j', kind: 'ip', label: 'IP statique', group: 'Paramètres Réseau', value: '2.0.0.41' },
      { key: 'k', kind: 'text', label: 'Masque', group: 'Paramètres Réseau', value: '255.0.0.0' },
      { key: 'l', kind: 'text', label: 'Nom long', group: 'Système & Sécurité', value: 'Node Plateau' },
      { key: 'm', kind: 'list', label: 'Page login', group: 'Système & Sécurité', options: ['Désactivée', 'Activée'], value: 1 },
      { key: 'n', kind: 'text', label: 'Firmware', group: 'Système & Sécurité', value: 'Jul 15 2026', readonly: true },
      { key: 'o', kind: 'list', label: 'Univers', group: 'Paramètres DMX', options: ['DMX 1', 'DMX 2'], value: 0 }
    ]
  };
  const wt = S.toTable(scan);
  const wm = M.mapTable(wt);
  const wc = wm.canon;
  eq([wc.protocol, wc.ports[0].dir, wc.ports[0].univOut, wc.ports[0].prio, wc.outMode, wc.fps, wc.ipNow, wc.ipMode, wc.ip, wc.mask, wc.longName, wc.loginPage, wc.firmware],
    ['sacn', 'out', 13, 100, 'fixed_always', 40, '2.0.0.41', 'static', '2.0.0.41', '255.0.0.0', 'Node Plateau', true, 'Jul 15 2026'], 'page 2026 -> réglages communs');
  eq(wm.family, '2026', 'famille 2026 reconnue');
  const wch = M.changesFor(wm, { protocol: 'artnet', ports: [{ univOut: 20 }], outMode: 'change', loginPage: false });
  eq(wch.changes.map(x => [x.param.key, x.value]), [['a', 1], ['c', 20], ['f', 1], ['m', 0]], 'page 2026 : changements (bon champ d\'univers selon le protocole)');

  // ------------------------------------------------------------ autres marques : pages web
  const B = require(J('brands.js'));
  const reA = new RegExp(S.APPLY, 'i'), exA = new RegExp(S.APPLY_EXCLUDE, 'i');
  eq(['Apply', 'Save', 'Save Settings', 'Appliquer', 'Enregistrer les réglages', 'Update', 'Save & Reboot', 'Save Parameters', 'Load Parameters', 'Update Firmware', 'Status Page'].map(t => reA.test(t) && !exA.test(t)),
    [true, true, true, true, true, true, true, false, false, false, false], 'bouton Appliquer reconnu (autres marques) sans les liens de fichiers');
  // petit node chinois : Net / Sub-Net / Universe N, DHCP en case à cocher
  const cn = {
    url: 'http://2.0.0.61/', title: 'Art-Net Node', isLogin: false, fields: [
      { key: 'nn', kind: 'text', label: 'Node Name', group: '', value: 'ARTNET-4' },
      { key: 'dh', kind: 'bool', label: 'DHCP', group: '', value: false },
      { key: 'ip', kind: 'ip', label: 'IP Address', group: '', value: '2.0.0.61' },
      { key: 'mk', kind: 'ip', label: 'Subnet Mask', group: '', value: '255.0.0.0' },
      { key: 'gw', kind: 'ip', label: 'Gateway', group: '', value: '2.0.0.1' },
      { key: 'pr', kind: 'list', label: 'Protocol', group: '', options: ['Art-Net', 'sACN'], value: 0 },
      { key: 'net', kind: 'number', label: 'Net', group: '', value: '0', min: 0, max: 127 },
      { key: 'sub', kind: 'list', label: 'Sub Net', group: '', options: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15'], value: 1 },
      { key: 'm1', kind: 'list', label: 'Port 1 Mode', group: '', options: ['DMX Output', 'DMX Input'], value: 0 },
      { key: 'u1', kind: 'number', label: 'Universe 1', group: '', value: '0', min: 0, max: 15 },
      { key: 'm2', kind: 'list', label: 'Port 2 Mode', group: '', options: ['DMX Output', 'DMX Input'], value: 1 },
      { key: 'u2', kind: 'number', label: 'Universe 2', group: '', value: '3', min: 0, max: 15 }
    ]
  };
  const cm = M.mapTable(S.toTable(cn), { sacnBase: 1 });
  const cc = cm.canon;
  eq([cc.longName, cc.ipMode, cc.ip, cc.mask, cc.gateway, cc.protocol, cm.ports, cc.ports[0].dir, cc.ports[0].univOut, cc.ports[1].dir, cc.ports[1].univIn],
    ['ARTNET-4', 'static', '2.0.0.61', '255.0.0.0', '2.0.0.1', 'artnet', 2, 'out', 16, 'in', 19], 'node chinois : Net/Sub-Net recombinés, DHCP en case, Universe N par port');
  eq(cm.unmapped.length, 0, 'node chinois : tous les champs reconnus');
  const cch = M.changesFor(cm, { ports: [{ univOut: 0x123 }, { univIn: 0x125 }] });
  eq(cch.changes.map(x => [x.param.key, x.value]), [['net', 1], ['sub', 2], ['u1', 3], ['u2', 5]], 'node chinois : univers 15 bits découpé en Net / Sub-Net / Universe');
  const cbad = M.changesFor(cm, { ports: [{ univOut: 0x123 }, { univIn: 0x200 }] });
  ok(cbad.errors.length === 1 && /même bloc de 16/.test(cbad.errors[0]), 'node chinois : univers hors du bloc commun refusé', cbad.errors);
  const cdh = M.changesFor(cm, { ipMode: 'dhcp', protocol: 'sacn', ports: [{ univOut: 7 }] });
  eq(cdh.changes.map(x => [x.param.key, x.value]), [['pr', 1], ['dh', true], ['u1', 7]], 'node chinois : DHCP coché, sACN sur le même champ d\'univers');
  // Enttec ODE : un bloc par port, protocole par port, univers unique
  const od = {
    url: 'http://2.0.0.71/', title: 'ENTTEC ODE MK3', isLogin: false, fields: [
      { key: 'name', kind: 'text', label: 'Node Name', group: 'General', value: 'ODE-Cour' },
      { key: 'p1p', kind: 'list', label: 'Protocol', group: 'Port 1', options: ['Art-Net', 'sACN', 'ESP'], value: 1 },
      { key: 'p1d', kind: 'list', label: 'Direction', group: 'Port 1', options: ['Output', 'Input'], value: 0 },
      { key: 'p1u', kind: 'number', label: 'Universe', group: 'Port 1', value: '21', min: 0, max: 63999 },
      { key: 'p2p', kind: 'list', label: 'Protocol', group: 'Port 2', options: ['Art-Net', 'sACN', 'ESP'], value: 1 },
      { key: 'p2d', kind: 'list', label: 'Direction', group: 'Port 2', options: ['Output', 'Input'], value: 0 },
      { key: 'p2u', kind: 'number', label: 'Universe', group: 'Port 2', value: '22', min: 0, max: 63999 }
    ]
  };
  const om = M.mapTable(S.toTable(od), { sacnBase: 1 });
  eq([om.canon.protocol, om.ports, om.canon.ports[0].univOut, om.canon.ports[1].univOut, om.canon.longName], ['sacn', 2, 21, 22, 'ODE-Cour'], 'Enttec : protocole et univers par port');
  const och = M.changesFor(om, { protocol: 'artnet', ports: [{ univOut: 3 }, { dir: 'in', univIn: 4 }] });
  eq(och.changes.map(x => [x.param.key, x.value]), [['p1p', 0], ['p2p', 0], ['p2d', 1], ['p1u', 3], ['p2u', 4]], 'Enttec : protocole écrit sur chaque port, univers selon le sens');
  // marques
  eq([B.detect({ poll: { oem: 0x29dd } }).id, B.detect({ poll: { oem: 0x04b0 } }).id, B.detect({ poll: { oem: 0xffff, longName: 'ETC Response Mk2', estaMan: 0x6574 } }).id,
    B.detect({ poll: { oem: 0xffff, shortName: 'SnakeSys B4' } }).id, B.detect({ poll: { oem: 0, longName: 'Art-Net Node 4' } }).id, B.detect({ poll: { oem: 0x00ff, longName: 'Node Jardin', estaMan: 0x4345 } }).id,
    B.detect({ usb: { vid: 0x1fc9, pid: 0x52 } }).id, B.detect({ brand: 'ma', poll: { oem: 0x29dd } }).id, B.detect({ poll: { oem: 0x00ff, longName: 'Bidule' } }).id],
    ['luminex', 'ma', 'etc', 'chamsys', 'china', 'electroconcept', 'electroconcept', 'ma', 'generic'], 'marques reconnues (OEM, noms, ESTA, USB, choix manuel)');
  ok(!B.canWrite('etc', 'artnet') && !B.canWrite('ma', 'web') && B.canWrite('china', 'artnet') && !B.canWrite('enttec', 'artnet') && B.canWrite('luminex', 'web'), 'droits d\'écriture par marque');

  console.log(results.join('\n'));
  console.log((fail ? '❌ ' : '✅ ') + pass + ' réussis, ' + fail + ' en échec');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
