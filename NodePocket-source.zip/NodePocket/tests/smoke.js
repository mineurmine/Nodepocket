// Test rapide : l'appli démarre en démo, sans erreur, et les pages s'affichent
const { chromium } = require('playwright');
const path = require('path');
const OUT = process.env.OUT || '/tmp/np-shots';
require('fs').mkdirSync(OUT, { recursive: true });
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 960, height: 540 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve(__dirname, '../app/src/main/assets/index.html'));
  await page.waitForTimeout(800);
  await page.screenshot({ path: OUT + '/01-welcome.png' });
  await page.click('.modal .btn.primary', { timeout: 5000 });
  await page.waitForTimeout(2500);
  await page.screenshot({ path: OUT + '/02-parc.png' });
  for (const p of ['univers', 'lot', 'firmware', 'usb', 'prods', 'moniteur', 'reglages']) {
    await page.click('.nv[data-arg="' + p + '"]');
    await page.waitForTimeout(500);
    await page.screenshot({ path: OUT + '/03-' + p + '.png' });
  }
  await page.click('.nv[data-arg="parc"]');
  await page.waitForTimeout(300);
  await page.click('.card.node >> nth=0');
  await page.waitForTimeout(500);
  await page.screenshot({ path: OUT + '/04-fiche.png' });
  console.log(errors.length ? errors.join('\n') : 'aucune erreur');
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
