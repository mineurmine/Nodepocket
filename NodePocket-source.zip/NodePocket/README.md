# Node Pocket

Appli Android pour gérer un parc de **nodes DMX Electroconcept** (Art-Net / sACN, 1, 2 et 4 univers, PoE) depuis une seule appli : sur le réseau, ou en USB depuis une console portable (Anbernic RG556…) quand le réseau n'est pas encore installé.

## Ce que fait l'appli

- **Parc** : ta liste de nodes en IP fixe, avec leur état en direct (recherche Art-Net automatique et test de la page web). Les nodes inconnus qui répondent sur le réseau sont proposés à l'ajout. « Préparer une série » crée d'un coup des nodes neufs avec leurs adresses, noms et univers à la suite.
- **Fiche d'un node** :
  - tous les réglages (noms, adressage, protocole, sortie DMX et images/s, chaque port, sécurité) ;
  - pour chaque réglage, la valeur **prévue** et la valeur **lue** sur le node, avec les écarts en couleur ;
  - **Lire** et **Appliquer**, puis relecture automatique pour vérifier que le node a bien pris les réglages ;
  - onglets « Tous les paramètres » (y compris ceux que l'appli ne reconnaît pas), « État » (Art-Net en direct) et « Historique ».
- **USB** :
  - le node branché est reconnu par son numéro de série ;
  - « Écrire la config prévue », ou « Le préparer comme… » un node du parc (idéal pour configurer avant le montage) ;
  - interface web embarquée du node (firmwares 2026) ;
  - inspecteur USB.
- **Univers** : plan d'univers du parc. L'appli signale :
  - deux sources sur le même univers ;
  - une IP en double ;
  - un univers de la console qu'aucun node ne sort ;
  - Art-Net 0 et sACN 1 utilisés en même temps (même univers MA).
- **Lot** : protocole, fréquence fixe, adresses IP à la suite, univers à la suite ou décalés, noms, page de login, priorité sACN… sur plusieurs nodes, avec un aperçu avant d'écrire.
- **Firmware** :
  - version de chaque node, comparée à la plus récente du parc (ou à une version de référence) ;
  - mise à jour par USB : passage en DFU, envoi, redémarrage, relecture.
- **Sauvegardes** : la config du parc par production, comparaison avec l'état actuel, remise en un geste. Export / import de toutes les données et feuille de patch CSV.
- **Moniteur** :
  - univers Art-Net et sACN qui passent sur le réseau (sources, images/s, niveaux) ;
  - nodes qui émettent ;
  - test de sortie d'un node sans console.
- **Console portable** :
  - la croix déplace la sélection, ← → change une valeur ;
  - A valide, B retour, X menu, Y lire, Start appliquer, L1/R1 onglets, L2/R2 défilement, Select aide.

## Comment l'appli parle aux nodes

| Chemin | Ce qui passe | Fiabilité |
|---|---|---|
| **USB** | Même protocole que dmx-tools (HID VID 1FC9 / PID 0052, rapports de 64 octets). Le node décrit lui-même ses réglages (groupes, noms, types, min/max) : rien n'est figé dans l'appli. | Relevé dans le code de dmx-tools |
| **Page web** | Pas d'API publiée. L'appli ouvre la page du node en arrière-plan, se connecte si la page de login est activée, lit les champs, les remplit, clique sur « Apply / Appliquer », puis relit la page. | À confirmer sur un vrai node (voir plus bas) |
| **Art-Net** | Recherche (ArtPoll), état des ports en direct, identification (ArtAddress). Écriture standard (ArtAddress, ArtIpProg) si le node la gère. | Norme Art-Net 4 |
| **DFU** | Passage en DFU par le réglage « DFU » du node (comme dmx-tools), puis envoi du fichier selon la norme USB DFU 1.1 / DfuSe. | À confirmer sur un vrai node |

Le firmware n'est pas public : Electroconcept l'envoie sur demande (electroconcept@electroconcept.fr).

**Univers** : l'appli affiche l'univers réseau (Art-Net à partir de 0, sACN à partir de 1) et son équivalent grandMA2 (MA 1 = Art-Net 0 = sACN 1). Sur les anciens firmwares, le champ « Universe » vaut 0 pour l'univers sACN 1 : l'appli convertit toute seule. Le réglage « Numérotation sACN » de la fiche permet de forcer ce choix.

### Si quelque chose ne colle pas avec un vrai node

- **Page web** : Fiche › Tous les paramètres › « Diagnostic de la page web » montre exactement ce que l'appli lit dans la page (libellés, champs, boutons). Partage-le pour que j'ajuste la lecture.
- **USB / DFU** : USB › Inspecteur USB › « Rapport détaillé » donne les descripteurs du node, en mode normal et en mode DFU.
- Dans le doute, l'appli s'arrête sans rien écrire et affiche ce qui manque.

## Compiler l'APK avec GitHub

1. Crée un **nouveau dépôt** sur github.com (privé, c'est très bien). Ne réutilise pas celui de MA2 Pocket : chaque dépôt compile sa propre appli.
2. **Add file → Upload files** : envoie `NodePocket-source.zip` tel quel, puis **Commit**.
3. **Add file → Create new file** : nom `.github/workflows/build.yml`, colle le contenu du fichier `build.yml`, puis **Commit**.
4. Onglet **Actions** : la compilation prend 3 à 5 minutes.
5. Onglet **Releases** : télécharge `NodePocket-v1.0.X.apk` sur la console (ou le téléphone) et installe-le.

Pour une nouvelle version, renvoie le zip (même nom). La clé de signature est fixe : la mise à jour s'installe par-dessus sans perdre le parc.

## Essayer sans node

Ouvre `app/src/main/assets/index.html` dans Chrome : l'appli passe en mode démo avec 8 nodes simulés :
- 7 nodes en IP fixe : classiques, un avec page de login, un « firmware 2026 » ;
- 1 node neuf en DHCP.

Dans Parc › « Outils de démo », tu peux brancher un node en USB, couper un node du réseau et préparer un fichier firmware de démo. Ajoute `?pad=1` à l'adresse pour piloter au clavier comme avec une console (flèches, Entrée = A, Échap = B, x, y, q/e = L1/R1, s = Start, Tab = Select).

## Organisation du code

| Fichier | Rôle |
|---|---|
| `java/fr/nodepocket/MainActivity.java` | Écran, pont JavaScript, fichiers, boutons de la console |
| `java/fr/nodepocket/UsbHub.java` | USB : liste, autorisations, HID, transferts de contrôle (DFU) |
| `java/fr/nodepocket/NetIO.java` | Art-Net (UDP 6454), écoute sACN, HTTP, test de présence |
| `java/fr/nodepocket/PageHost.java` | Pages web des nodes (invisibles ou plein écran) |
| `assets/js/hidproto.js` | Protocole USB des produits Electroconcept (dmx-tools) |
| `assets/js/artnet.js` | Art-Net 4 et sACN |
| `assets/js/model.js` | Réglages communs, plan d'univers, lots, firmware |
| `assets/js/scraper.js` | Lecture / remplissage des pages web des nodes |
| `assets/js/dfu.js` | Mise à jour USB DFU / DfuSe, fichiers .dfu / .bin / .hex |
| `assets/js/ops.js` | Découverte, session USB, lecture / écriture / vérification |
| `assets/js/sim.js` | Nodes simulés (démo et tests) |
| `assets/js/pages/*.js` | Les pages de l'appli |
| `tests/` | `node tests/unit.test.js` (protocoles) et `tests/e2e.js` (parcours complets, Playwright) |
