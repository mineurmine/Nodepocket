/*
 * Node Pocket — pont vers Android (USB, réseau, pages des nodes, fichiers).
 * Dans un navigateur, le même pont fonctionne avec des nodes simulés (mode démo).
 */
(function (root) {
  'use strict';
  const NB = root.AndroidBridge;
  const Bridge = { native: !!NB, demo: !NB };
  root.Bridge = Bridge;

  // Fonctions appelées par Android (window.NP.*) ; l'appli y branche ses propres gestionnaires
  const handlers = {};
  Bridge.on = (name, fn) => { handlers[name] = fn; };
  const fire = (name, ...a) => { if (handlers[name]) { try { return handlers[name](...a); } catch (e) { console.error(e); } } return undefined; };

  let seq = 1;
  const waiting = {};
  root.NP = {
    cb(id, err, res) {
      const w = waiting[id];
      if (!w) return;
      delete waiting[id];
      clearTimeout(w.t);
      if (err) w.reject(new Error(err)); else w.resolve(res);
    },
    usbEvent: (type, d) => fire('usb', type, d),
    udp: (b64, ip, port) => fire('udp', U.fromB64(b64), ip, port),
    netStatus: (state, detail) => fire('netStatus', state, detail),
    pageEvent: (sid, type, d) => fire('page', sid, type, d),
    hwKey: (code, name, down, rep) => fire('key', code, name, !!down, rep),
    hwAxes: a => fire('axes', a),
    onBack: () => !!fire('back'),
    flush: () => fire('flush'),
    toast: m => UI.toast(m)
  };
  function call(timeoutMs, fn) {
    return new Promise((resolve, reject) => {
      const id = seq++;
      waiting[id] = { resolve, reject, t: setTimeout(() => { delete waiting[id]; reject(new Error('délai dépassé')); }, timeoutMs || 15000) };
      try { fn(id); } catch (e) { delete waiting[id]; reject(e); }
    });
  }

  if (NB) {
    // ============================================================ Android
    Bridge.loadState = () => NB.loadState();
    Bridge.saveState = json => NB.saveState(json);
    Bridge.appVersion = () => NB.getAppVersion();
    Bridge.deviceInfo = () => NB.getDeviceInfo();
    Bridge.hasGamepad = () => NB.hasGamepad();
    Bridge.launchUsb = () => NB.launchUsbDevice();
    Bridge.vibrate = ms => NB.vibrate(ms);
    Bridge.keepScreenOn = on => NB.setKeepScreenOn(!!on);
    Bridge.immersive = on => NB.setImmersive(!!on);
    Bridge.orientation = m => NB.setOrientation(m || 'auto');
    Bridge.textInput = on => NB.setTextInputActive(!!on);
    Bridge.exit = () => NB.exitApp();
    Bridge.saveFile = (content, name, mime, isB64) => NB.saveFile(content, name, mime || 'application/json', !!isB64);
    Bridge.pickFile = mime => call(10 * 60 * 1000, id => NB.pickFile(id, mime || '*/*')).then(r => ({ name: r.name, bytes: U.fromB64(r.b64) }));
    Bridge.share = (text, subject) => NB.shareText(text, subject || 'Node Pocket');

    Bridge.netInfo = () => { try { return JSON.parse(NB.netInfo()); } catch (e) { return []; } };
    Bridge.udpStart = () => NB.udpStart();
    Bridge.udpSend = (ip, port, u8) => NB.udpSend(ip, port, U.toB64(u8));
    Bridge.monitor = (on, sacn) => NB.monitor(!!on, (sacn || []).join(','));
    Bridge.monitorSnapshot = () => { try { return JSON.parse(NB.monitorSnapshot()); } catch (e) { return []; } };
    Bridge.http = (method, url, o) => {
      o = o || {};
      const t = o.timeout || 4000;
      return call(t + 3000, id => NB.http(id, method || 'GET', url, JSON.stringify(o.headers || {}), o.body ? U.toB64(o.body) : '', t))
        .then(r => ({ status: r.status, headers: r.headers || {}, body: U.fromB64(r.b64) }));
    };
    Bridge.tcpProbe = (ip, port, timeout) => call((timeout || 1500) + 3000, id => NB.tcpProbe(id, ip, port || 80, timeout || 1500));

    Bridge.usbAvailable = () => NB.usbAvailable();
    Bridge.usbList = () => { try { return JSON.parse(NB.usbList()); } catch (e) { return []; } };
    Bridge.usbPermission = name => NB.usbPermission(name);
    Bridge.hidOpen = name => {
      const h = NB.hidOpen(name);
      if (h < 0) throw new Error(NB.usbLastError() || 'ouverture USB impossible');
      return h;
    };
    Bridge.hidXfer = (h, u8, timeout) => call((timeout || 1000) + 4000, id => NB.hidXfer(id, h, U.hex(u8), timeout || 1000)).then(hex => U.fromHex(hex));
    Bridge.hidFlush = h => call(5000, id => NB.hidFlush(id, h)).catch(() => 0);
    Bridge.usbOpenRaw = (name, iface) => {
      const h = NB.usbOpenRaw(name, iface);
      if (h < 0) throw new Error(NB.usbLastError() || 'ouverture USB impossible');
      return h;
    };
    Bridge.usbRawDescriptors = h => U.fromHex(NB.usbRawDescriptors(h));
    Bridge.usbControl = (h, type, req, value, index, data, length, timeout) =>
      call((timeout || 3000) + 4000, id => NB.usbControl(id, h, type, req, value, index, data ? U.hex(data) : '', length || 0, timeout || 3000))
        .then(r => ((type & 0x80) ? U.fromHex(r) : Number(r)));
    Bridge.usbClose = h => NB.usbClose(h);

    Bridge.pageOpen = (sid, url, user, pass) => NB.pageOpen(sid, url, user || '', pass || '');
    Bridge.pageEval = (sid, js, timeout) => call(timeout || 15000, id => NB.pageEval(id, sid, js));
    Bridge.pageShow = (sid, visible, title) => NB.pageShow(sid, !!visible, title || '');
    Bridge.pageClose = sid => NB.pageClose(sid);
    return;
  }

  // ============================================================ démo (navigateur)
  const SimNet = {
    fleet: Sim.demoFleet(),
    plugged: null,       // index du node branché en USB
    granted: {},
    dfu: null,
    handles: {},
    nextH: 1,
    console: true        // une console envoie de l'Art-Net / sACN
  };
  Bridge.sim = SimNet;
  root.__simNet = SimNet;
  SimNet.fleet.forEach(n => {
    n.onModeChange = mode => {
      if (SimNet.plugged == null || SimNet.fleet[SimNet.plugged] !== n) return;
      const old = SimNet.devName;
      SimNet.gap = true; // le node se réénumère : il disparaît un instant de l'USB
      fire('usb', 'detached', { name: old });
      setTimeout(() => {
        SimNet.gap = false;
        SimNet.devName = '/dev/bus/usb/001/0' + (10 + Math.floor(Math.random() * 80));
        if (mode === 'dfu') SimNet.dfu = new Sim.SimDfu(n);
        else SimNet.dfu = null;
        fire('usb', 'attached', usbDesc());
      }, 400);
    };
  });

  let saved = null;
  try { saved = localStorage.getItem('nodepocket-demo-2'); } catch (e) { /* stockage refusé */ }
  Bridge.loadState = () => saved || '';
  Bridge.saveState = json => { saved = json; try { localStorage.setItem('nodepocket-demo-2', json); } catch (e) { /* rien */ } return true; };
  Bridge.appVersion = () => 'démo';
  Bridge.deviceInfo = () => 'Navigateur (démo) — ' + navigator.userAgent.replace(/^.*?\) /, '').slice(0, 60);
  Bridge.hasGamepad = () => /[?&]pad=1/.test(location.search);
  Bridge.launchUsb = () => '';
  Bridge.vibrate = () => {};
  Bridge.keepScreenOn = () => {};
  Bridge.immersive = () => {};
  Bridge.orientation = () => {};
  Bridge.textInput = () => {};
  Bridge.exit = () => UI.toast('Mode démo : rien à fermer');
  // démo : le fichier est montré (et copiable) au lieu d'être téléchargé
  Bridge.saveFile = (content, name, mime, isB64) => {
    Bridge.lastSaved = { name, content: isB64 ? null : content };
    if (isB64) { UI.toast('Mode démo : « ' + name + ' » serait enregistré sur l\'appareil'); return; }
    UI.dialog({
      title: name, wide: true,
      body: '<p class="muted small">Sur Android, ce fichier est enregistré là où tu veux. Ici, en démo, tu peux le copier.</p><textarea class="pre" readonly rows="14" style="width:100%">' + U.esc(content) + '</textarea>',
      buttons: [{ label: 'Copier', value: 'copy' }, { label: 'Fermer', value: null, kind: 'primary' }],
      onAction: (v, el) => {
        if (v !== 'copy') return true;
        const t = el.querySelector('textarea');
        try { navigator.clipboard.writeText(content).then(() => UI.toast('Copié'), () => { t.select(); UI.toast('Sélectionné : copie-le'); }); } catch (e) { t.select(); }
        return false;
      }
    });
  };
  Bridge.pickFile = function () {
    return new Promise((resolve, reject) => {
      if (Bridge.nextPick) { const p = Bridge.nextPick; Bridge.nextPick = null; resolve(p); return; }
      const inp = document.createElement('input');
      inp.type = 'file';
      inp.onchange = () => {
        const f = inp.files[0];
        if (!f) { reject(new Error('annulé')); return; }
        f.arrayBuffer().then(b => resolve({ name: f.name, bytes: new Uint8Array(b) }));
      };
      inp.click();
    });
  };
  Bridge.share = text => { Bridge.lastShared = text; try { navigator.clipboard.writeText(text); UI.toast('Copié dans le presse-papier'); } catch (e) { UI.toast('Partage indisponible en démo'); } };

  Bridge.netInfo = () => [{ name: 'wlan0', ip: '2.0.0.100', prefix: 8, broadcast: '2.255.255.255' }];
  Bridge.udpStart = () => setTimeout(() => fire('netStatus', 'ready', 'port 6454 (démo)'), 10);
  Bridge.udpSend = (ip, port, u8) => {
    const bcast = /\.255$/.test(ip);
    SimNet.fleet.forEach(n => {
      if (!bcast && n.ipNow !== ip) return;
      const out = n.artnet(u8);
      out.forEach((pkt, i) => setTimeout(() => fire('udp', pkt, n.ipNow, 6454), 15 + Math.random() * 60 + i * 3));
    });
  };
  let monOn = false;
  Bridge.monitor = on => { monOn = on; };
  Bridge.monitorSnapshot = () => {
    if (!monOn || !SimNet.console) return [];
    const t = Date.now() / 1000;
    const list = [];
    const mk = (proto, univ, src, name, prio) => {
      const d = new Uint8Array(512);
      for (let i = 0; i < 512; i++) d[i] = Math.max(0, Math.round(127 + 127 * Math.sin(t * 1.3 + i / 9 + univ)));
      if (univ % 3 === 0) d.fill(0, 64);
      list.push({ proto, univ, src, name, prio, age: 20 + Math.round(Math.random() * 20), frames: Math.round(t * 30), since: 60000, sources: [src + (name ? ' (' + name + ')' : '')], data: U.toB64(d) });
    };
    for (let u = 0; u <= 12; u++) mk('artnet', u, '2.0.0.100', '', -1);
    for (let u = 13; u <= 16; u++) mk('sacn', u, '2.0.0.100', 'grandMA2 onPC', 100);
    list.find(x => x.univ === 4).sources.push('2.0.0.250');
    return list;
  };
  const nodeByIp = ip => SimNet.fleet.find(n => n.ipNow === ip && n.online);
  Bridge.http = (method, url, o) => {
    o = o || {};
    const m = /^https?:\/\/([^/:]+)(?::\d+)?(\/.*)?$/.exec(url);
    const n = m && nodeByIp(m[1]);
    if (!n) return U.sleep(300).then(() => { throw new Error('ConnectException : hôte injoignable'); });
    let body = null;
    if (o.body) { const t = U.utf8dec(o.body); try { body = JSON.parse(t); } catch (e) { body = t; } }
    const r = n.http(method || 'GET', m[2] || '/', body, 'probe', o.headers || {});
    if (!r.status) return U.sleep(300).then(() => { throw new Error('ConnectException : hôte injoignable'); });
    return U.sleep(20).then(() => ({ status: r.status, headers: { 'content-type': r.json ? 'application/json' : 'text/html' }, body: U.utf8(r.json ? JSON.stringify(r.json) : (r.html || '')) }));
  };
  Bridge.tcpProbe = (ip) => U.sleep(15 + Math.random() * 30).then(() => {
    const n = nodeByIp(ip);
    return { open: !!(n && n.mode === 'app'), ms: n ? 3 + Math.round(Math.random() * 6) : 1500 };
  });

  // ---- USB simulé
  function usbDesc() {
    const n = SimNet.plugged == null ? null : SimNet.fleet[SimNet.plugged];
    if (!n || SimNet.gap) return null;
    const name = SimNet.devName;
    if (n.mode === 'dfu') {
      return { name, vid: 0x1fc9, pid: 0x0054, cls: 0, permission: !!SimNet.granted[name], manufacturer: 'NXP', product: 'DFU', interfaces: [{ id: 0, alt: 0, cls: 254, sub: 1, proto: 2, endpoints: [] }] };
    }
    return { name, vid: 0x1fc9, pid: 0x0052, cls: 0, permission: !!SimNet.granted[name], manufacturer: 'Electroconcept', product: n.product, serial: SimNet.granted[name] ? n.serial : undefined, interfaces: [{ id: 0, alt: 0, cls: 3, sub: 0, proto: 0, endpoints: [{ addr: 0x81, type: 3, dir: 'in', max: 64 }, { addr: 0x01, type: 3, dir: 'out', max: 64 }] }] };
  }
  SimNet.plug = function (i) {
    if (SimNet.plugged != null) SimNet.unplug();
    SimNet.plugged = i;
    SimNet.devName = '/dev/bus/usb/001/00' + (2 + i);
    const n = SimNet.fleet[i];
    SimNet.dfu = n.mode === 'dfu' ? new Sim.SimDfu(n) : null;
    fire('usb', 'attached', usbDesc());
  };
  SimNet.unplug = function () {
    if (SimNet.plugged == null) return;
    const name = SimNet.devName;
    SimNet.plugged = null;
    fire('usb', 'detached', { name });
  };
  Bridge.usbAvailable = () => true;
  Bridge.usbList = () => { const d = usbDesc(); return d ? [d] : []; };
  Bridge.usbPermission = name => {
    setTimeout(() => { SimNet.granted[name] = true; fire('usb', 'permission', { name, granted: true }); }, 250);
    return true;
  };
  Bridge.hidOpen = name => {
    const d = usbDesc();
    if (!d || d.name !== name) throw new Error('périphérique absent');
    if (!SimNet.granted[name]) throw new Error('autorisation USB manquante');
    const h = SimNet.nextH++;
    SimNet.handles[h] = { name, kind: 'hid' };
    return h;
  };
  Bridge.hidXfer = (h, u8) => {
    const hd = SimNet.handles[h];
    const n = SimNet.plugged == null ? null : SimNet.fleet[SimNet.plugged];
    if (!hd || !n || hd.name !== SimNet.devName || n.mode !== 'app') return U.sleep(5).then(() => { throw new Error('périphérique USB fermé'); });
    return U.sleep(SimNet.hidDelay == null ? 2 : SimNet.hidDelay).then(() => {
      const r = n.hid(u8);
      // un node qui redémarre (DFU, reset) ne répond plus, comme en vrai
      if (n.mode !== 'app') throw new Error('timeout : le node ne répond pas');
      return r;
    });
  };
  Bridge.hidFlush = () => Promise.resolve(0);
  Bridge.usbOpenRaw = name => {
    const d = usbDesc();
    if (!d || d.name !== name) throw new Error('périphérique absent');
    if (!SimNet.granted[name]) throw new Error('autorisation USB manquante');
    const h = SimNet.nextH++;
    SimNet.handles[h] = { name, kind: 'raw' };
    return h;
  };
  Bridge.usbRawDescriptors = () => (SimNet.dfu ? SimNet.dfu.descriptors() : U.fromHex('1201000200000040c91f5200000101020301'));
  Bridge.usbControl = (h, type, req, value, index, data, length) => U.sleep(1).then(() => {
    const hd = SimNet.handles[h];
    if (!hd || !SimNet.dfu || hd.name !== SimNet.devName) throw new Error('périphérique USB fermé (déconnecté)');
    return SimNet.dfu.control(type, req, value, index, (type & 0x80) ? length : (data || new Uint8Array(0)));
  });
  Bridge.usbClose = h => { delete SimNet.handles[h]; };

  // ---- pages web des nodes simulés (iframes)
  const frames = {};
  function pageHost() {
    let el = document.getElementById('simpages');
    if (!el) {
      el = document.createElement('div');
      el.id = 'simpages';
      el.setAttribute('aria-hidden', 'true');
      document.body.appendChild(el);
    }
    return el;
  }
  function render(sid, method, path, body) {
    const f = frames[sid];
    const n = nodeByIp(f.ip);
    if (!n || n.mode !== 'app') {
      // comme la WebView : page d'erreur à la place de l'ancienne
      fire('page', sid, 'started', { url: 'http://' + f.ip + path });
      setTimeout(() => { f.el.srcdoc = '<h2>Page web inaccessible</h2><p>net::ERR_CONNECTION_TIMED_OUT</p>'; fire('page', sid, 'error', { message: 'net::ERR_CONNECTION_TIMED_OUT' }); }, 400);
      return;
    }
    let r = n.http(method, path, body, sid);
    if (r.status === 302) r = n.http('GET', r.location, null, sid);
    const head = '<script>window.__simIp=' + JSON.stringify(f.ip) + ';window.__simPost=function(p,b){parent.__simNav(' + JSON.stringify(sid) + ',"POST",p,b)};<\/script>';
    let html = r.html || ('<pre>' + JSON.stringify(r.json) + '</pre>');
    html = /<head>/i.test(html) ? html.replace(/<head>/i, '<head>' + head) : head + html;
    f.url = 'http://' + f.ip + path;
    fire('page', sid, 'started', { url: f.url });
    f.el.srcdoc = html;
  }
  root.__simNav = (sid, method, path, body) => setTimeout(() => render(sid, method, path, body), 30);
  root.__simApi = (ip, path) => { const n = nodeByIp(ip); return n ? n.api(path) : null; };
  Bridge.pageOpen = (sid, url) => {
    let f = frames[sid];
    if (!f) {
      const wrap = document.createElement('div');
      wrap.className = 'simpage';
      wrap.innerHTML = '<div class="simbar"><span></span><button type="button">Fermer</button></div><iframe></iframe>';
      pageHost().appendChild(wrap);
      f = frames[sid] = { wrap, el: wrap.querySelector('iframe') };
      wrap.querySelector('button').onclick = () => Bridge.pageShow(sid, false);
      f.el.addEventListener('load', () => {
        try { if (f.el.contentWindow.document.readyState) fire('page', sid, 'finished', { url: f.url }); } catch (e) { /* rien */ }
      });
    }
    const m = /^https?:\/\/([^/:]+)(?::\d+)?(\/.*)?$/.exec(url);
    f.ip = m ? m[1] : '';
    setTimeout(() => render(sid, 'GET', (m && m[2]) || '/', null), 40);
  };
  Bridge.pageEval = (sid, js) => {
    const f = frames[sid];
    if (!f) return Promise.reject(new Error('page fermée'));
    try {
      const v = f.el.contentWindow.eval(js);
      return Promise.resolve(v === undefined ? null : JSON.parse(JSON.stringify(v)));
    } catch (e) {
      return Promise.reject(e);
    }
  };
  Bridge.pageShow = (sid, visible, title) => {
    const f = frames[sid];
    if (!f) return;
    f.wrap.classList.toggle('show', !!visible);
    f.wrap.querySelector('span').textContent = title || f.url || '';
    if (!visible) fire('page', sid, 'hidden', {});
  };
  Bridge.pageVisible = () => Object.keys(frames).find(k => frames[k].wrap.classList.contains('show')) || null;
  Bridge.pageClose = sid => {
    const f = frames[sid];
    if (!f) return;
    f.wrap.remove();
    delete frames[sid];
  };
  Bridge.pageFrame = sid => frames[sid] && frames[sid].el;

  // clavier du navigateur -> mêmes touches que la console portable (pour essayer)
  document.addEventListener('keydown', e => {
    if (!/[?&]pad=1/.test(location.search)) return;
    const map = { ArrowUp: 19, ArrowDown: 20, ArrowLeft: 21, ArrowRight: 22, Enter: 96, Escape: 97, x: 99, y: 100, q: 102, e: 103, a: 104, d: 105, s: 108, Tab: 109 };
    const code = map[e.key];
    if (!code) return;
    if (/^(INPUT|TEXTAREA)$/.test(document.activeElement && document.activeElement.tagName) && code >= 19 && code <= 22 && (e.key === 'ArrowLeft' || e.key === 'ArrowRight') && document.activeElement.type !== 'number') return;
    e.preventDefault();
    root.NP.hwKey(code, 'KEY', 1, e.repeat ? 1 : 0);
  });
  document.addEventListener('keyup', e => {
    if (!/[?&]pad=1/.test(location.search)) return;
    const map = { a: 104, d: 105 };
    if (map[e.key]) root.NP.hwKey(map[e.key], 'KEY', 0, 0);
  });
})(typeof self !== 'undefined' ? self : this);
