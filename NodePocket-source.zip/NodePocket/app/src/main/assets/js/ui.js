/* Node Pocket — briques d'interface : fenêtres, messages, progression, navigation à la croix */
(function (root) {
  'use strict';
  const esc = s => U.esc(s);
  const UI = {};

  // ------------------------------------------------------------ message bref
  let toastTimer = null;
  UI.toast = function (msg, kind) {
    const t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = 'show' + (kind ? ' ' + kind : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.className = ''; }, kind === 'err' ? 4500 : 2600);
  };

  // ------------------------------------------------------------ fenêtres
  const stack = [];
  UI.isOpen = () => stack.length > 0;
  UI.top = () => stack[stack.length - 1] || null;

  /**
   * opts = { title, body (html), buttons:[{label, value, kind:'primary'|'danger'|'', close:true}], wide, onOpen(el), onAction(value, el) -> false pour garder ouvert }
   * Renvoie une promesse résolue avec la valeur du bouton (null si fermé)
   */
  UI.dialog = function (opts) {
    return new Promise(resolve => {
      const wrap = document.createElement('div');
      wrap.className = 'modal';
      const btns = (opts.buttons || [{ label: 'Fermer', value: null }]).map((b, i) =>
        '<button type="button" class="btn ' + (b.kind || '') + '" data-dlg="' + i + '">' + esc(b.label) + '</button>').join('');
      wrap.innerHTML = '<div class="dlg' + (opts.wide ? ' wide' : '') + '" role="dialog">' +
        (opts.title ? '<div class="dlg-h"><span>' + esc(opts.title) + '</span><button type="button" class="x" data-dlg="x" aria-label="Fermer">✕</button></div>' : '') +
        '<div class="dlg-b">' + (opts.body || '') + '</div>' +
        '<div class="dlg-f">' + btns + '</div></div>';
      document.body.appendChild(wrap);
      const entry = { el: wrap, close: v => finish(v), opts };
      stack.push(entry);
      let done = false;
      function finish(v) {
        if (done) return;
        done = true;
        const i = stack.indexOf(entry);
        if (i >= 0) stack.splice(i, 1);
        wrap.remove();
        resolve(v);
        UI.focusFirst();
      }
      wrap.addEventListener('click', async e => {
        const b = e.target.closest('[data-dlg]');
        if (!b) { if (e.target === wrap && opts.dismiss !== false) finish(null); return; }
        if (b.dataset.dlg === 'x') { finish(null); return; }
        const def = opts.buttons[+b.dataset.dlg];
        if (opts.onAction) {
          const r = await opts.onAction(def.value, wrap);
          if (r === false) return;
        }
        finish(def.value);
      });
      if (opts.onOpen) opts.onOpen(wrap, entry);
      setTimeout(() => {
        const first = wrap.querySelector('[autofocus]') || wrap.querySelector('.dlg-b input, .dlg-b select, .dlg-b textarea') || wrap.querySelector('.dlg-f .btn.primary') || wrap.querySelector('.dlg-f .btn');
        if (first) UI.focus(first, true);
      }, 30);
    });
  };

  UI.closeTop = function () {
    const t = UI.top();
    if (!t) return false;
    t.close(null);
    return true;
  };

  UI.alert = (title, html) => UI.dialog({ title, body: '<div class="txt">' + html + '</div>', buttons: [{ label: 'OK', value: true, kind: 'primary' }] });

  UI.confirm = (title, html, okLabel, danger) => UI.dialog({
    title, body: '<div class="txt">' + html + '</div>',
    buttons: [{ label: 'Annuler', value: false }, { label: okLabel || 'OK', value: true, kind: danger ? 'danger' : 'primary' }]
  }).then(v => v === true);

  /** fields = [{ key, label, type:'text'|'number'|'ip'|'select'|'textarea'|'password'|'check', value, options:[[v,l]], hint, placeholder, min, max }] */
  UI.form = function (title, fields, okLabel, opts) {
    const body = '<form class="form" onsubmit="return false">' + fields.map(f => UI.fieldHtml(f)).join('') + '</form>' + ((opts && opts.extra) || '');
    return UI.dialog({
      title, body, wide: opts && opts.wide,
      buttons: [{ label: 'Annuler', value: null }, { label: okLabel || 'OK', value: 'ok', kind: 'primary' }],
      onOpen: opts && opts.onOpen,
      onAction: (v, el) => {
        if (v !== 'ok') return true;
        const vals = UI.readForm(el, fields);
        if (opts && opts.validate) {
          const err = opts.validate(vals);
          if (err) { UI.toast(err, 'err'); return false; }
        }
        el._vals = vals;
        return true;
      }
    }).then(v => (v === 'ok' ? UI._lastVals : null));
  };
  // la valeur lue est mémorisée juste avant la fermeture
  UI.readForm = function (el, fields) {
    const vals = {};
    fields.forEach(f => {
      const x = el.querySelector('[name="' + f.key + '"]');
      if (!x) return;
      if (f.type === 'check') vals[f.key] = x.checked;
      else if (f.type === 'number') vals[f.key] = x.value === '' ? null : Number(x.value);
      else vals[f.key] = x.value;
    });
    UI._lastVals = vals;
    return vals;
  };

  UI.fieldHtml = function (f) {
    const id = 'f_' + f.key;
    const common = 'name="' + esc(f.key) + '" id="' + id + '"' + (f.placeholder ? ' placeholder="' + esc(f.placeholder) + '"' : '') + (f.autofocus ? ' autofocus' : '');
    let input;
    if (f.type === 'select') {
      input = '<select ' + common + '>' + f.options.map(o => '<option value="' + esc(o[0]) + '"' + (String(o[0]) === String(f.value) ? ' selected' : '') + '>' + esc(o[1]) + '</option>').join('') + '</select>';
    } else if (f.type === 'textarea') {
      input = '<textarea ' + common + ' rows="' + (f.rows || 4) + '">' + esc(f.value == null ? '' : f.value) + '</textarea>';
    } else if (f.type === 'check') {
      return '<label class="row check"><input type="checkbox" ' + common + (f.value ? ' checked' : '') + '><span>' + esc(f.label) + '</span>' + (f.hint ? '<small>' + esc(f.hint) + '</small>' : '') + '</label>';
    } else {
      const t = f.type === 'number' ? 'number' : f.type === 'password' ? 'password' : 'text';
      const extra = (f.min != null ? ' min="' + f.min + '"' : '') + (f.max != null ? ' max="' + f.max + '"' : '') + (f.maxlength ? ' maxlength="' + f.maxlength + '"' : '') +
        (f.type === 'ip' || f.type === 'number' ? ' inputmode="decimal"' : '') + (f.type === 'number' ? ' step="' + (f.step || 1) + '"' : '');
      input = '<input type="' + t + '" ' + common + extra + ' value="' + esc(f.value == null ? '' : f.value) + '" autocomplete="off" autocapitalize="off" spellcheck="false">';
    }
    return '<label class="row" for="' + id + '"><span>' + esc(f.label) + '</span>' + input + (f.hint ? '<small>' + esc(f.hint) + '</small>' : '') + '</label>';
  };

  /** Liste de choix ; renvoie la valeur choisie */
  UI.choose = function (title, items, opts) {
    const body = '<div class="choices">' + items.map((it, i) =>
      '<button type="button" class="choice' + (it.danger ? ' danger' : '') + '" data-ch="' + i + '"' + (it.disabled ? ' disabled' : '') + '><b>' + esc(it.label) + '</b>' + (it.hint ? '<small>' + esc(it.hint) + '</small>' : '') + '</button>').join('') + '</div>';
    return new Promise(resolve => {
      let chosen = null;
      UI.dialog({
        title, body, wide: opts && opts.wide, buttons: [{ label: 'Annuler', value: null }],
        onOpen: el => el.querySelector('.choices').addEventListener('click', e => {
          const b = e.target.closest('[data-ch]');
          if (!b) return;
          chosen = items[+b.dataset.ch].value;
          UI.closeTop();
        })
      }).then(() => resolve(chosen));
    });
  };

  // ------------------------------------------------------------ progression
  /** Fenêtre de progression ; renvoie { set(frac, text), log(line, kind), done(title, html), cancelled } */
  UI.progress = function (title, opts) {
    const ctl = { cancelled: false };
    let el = null;
    const p = UI.dialog({
      title, dismiss: false, wide: opts && opts.wide,
      body: '<div class="prog"><div class="bar"><i style="width:0%"></i></div><div class="ptxt">…</div><div class="plog"></div></div>',
      buttons: [{ label: opts && opts.cancelLabel || 'Arrêter', value: 'stop' }],
      onOpen: e => { el = e; },
      onAction: v => {
        if (v === 'stop' && !ctl.finished) { ctl.cancelled = true; ctl.log('Arrêt demandé…', 'warn'); return false; }
        return true;
      }
    });
    ctl.set = (f, txt) => {
      if (!el) return;
      if (f != null) el.querySelector('.bar i').style.width = Math.round(U.clamp(f, 0, 1) * 100) + '%';
      if (txt != null) el.querySelector('.ptxt').textContent = txt;
    };
    ctl.log = (line, kind) => {
      if (!el) return;
      const d = document.createElement('div');
      d.className = 'l ' + (kind || '');
      d.textContent = line;
      const lg = el.querySelector('.plog');
      lg.appendChild(d);
      lg.scrollTop = lg.scrollHeight;
    };
    ctl.done = (txt, kind) => {
      ctl.finished = true;
      if (!el) return;
      ctl.set(1, txt);
      el.querySelector('.ptxt').className = 'ptxt ' + (kind || 'ok');
      const b = el.querySelector('.dlg-f .btn');
      b.textContent = 'Fermer';
      b.classList.add('primary');
      UI.focus(b, true);
    };
    ctl.closed = p;
    return ctl;
  };

  // ------------------------------------------------------------ navigation à la croix (console portable)
  const FOCUSABLE = 'button:not([disabled]), input:not([disabled]):not([type=hidden]), select:not([disabled]), textarea:not([disabled]), [data-act], [tabindex="0"], a[href]';
  UI.padMode = false;

  function visible(el) {
    if (!el.offsetParent && getComputedStyle(el).position !== 'fixed') return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
  }
  function scope() {
    const t = UI.top();
    return t ? t.el : document.getElementById('app');
  }
  function focusables() {
    const s = scope();
    if (!s) return [];
    return Array.from(s.querySelectorAll(FOCUSABLE)).filter(el => !el.closest('[aria-hidden=true]') && visible(el) && !el.closest('.nofocus'));
  }

  UI.focus = function (el, quiet) {
    if (!el) return;
    document.querySelectorAll('.kfocus').forEach(x => x.classList.remove('kfocus'));
    if (UI.padMode) el.classList.add('kfocus');
    if (el.tabIndex < 0 && !/^(BUTTON|INPUT|SELECT|TEXTAREA|A)$/.test(el.tagName)) el.tabIndex = 0;
    try { el.focus({ preventScroll: true }); } catch (e) { el.focus(); }
    // au doigt, la page ne bouge jamais toute seule ; à la croix, l'élément choisi reste visible
    if (!UI.padMode) return;
    const r = el.getBoundingClientRect();
    if (r.top < 60 || r.bottom > innerHeight - 40) el.scrollIntoView({ block: 'center', behavior: quiet ? 'auto' : 'smooth' });
  };
  UI.focusFirst = function () {
    if (!UI.padMode) return;
    const list = focusables();
    const cur = document.activeElement;
    if (cur && list.indexOf(cur) >= 0) { UI.focus(cur, true); return; }
    const notText = e => !/^(INPUT|TEXTAREA|SELECT)$/.test(e.tagName);
    const pref = scope().querySelector('[data-autofocus]') || list.find(e => e.closest('.content') && notText(e)) || list.find(e => e.closest('.content')) || list[0];
    if (pref) UI.focus(pref, true);
  };

  /** Déplace le focus vers l'élément le plus proche dans la direction donnée */
  UI.move = function (dir) {
    const list = focusables();
    if (!list.length) return;
    let cur = document.activeElement;
    if (!cur || list.indexOf(cur) < 0) { UI.focus(list[0]); return; }
    const a = cur.getBoundingClientRect();
    const ax = a.left + a.width / 2, ay = a.top + a.height / 2;
    // d'abord les éléments entièrement dans la direction demandée, sinon les autres
    const pick = strict => {
      let best = null, bestScore = Infinity;
      for (const el of list) {
        if (el === cur || el.contains(cur) || cur.contains(el)) continue;
        const b = el.getBoundingClientRect();
        const bx = b.left + b.width / 2, by = b.top + b.height / 2;
        const dx = bx - ax, dy = by - ay;
        let primary, cross;
        if (dir === 'up') { if (strict ? b.bottom > a.top + 4 : (b.bottom > a.top + 4 && by >= ay)) continue; primary = ay - by; cross = Math.abs(dx); }
        else if (dir === 'down') { if (strict ? b.top < a.bottom - 4 : (b.top < a.bottom - 4 && by <= ay)) continue; primary = by - ay; cross = Math.abs(dx); }
        else if (dir === 'left') { if (strict ? b.right > a.left + 4 : (b.right > a.left + 4 && bx >= ax)) continue; primary = ax - bx; cross = Math.abs(dy); }
        else { if (strict ? b.left < a.right - 4 : (b.left < a.right - 4 && bx <= ax)) continue; primary = bx - ax; cross = Math.abs(dy); }
        if (primary <= 0) continue;
        // recouvrement : favorise les éléments alignés
        const overlap = dir === 'up' || dir === 'down' ? Math.max(0, Math.min(a.right, b.right) - Math.max(a.left, b.left)) : Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
        const score = primary + cross * (overlap > 0 ? 0.3 : 2.2);
        if (score < bestScore) { bestScore = score; best = el; }
      }
      return best;
    };
    const best = pick(true) || pick(false);
    if (best) UI.focus(best);
  };

  /** Action principale sur l'élément sélectionné (bouton A) */
  UI.activate = function () {
    const el = document.activeElement;
    if (!el || el === document.body) { UI.focusFirst(); return; }
    if (el.tagName === 'INPUT' && /^(checkbox|radio)$/.test(el.type)) { el.click(); return; }
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      // ouvre le clavier : sélectionne le texte
      el.blur(); el.focus();
      try { el.select(); } catch (e) { /* champ nombre */ }
      return;
    }
    if (el.tagName === 'SELECT') {
      const n = el.options.length;
      if (n) { el.selectedIndex = (el.selectedIndex + 1) % n; el.dispatchEvent(new Event('change', { bubbles: true })); }
      return;
    }
    el.click();
  };

  /** Croix gauche/droite sur un champ nombre ou une liste : change la valeur */
  UI.adjust = function (delta) {
    const el = document.activeElement;
    if (!el) return false;
    if (el.tagName === 'INPUT' && (el.type === 'number' || el.dataset.num !== undefined)) {
      const step = Number(el.step || 1) * delta;
      let v = Number(el.value || 0) + step;
      if (el.min !== '') v = Math.max(Number(el.min), v);
      if (el.max !== '') v = Math.min(Number(el.max), v);
      el.value = v;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
    if (el.tagName === 'SELECT') {
      const n = el.options.length;
      el.selectedIndex = (el.selectedIndex + delta + n) % n;
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
    if (el.classList.contains('seg-b')) {
      const sibs = Array.from(el.parentElement.querySelectorAll('.seg-b:not([disabled])'));
      const i = sibs.indexOf(el);
      const nx = sibs[(i + delta + sibs.length) % sibs.length];
      if (nx) { nx.click(); UI.focus(nx); }
      return true;
    }
    return false;
  };

  // ------------------------------------------------------------ boutons segmentés (choix courts)
  UI.seg = function (name, options, value, attrs) {
    return '<div class="seg" data-seg="' + esc(name) + '" ' + (attrs || '') + '>' + options.map(o =>
      '<button type="button" class="seg-b' + (String(o[0]) === String(value) ? ' on' : '') + '" data-v="' + esc(o[0]) + '" data-fid="seg_' + esc(name) + '_' + esc(o[0]) + '"' + (o[2] ? ' title="' + esc(o[2]) + '"' : '') + '>' + esc(o[1]) + '</button>').join('') + '</div>';
  };

  UI.badge = (txt, kind, title) => '<span class="badge ' + (kind || '') + '"' + (title ? ' title="' + esc(title) + '"' : '') + '>' + esc(txt) + '</span>';
  UI.dot = (kind, title) => '<i class="dot ' + (kind || '') + '"' + (title ? ' title="' + esc(title) + '"' : '') + '></i>';

  if (typeof module !== 'undefined' && module.exports) module.exports = UI;
  else root.UI = UI;
})(typeof self !== 'undefined' ? self : this);
