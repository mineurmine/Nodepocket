/*
 * Node Pocket — modèle commun des réglages d'un node.
 *
 * Les nodes décrivent eux-mêmes leurs réglages (USB) ou les affichent dans leur page web (réseau),
 * avec des libellés qui changent selon le firmware ("Long Device Name", "Nom long"…).
 * Ce module reconnaît ces libellés et les ramène à des réglages communs (« canoniques »),
 * pour comparer, planifier et modifier tous les nodes de la même façon.
 *
 * Univers : la valeur canonique est l'univers réellement utilisé sur le réseau
 *   - Art-Net : adresse 15 bits à partir de 0 (comme le champ du node)
 *   - sACN    : numéro d'univers sACN à partir de 1 (239.255.0.1 = univers 1)
 *   Les anciens firmwares n'ont qu'un champ, numéroté à partir de 0 aussi en sACN : on convertit.
 */
(function (root) {
  'use strict';
  const U = root.U || (typeof require !== 'undefined' ? require('./util.js') : null);

  const M = {};
  M.T = { NUMBER: 0, STRING: 1, IP: 2, OTHER: 3, LIST: 4, RO: 5, BOOL: 6 };

  // ------------------------------------------------------------ réglages communs
  M.FIELDS = [
    { key: 'longName', label: 'Nom long', kind: 'text', max: 63, section: 'ident' },
    { key: 'shortName', label: 'Nom court', kind: 'text', max: 17, section: 'ident' },
    { key: 'ipMode', label: 'Adressage', kind: 'enum', values: [['static', 'IP fixe'], ['dhcp', 'DHCP']], section: 'net' },
    { key: 'ip', label: 'Adresse IP', kind: 'ip', section: 'net' },
    { key: 'mask', label: 'Masque', kind: 'ip', section: 'net' },
    { key: 'gateway', label: 'Passerelle', kind: 'ip', section: 'net' },
    { key: 'protocol', label: 'Protocole', kind: 'enum', values: [['artnet', 'Art-Net'], ['sacn', 'sACN']], section: 'dmx' },
    { key: 'maxUniv', label: 'Nombre d\'univers', kind: 'number', section: 'dmx' },
    { key: 'outMode', label: 'Sortie DMX', kind: 'enum', values: [['sync', 'Synchro sur le flux'], ['fixed', 'Fréquence fixe'], ['fixed_always', 'Fixe, sans arrêt'], ['change', 'Sur changement']], section: 'dmx' },
    { key: 'fps', label: 'Images / s', kind: 'number', min: 16, max: 44, section: 'dmx' },
    { key: 'loginPage', label: 'Page de login', kind: 'bool', section: 'sec' },
    { key: 'login', label: 'Utilisateur', kind: 'text', max: 32, section: 'sec' },
    { key: 'pass', label: 'Mot de passe', kind: 'text', max: 32, secret: true, section: 'sec' },
    { key: 'firmware', label: 'Firmware', kind: 'ro', section: 'info' },
    { key: 'serial', label: 'N° de série', kind: 'ro', section: 'info' },
    { key: 'ipNow', label: 'IP actuelle', kind: 'ro', section: 'info' }
  ];
  M.PORT_FIELDS = [
    { key: 'dir', label: 'Sens', kind: 'enum', values: [['out', 'Sortie DMX'], ['in', 'Entrée DMX']] },
    { key: 'univOut', label: 'Univers reçu', kind: 'univ', hint: 'univers écouté sur le réseau et envoyé sur la XLR' },
    { key: 'univIn', label: 'Univers envoyé', kind: 'univ', hint: 'univers envoyé sur le réseau depuis l\'entrée XLR' },
    { key: 'prio', label: 'Priorité sACN', kind: 'number', min: 0, max: 200 },
    { key: 'castIp', label: 'IP d\'envoi', kind: 'ip', hint: 'destination du flux de l\'entrée XLR' },
    { key: 'sacnMode', label: 'Mode sACN', kind: 'enum', values: [['multicast', 'Multicast'], ['unicast', 'Unicast']] }
  ];
  M.SECTIONS = { ident: 'Identité', net: 'Réseau', dmx: 'DMX', sec: 'Sécurité', info: 'Infos' };
  M.fieldDef = function (path) {
    const m = /^ports\.(\d+)\.(\w+)$/.exec(path);
    if (m) return M.PORT_FIELDS.find(f => f.key === m[2]);
    return M.FIELDS.find(f => f.key === path);
  };
  M.pathLabel = function (path) {
    const m = /^ports\.(\d+)\.(\w+)$/.exec(path);
    if (m) {
      const f = M.PORT_FIELDS.find(x => x.key === m[2]);
      return 'DMX ' + (+m[1] + 1) + ' · ' + (f ? f.label : m[2]);
    }
    const f = M.FIELDS.find(x => x.key === path);
    return f ? f.label : ({ artNet: 'Net Art-Net', artSub: 'Sub-Net Art-Net' }[path] || path);
  };
  M.enumLabel = function (path, v) {
    const f = M.fieldDef(path);
    if (!f) return v;
    if (f.kind === 'bool') return v ? 'Oui' : 'Non';
    if (f.values) {
      const x = f.values.find(e => e[0] === v);
      if (x) return x[1];
    }
    return v;
  };

  // ------------------------------------------------------------ reconnaissance des libellés
  const OPT = {
    ipMode: [['dhcp', /dhcp|auto/], ['static', /stati|fixe|manu/]],
    protocol: [['sacn', /sacn|e1\.?31|\bacn\b/], ['artnet', /art.?net/]],
    outMode: [['fixed_always', /sans arr|non.?stop|always|toujours/], ['change', /changement|on change|delta/], ['sync', /sync|transparen/], ['fixed', /fix|continu/]],
    dir: [['out', /\bout|output|emission|sortie|\btx\b/], ['in', /\bin\b|input|reception|entree|\brx\b/]],
    sacnMode: [['multicast', /multi/], ['unicast', /uni/]],
    bool: [[false, /^no\b|^non\b|desactiv|disabl|^off\b|inactif|^0$/], [true, /^yes\b|^oui\b|activ|enabl|^on\b|actif|^1$/]],
    action: [[false, /^no\b|^non\b|^off\b|^0$|annul|normal/], [true, /^yes\b|^oui\b|^on\b|^1$|go|lancer|reset|dfu/]]
  };
  M.OPT = OPT;

  /** valeur canonique d'une option affichée par le node */
  M.optToCanon = function (kind, text) {
    const t = U.norm(text);
    const list = OPT[kind];
    if (!list) return null;
    for (const [v, re] of list) if (re.test(t)) return v;
    return null;
  };
  /** index de l'option du node qui correspond à une valeur canonique (ou -1) */
  M.canonToOpt = function (kind, options, value) {
    const list = OPT[kind];
    if (!list) return -1;
    for (let i = 0; i < options.length; i++) {
      if (M.optToCanon(kind, options[i]) === value) return i;
    }
    return -1;
  };

  const GLOBAL_RULES = [
    { key: 'ipNow', l: /\bip ?now\b|ip actuelle|current ip|ip courante|ip en cours/ },
    { key: 'firmware', l: /firmware|version/ },
    { key: 'serial', l: /serial|\bserie\b|numero de serie|\bs\/n\b/ },
    { key: 'shortName', l: /short.*name|nom court/ },
    { key: 'longName', l: /long.*name|nom long|^nom$|^name$|device name|node name|nom du (node|produit|boitier)|hostname|nom de l.appareil/ },
    { key: 'ipMode', opt: /dhcp/ },
    { key: 'ipMode', l: /dhcp/ },
    { key: 'mask', l: /mask|masque/ },
    { key: 'gateway', l: /gateway|passerelle/ },
    { key: 'artSub', l: /^sub ?-?net$|^sub ?switch$|^sub-?uni(verse)?$|^sous-?reseau art/ },
    { key: 'artNet', l: /^net$|^net ?switch$|^art-?net net$|^net \(0/ },
    { key: 'ip', l: /\bip\b|adresse ip/, not: /now|actuelle|courante|cast|sortie|\bout\b|multicast|\bpc\b|mask|masque|gateway|passerelle|login|server|serveur/ },
    { key: 'maxUniv', l: /max.*univ|nombre d.?univers|total univ/ },
    { key: 'protocol', l: /protoco/, opt: /art.?net|sacn|e1\.?31/ },
    { key: 'fps', l: /\bfps\b|frequence|refresh|images? ?\/ ?s|frame ?rate/ },
    { key: 'outMode', l: /^dmx out$|mode sortie|mode de sortie|sortie reseau|output mode|dmx out mode|^sortie$|output style/ },
    { key: 'loginPage', l: /login page|page login|page de login|authentif|page de connexion/ },
    { key: 'login', l: /^login$|utilisateur|^user|username|identifiant/ },
    { key: 'pass', l: /pass|mot de passe/ },
    { key: 'reset', l: /reset|usine|factory/ },
    { key: 'dfu', l: /\bdfu\b|bootloader/ }
  ];
  const PORT_RULES = [
    { key: 'sacnMode', l: /mode sacn|sacn mode/ },
    { key: 'sacnMode', opt: /multicast/ },
    { key: 'univOut', l: /univ\w*\s*out|univers (de )?sortie|out(put)? univ|univ\w* recu/ },
    { key: 'univIn', l: /univ\w*\s*in\b|univers (d.)?entree|in(put)? univ|univ\w* envoye/ },
    { key: 'univ', l: /^univers(e)?\b|^dmx universe|^port universe|^univ\.?$/, not: /\b(out|in|sortie|entree|recu|envoye)\b|select|choix/ },
    { key: 'prio', l: /priorit/ },
    { key: 'protocol', l: /protoco/, opt: /art.?net|sacn|e1\.?31/ },
    { key: 'castIp', l: /ip ?cast|cast out|ip sortie|ip (de )?destination|ip out|ip d.envoi/, not: /multicast/ },
    { key: 'dir', l: /^dmx$|^mode$|direction|^sens$|^dmx \d+$|^xlr$|port mode|^type$|^port type$/, optAll: [/\bout|output|emission|sortie/, /\bin\b|input|reception|entree/] },
    { key: 'dir', optAll: [/\bout|output|emission/, /\bin\b|input|reception/] }
  ];

  function portOf(groupName, label, numberedGroups) {
    const g = U.norm(groupName);
    let m = /(?:dmx|port|xlr|univers|universe|sortie|output)\s*(\d+)/.exec(g);
    if (m && +m[1] >= 1 && +m[1] <= 16) return +m[1] - 1;
    const l = U.norm(label);
    m = /(?:dmx|port|xlr)\s*(\d+)/.exec(l);
    if (m && +m[1] >= 1 && +m[1] <= 16) return +m[1] - 1;
    // "Universe 1", "Universe 2"… : un champ par port
    m = /^univers(?:e)?\s*(\d+)$/.exec(l);
    if (m && +m[1] >= 1 && +m[1] <= 16) return +m[1] - 1;
    if (!numberedGroups && /\bdmx\b|ports?|xlr/.test(g)) return 0;
    return null;
  }

  function matchRule(rule, label, options) {
    if (rule.l && !rule.l.test(label)) return false;
    if (rule.not && rule.not.test(label)) return false;
    if (rule.opt && !(options || []).some(o => rule.opt.test(U.norm(o)))) return false;
    if (rule.optAll && !rule.optAll.every(re => (options || []).some(o => re.test(U.norm(o))))) return false;
    return true;
  }

  function variantOf(label) {
    const l = U.norm(label);
    if (/sacn|e1\.?31/.test(l)) return 'sacn';
    if (/art.?net/.test(l)) return 'artnet';
    return null;
  }

  /**
   * Associe une table de paramètres (USB ou page web) aux réglages communs.
   * table = { name, groups:[{index,name}], params:[{index,key?,group,type,label,options,value,min,max,readonly}] }
   * opts.sacnBase : 'auto' | 0 | 1 (numérotation sACN des champs d'univers uniques)
   *
   * Cas gérés en plus des champs simples :
   *  - un seul champ « Universe » par port (servant en entrée et en sortie)
   *  - un protocole par port (Enttec, Luminex…) : écrit sur tous les ports
   *  - Art-Net en Net / Sub-Net / Universe (petits nodes) : recombiné en adresse 15 bits
   */
  M.mapTable = function (table, opts) {
    opts = opts || {};
    const groups = {};
    (table.groups || []).forEach(g => { groups[g.index] = g.name; });
    const numberedGroups = (table.groups || []).filter(g => /(?:dmx|port|xlr)\s*\d/.test(U.norm(g.name))).length > 0;
    const refs = {};
    const used = {};
    const unmapped = [];
    const actions = {};
    const netsub = {};
    let ports = 0;
    const add = (path, ref, idx) => {
      const list = refs[path] = refs[path] || [];
      if (list.some(x => x.variant === ref.variant)) return false;
      list.push(ref);
      used[idx] = used[idx] || path;
      return true;
    };

    for (const p of table.params || []) {
      const label = U.norm(p.label);
      const gname = groups[p.group] != null ? groups[p.group] : (p.groupName || '');
      const port = portOf(gname, p.label, numberedGroups);
      let hit = null;
      if (port != null) {
        for (const r of PORT_RULES) if (matchRule(r, label, p.options)) { hit = { key: r.key, port }; break; }
      }
      if (!hit) {
        for (const r of GLOBAL_RULES) if (matchRule(r, label, p.options)) { hit = { key: r.key, port: null }; break; }
      }
      if (!hit) { unmapped.push(p.index); continue; }
      if (hit.key === 'reset' || hit.key === 'dfu') {
        if (actions[hit.key] == null) actions[hit.key] = p.index;
        continue;
      }
      if (hit.key === 'artNet' || hit.key === 'artSub') {
        if (netsub[hit.key] == null) { netsub[hit.key] = p.index; used[p.index] = hit.key; } else unmapped.push(p.index);
        continue;
      }
      if (hit.port != null && hit.key !== 'protocol') ports = Math.max(ports, hit.port + 1);
      if (hit.key === 'protocol' && hit.port != null) {
        // protocole par port : même réglage commun pour tous les ports
        if (!add('protocol', { index: p.index, variant: 'p' + hit.port, perPort: true }, p.index)) unmapped.push(p.index);
        continue;
      }
      if (hit.key === 'univ') {
        // un seul champ d'univers pour le port, quel que soit le sens
        const a = add('ports.' + hit.port + '.univOut', { index: p.index, variant: null, shared: true }, p.index);
        const b = add('ports.' + hit.port + '.univIn', { index: p.index, variant: null, shared: true }, p.index);
        if (!a && !b) unmapped.push(p.index);
        continue;
      }
      const path = hit.port != null ? 'ports.' + hit.port + '.' + hit.key : hit.key;
      const variant = (hit.key === 'univOut' || hit.key === 'univIn' || hit.key === 'castIp') ? variantOf(p.label) : null;
      if (!add(path, { index: p.index, variant }, p.index)) unmapped.push(p.index);
    }

    const byIndex = {};
    (table.params || []).forEach(p => { byIndex[p.index] = p; });
    let sacnBase = opts.sacnBase;
    if (sacnBase == null || sacnBase === 'auto') {
      // champs uniques des anciens firmwares Electroconcept : 0 = 239.255.0.1 (sauf si le champ commence à 1)
      const uf = Object.keys(refs).filter(k => /univ(Out|In)$/.test(k)).map(k => refs[k].find(x => !x.variant)).filter(Boolean);
      sacnBase = uf.length && uf.every(x => byIndex[x.index] && byIndex[x.index].min >= 1) ? 1 : 0;
    }

    const res = { refs, used, unmapped, actions, ports, sacnBase: +sacnBase, byIndex, product: table.name || '', netsub: (netsub.artNet != null || netsub.artSub != null) ? netsub : null };
    res.canon = M.readCanon(res);
    res.family = (table.params || []).some(p => /^(nom long|nom court|ip statique|mode sortie)$/.test(U.norm(p.label))) ? '2026' : 'classique';
    return res;
  };

  function nsVal(mapped, k) {
    const i = mapped.netsub && mapped.netsub[k];
    if (i == null) return 0;
    const p = mapped.byIndex[i];
    return (p.type === M.T.LIST ? Number(p.options[p.value]) : Number(p.value)) || 0;
  }
  /** valeur brute d'un champ Net / Sub-Net (liste de nombres ou nombre) */
  function nsRaw(p, v) {
    if (p.type !== M.T.LIST) return v;
    const i = p.options.findIndex(o => Number(o) === v);
    return i < 0 ? v : i;
  }

  function rawToCanon(mapped, path, p, protocol) {
    const key = path.split('.').pop();
    const def = M.fieldDef(path) || { kind: 'text' };
    let v = p.value;
    if (p.type === M.T.LIST) {
      const text = p.options[v] != null ? p.options[v] : '';
      if (key === 'ipMode' && M.optToCanon('ipMode', text) == null && M.optToCanon('bool', text) != null) return M.optToCanon('bool', text) ? 'dhcp' : 'static';
      if (def.kind === 'enum') return M.optToCanon(key === 'ipMode' || key === 'protocol' || key === 'outMode' || key === 'dir' || key === 'sacnMode' ? key : 'bool', text);
      if (def.kind === 'bool') return M.optToCanon('bool', text);
      if (def.kind === 'number' || def.kind === 'univ') return Number(text);
      return text;
    }
    if (p.type === M.T.BOOL) {
      if (key === 'ipMode') return v ? 'dhcp' : 'static';
      return !!v;
    }
    if (def.kind === 'bool') return !!Number(v);
    if (def.kind === 'univ') {
      const n = Number(v);
      const ref = (mapped.refs[path] || []).find(r => r.index === p.index);
      if (protocol === 'sacn' && ref && !ref.variant && mapped.sacnBase === 0) return n + 1;
      if (protocol !== 'sacn' && mapped.netsub && ref && !ref.variant && n >= 0 && n <= 15) return ((nsVal(mapped, 'artNet') & 0x7f) << 8) | ((nsVal(mapped, 'artSub') & 15) << 4) | n;
      return n;
    }
    if (def.kind === 'number') return Number(v);
    if (def.kind === 'enum' && p.type === M.T.NUMBER) {
      // valeur numérique brute pour un choix : 0/1 -> premier/second choix connu
      return def.values[Number(v)] ? def.values[Number(v)][0] : null;
    }
    return v == null ? '' : String(v);
  }

  function pickRef(mapped, path, protocol) {
    const list = mapped.refs[path];
    if (!list || !list.length) return null;
    if (list.length === 1) return list[0];
    return list.find(r => r.variant === protocol) || list.find(r => !r.variant) || list[0];
  }

  /** Réglages communs actuels d'après la table associée */
  M.readCanon = function (mapped) {
    const c = { ports: [] };
    const protoRef = pickRef(mapped, 'protocol');
    if (protoRef) c.protocol = rawToCanon(mapped, 'protocol', mapped.byIndex[protoRef.index]);
    for (const path of Object.keys(mapped.refs)) {
      if (path === 'protocol') continue;
      const ref = pickRef(mapped, path, c.protocol);
      const p = mapped.byIndex[ref.index];
      const val = rawToCanon(mapped, path, p, c.protocol);
      M.setPath(c, path, val);
    }
    for (let i = 0; i < mapped.ports; i++) c.ports[i] = c.ports[i] || {};
    return c;
  };

  /**
   * Changements à envoyer au node pour atteindre la config "target" (partielle).
   * Renvoie { changes:[{param, value, path}], missing:[path], errors:[texte] }
   */
  M.changesFor = function (mapped, target) {
    const out = { changes: [], missing: [], errors: [] };
    const current = mapped.canon;
    const flatT = M.flat(target);
    const protocol = flatT.protocol || current.protocol;
    const seen = {};
    const ns = {};
    const push = (p, value, path) => {
      if (seen[p.index] != null) return;
      seen[p.index] = 1;
      const same = p.type === M.T.STRING || p.type === M.T.RO ? String(p.value) === String(value) : U.same(p.value, value);
      if (!same) out.changes.push({ param: p, value, path });
    };
    const dirOf = i => flatT['ports.' + i + '.dir'] || ((current.ports || [])[i] || {}).dir || 'out';

    const one = (path, want, ref) => {
      const def = M.fieldDef(path);
      const p = mapped.byIndex[ref.index];
      if (p.readonly) { out.missing.push(path); return; }
      const key = path.split('.').pop();
      let raw;
      if (p.type === M.T.LIST) {
        let idx = -1;
        if (def.kind === 'enum') idx = M.canonToOpt(key, p.options, want);
        else if (def.kind === 'bool') idx = M.canonToOpt('bool', p.options, !!want);
        else idx = p.options.findIndex(o => U.same(o, want));
        // « DHCP : Enabled / Disabled », « DHCP : On / Off »
        if (idx < 0 && key === 'ipMode') idx = M.canonToOpt('bool', p.options, want === 'dhcp');
        if (idx < 0) { out.errors.push(M.pathLabel(path) + ' : « ' + M.enumLabel(path, want) + ' » n\'existe pas sur ce node (' + p.options.join(', ') + ')'); return; }
        raw = idx;
      } else if (p.type === M.T.BOOL) {
        raw = key === 'ipMode' ? want === 'dhcp' : !!want;
      } else if (def.kind === 'bool') {
        raw = want ? 1 : 0;
      } else if (def.kind === 'univ') {
        let n = Number(want);
        if (protocol === 'sacn' && !ref.variant && mapped.sacnBase === 0) n -= 1;
        if (protocol === 'sacn' && n < (ref.variant || mapped.sacnBase === 1 ? 1 : 0)) { out.errors.push(M.pathLabel(path) + ' : l\'univers sACN 0 n\'existe pas (minimum 1)'); return; }
        if (protocol !== 'sacn' && mapped.netsub && !ref.variant) {
          // Net / Sub-Net / Universe : les ports partagent Net et Sub-Net
          const net = (n >> 8) & 0x7f, sub = (n >> 4) & 15;
          if ((ns.net != null && ns.net !== net) || (ns.sub != null && ns.sub !== sub)) {
            out.errors.push(M.pathLabel(path) + ' : sur ce node, tous les ports restent dans le même bloc de 16 univers (Net ' + ns.net + ', Sub-Net ' + ns.sub + ')');
            return;
          }
          ns.net = net; ns.sub = sub;
          if (mapped.netsub.artNet != null) push(mapped.byIndex[mapped.netsub.artNet], nsRaw(mapped.byIndex[mapped.netsub.artNet], net), 'artNet');
          else if (net !== 0) { out.errors.push(M.pathLabel(path) + ' : univers ' + n + ' impossible (pas de réglage Net sur ce node)'); return; }
          if (mapped.netsub.artSub != null) push(mapped.byIndex[mapped.netsub.artSub], nsRaw(mapped.byIndex[mapped.netsub.artSub], sub), 'artSub');
          else if (sub !== 0) { out.errors.push(M.pathLabel(path) + ' : univers ' + n + ' impossible (pas de réglage Sub-Net sur ce node)'); return; }
          n = n & 15;
        }
        raw = n;
      } else if (def.kind === 'number') {
        raw = Number(want);
      } else if (def.kind === 'enum') {
        const i = def.values.findIndex(e => e[0] === want);
        raw = i < 0 ? 0 : i;
      } else {
        raw = String(want);
      }
      if (p.type === M.T.NUMBER && p.max > p.min && (raw < p.min || raw > p.max)) {
        out.errors.push(M.pathLabel(path) + ' : ' + raw + ' hors limites (' + p.min + ' à ' + p.max + ')');
        return;
      }
      if (p.type === M.T.STRING && p.maxLen && U.utf8(String(raw)).length > p.maxLen && p.maxLen > 1) {
        out.errors.push(M.pathLabel(path) + ' : ' + p.maxLen + ' caractères maximum');
        return;
      }
      push(p, raw, path);
    };

    // le protocole d'abord : il décide quels champs d'univers écrire ; les sens avant les univers
    const rank = k => (k === 'protocol' ? 0 : /\.dir$/.test(k) ? 1 : 2);
    const order = Object.keys(flatT).sort((a, b) => rank(a) - rank(b));
    for (const path of order) {
      const want = flatT[path];
      if (want === undefined || want === null || want === '') continue;
      const def = M.fieldDef(path);
      if (!def || def.kind === 'ro') continue;
      if (path === 'protocol' && (mapped.refs.protocol || []).some(r => r.perPort)) {
        mapped.refs.protocol.forEach(r => one(path, want, r));
        continue;
      }
      const ref = pickRef(mapped, path, protocol);
      if (!ref) { out.missing.push(path); continue; }
      if (ref.shared) {
        // champ d'univers commun : n'écrire que celui qui correspond au sens du port
        const m = /^ports\.(\d+)\.(univOut|univIn)$/.exec(path);
        if (m && ((m[2] === 'univOut') !== (dirOf(+m[1]) !== 'in'))) continue;
      }
      one(path, want, ref);
    }
    return out;
  };

  /** Valeurs brutes d'un paramètre de type liste pour une action (reset/dfu) */
  M.actionValue = function (p, on) {
    if (p.type === M.T.LIST) {
      const i = M.canonToOpt('action', p.options, !!on);
      return i >= 0 ? i : (on ? 1 : 0);
    }
    return on ? 1 : 0;
  };

  // ------------------------------------------------------------ chemins
  M.flat = function (canon) {
    const out = {};
    if (!canon) return out;
    Object.keys(canon).forEach(k => {
      if (k === 'ports') {
        (canon.ports || []).forEach((p, i) => {
          if (!p) return;
          Object.keys(p).forEach(pk => { if (p[pk] !== undefined) out['ports.' + i + '.' + pk] = p[pk]; });
        });
      } else if (k[0] !== '_' && canon[k] !== undefined) out[k] = canon[k];
    });
    return out;
  };
  M.getPath = function (canon, path) {
    if (!canon) return undefined;
    const m = /^ports\.(\d+)\.(\w+)$/.exec(path);
    if (m) return canon.ports && canon.ports[+m[1]] ? canon.ports[+m[1]][m[2]] : undefined;
    return canon[path];
  };
  M.setPath = function (canon, path, v) {
    const m = /^ports\.(\d+)\.(\w+)$/.exec(path);
    if (m) {
      canon.ports = canon.ports || [];
      for (let i = 0; i <= +m[1]; i++) canon.ports[i] = canon.ports[i] || {};
      if (v === undefined) delete canon.ports[+m[1]][m[2]];
      else canon.ports[+m[1]][m[2]] = v;
    } else if (v === undefined) delete canon[path];
    else canon[path] = v;
    return canon;
  };
  M.unflat = function (flat) {
    const c = {};
    Object.keys(flat).forEach(k => M.setPath(c, k, flat[k]));
    return c;
  };

  /** Différences entre la config voulue (partielle) et la config lue */
  M.diff = function (want, have) {
    const fw = M.flat(want), out = [];
    Object.keys(fw).forEach(path => {
      const def = M.fieldDef(path);
      if (!def || def.kind === 'ro') return;
      const a = fw[path], b = M.getPath(have, path);
      if (a === undefined || a === null || a === '') return;
      if (!U.same(a, b)) out.push({ path, label: M.pathLabel(path), want: a, have: b });
    });
    return out;
  };

  // ------------------------------------------------------------ vérifications
  /** Problèmes d'une config (voulue ou lue). ctx = { ports, sacnBase } */
  M.validate = function (c, ctx) {
    ctx = ctx || {};
    const out = [];
    const add = (level, path, msg) => out.push({ level, path, msg });
    if (!c) return out;
    if (c.longName != null && U.utf8(String(c.longName)).length > 63) add('err', 'longName', 'Nom long : 63 caractères maximum');
    if (c.shortName != null && U.utf8(String(c.shortName)).length > 17) add('err', 'shortName', 'Nom court : 17 caractères maximum');
    if (/[^\x20-\x7e]/.test(String(c.longName || '') + String(c.shortName || ''))) add('warn', 'longName', 'Évite les accents dans les noms (affichage Art-Net)');
    if (c.ipMode === 'static') {
      if (!U.isIp(c.ip)) add('err', 'ip', 'Adresse IP fixe manquante ou invalide');
      if (c.mask != null && !U.isMask(c.mask)) add('err', 'mask', 'Masque invalide');
    } else if (c.ip != null && c.ip !== '' && !U.isIp(c.ip)) add('err', 'ip', 'Adresse IP invalide');
    if (U.isIp(c.ip) && /\.(0|255)$/.test(c.ip) && U.isMask(c.mask || '255.255.255.0') && U.ipToInt(c.mask || '255.255.255.0') >= U.ipToInt('255.255.255.0')) add('warn', 'ip', 'Adresse IP réservée (.0 ou .255)');
    if (c.fps != null && (c.fps < 16 || c.fps > 44)) add('err', 'fps', 'Images / s : entre 16 et 44');
    if (c.loginPage && !c.pass) add('warn', 'pass', 'Page de login activée sans mot de passe');
    (c.ports || []).forEach((p, i) => {
      if (!p) return;
      const u = p.dir === 'in' ? p.univIn : p.univOut;
      if (c.protocol === 'sacn' && u != null && u < 1) add('err', 'ports.' + i + '.' + (p.dir === 'in' ? 'univIn' : 'univOut'), 'DMX ' + (i + 1) + ' : l\'univers sACN 0 n\'existe pas');
      if (c.protocol === 'sacn' && u != null && u > 63999) add('err', 'ports.' + i + '.univOut', 'DMX ' + (i + 1) + ' : univers sACN 63999 maximum');
      if (c.protocol !== 'sacn' && u != null && u > 32767) add('err', 'ports.' + i + '.univOut', 'DMX ' + (i + 1) + ' : univers Art-Net 32767 maximum');
      if (p.prio != null && (p.prio < 0 || p.prio > 200)) add('err', 'ports.' + i + '.prio', 'DMX ' + (i + 1) + ' : priorité entre 0 et 200');
      if (p.castIp != null && p.castIp !== '' && !U.isIp(p.castIp)) add('err', 'ports.' + i + '.castIp', 'DMX ' + (i + 1) + ' : IP d\'envoi invalide');
    });
    return out;
  };

  /** Univers d'un port tel qu'utilisé sur le réseau, et équivalent grandMA2 (univers 1 = Art-Net 0) */
  M.portUniverse = function (c, p) {
    if (!p) return null;
    const u = p.dir === 'in' ? p.univIn : p.univOut;
    if (u == null || u === '' || isNaN(u)) return null;
    const proto = c.protocol === 'sacn' ? 'sacn' : 'artnet';
    return { proto, univ: Number(u), ma: proto === 'artnet' ? Number(u) + 1 : Number(u), dir: p.dir || 'out' };
  };
  M.fmtUniv = function (proto, u) {
    if (u == null) return '—';
    return proto === 'sacn' ? 'sACN ' + u : 'Art-Net ' + u;
  };

  /**
   * Plan des univers d'un parc.
   * entries = [{ id, name, ip, canon, ports }] ; opts.expected = [numéros MA attendus]
   */
  M.universePlan = function (entries, opts) {
    opts = opts || {};
    const rows = {};
    const issues = [];
    const ipOwners = {};
    const names = {};
    for (const e of entries) {
      const c = e.canon || {};
      const ip = c.ipMode === 'dhcp' ? null : (c.ip || e.ip);
      if (ip && U.isIp(ip)) (ipOwners[ip] = ipOwners[ip] || []).push(e);
      const nm = U.norm(c.shortName || '');
      if (nm) (names[nm] = names[nm] || []).push(e);
      const n = Math.max(e.ports || 0, (c.ports || []).length);
      for (let i = 0; i < n; i++) {
        const pu = M.portUniverse(c, (c.ports || [])[i]);
        if (!pu) continue;
        const k = pu.proto + ':' + pu.univ;
        const row = rows[k] = rows[k] || { proto: pu.proto, univ: pu.univ, ma: pu.ma, outs: [], ins: [] };
        (pu.dir === 'in' ? row.ins : row.outs).push({ id: e.id, name: e.name, port: i, prio: ((c.ports || [])[i] || {}).prio });
      }
    }
    const list = Object.values(rows).sort((a, b) => a.ma - b.ma || (a.proto < b.proto ? -1 : 1));
    for (const r of list) {
      r.issues = [];
      if (r.ins.length > 1) {
        const prios = r.ins.map(x => x.prio == null ? 100 : x.prio);
        const samePrio = r.proto === 'artnet' || new Set(prios).size < prios.length;
        r.issues.push({ level: samePrio ? 'err' : 'warn', msg: r.ins.length + ' entrées DMX envoient ' + M.fmtUniv(r.proto, r.univ) + (samePrio ? ' (sources en conflit)' : ' (priorités sACN différentes)') });
      }
      const loop = r.ins.find(x => r.outs.some(o => o.id === x.id));
      if (loop) r.issues.push({ level: 'warn', msg: loop.name + ' renvoie sur le réseau l\'univers qu\'il reçoit (MA ' + r.ma + ') : boucle possible' });
      r.issues.forEach(i => issues.push(Object.assign({ univ: r.univ, proto: r.proto, ma: r.ma }, i)));
    }
    // univers attendus (patch console) sans node en sortie
    if (opts.expected && opts.expected.length) {
      const covered = new Set(list.filter(r => r.outs.length).map(r => r.ma));
      opts.expected.forEach(ma => {
        if (!covered.has(ma)) issues.push({ level: 'info', ma, msg: 'Univers ' + ma + ' (console) : aucun node ne le sort' });
      });
      list.forEach(r => {
        if (r.outs.length && opts.expected.indexOf(r.ma) < 0) r.issues.push({ level: 'info', msg: 'Univers hors de la plage de la console' });
      });
    }
    // protocoles mélangés pour le même numéro
    const byMa = {};
    list.forEach(r => (byMa[r.ma] = byMa[r.ma] || []).push(r));
    Object.keys(byMa).forEach(ma => {
      if (byMa[ma].length > 1) issues.push({ level: 'warn', ma: +ma, msg: 'Univers ' + ma + ' utilisé à la fois en Art-Net et en sACN' });
    });
    Object.keys(ipOwners).forEach(ip => {
      if (ipOwners[ip].length > 1) issues.push({ level: 'err', msg: 'Adresse ' + ip + ' utilisée par ' + ipOwners[ip].map(e => e.name).join(', ') });
    });
    Object.keys(names).forEach(n => {
      if (names[n].length > 1) issues.push({ level: 'warn', msg: 'Nom court « ' + names[n][0].canon.shortName + ' » utilisé ' + names[n].length + ' fois' });
    });
    if (opts.subnet && opts.subnet.ip && opts.subnet.mask) {
      Object.keys(ipOwners).forEach(ip => {
        if (!U.sameSubnet(ip, opts.subnet.ip, opts.subnet.mask)) issues.push({ level: 'warn', msg: ipOwners[ip][0].name + ' (' + ip + ') est hors du réseau ' + opts.subnet.ip + ' / ' + opts.subnet.mask });
      });
    }
    return { rows: list, issues };
  };

  /** Lit "1-8, 12, 20-21" -> [1..8, 12, 20, 21] */
  M.parseRanges = function (s) {
    const out = [];
    String(s || '').split(/[,;\s]+/).forEach(part => {
      const m = /^(\d+)(?:\s*[-–à]\s*(\d+))?$/.exec(part.trim());
      if (!m) return;
      const a = +m[1], b = m[2] ? +m[2] : a;
      for (let i = Math.min(a, b); i <= Math.max(a, b) && out.length < 4096; i++) out.push(i);
    });
    return Array.from(new Set(out)).sort((x, y) => x - y);
  };

  // ------------------------------------------------------------ opérations par lot
  /**
   * Applique des opérations à la config voulue d'un node.
   * ops = [{ path, op:'set'|'offset'|'seq', value, step }] ; path peut contenir "ports.*."
   * idx = rang du node dans la sélection (pour les suites d'adresses)
   */
  M.applyOps = function (canon, ops, ctx) {
    ctx = ctx || {};
    const idx = ctx.idx || 0;
    const c = U.clone(canon || {}) || {};
    c.ports = c.ports || [];
    const portCount = Math.max(ctx.nPorts || 0, c.ports.length);
    const portOffset = ctx.portOffset != null ? ctx.portOffset : idx * portCount;
    for (const o of ops) {
      const paths = [];
      if (/^ports\.\*\./.test(o.path)) for (let i = 0; i < portCount; i++) paths.push(o.path.replace('*', i));
      else paths.push(o.path);
      paths.forEach((path, pi) => {
        // "ports.N.univ" = l'univers utilisé par le port (reçu en sortie, envoyé en entrée)
        const um = /^ports\.(\d+)\.univ$/.exec(path);
        if (um) path = 'ports.' + um[1] + '.' + (((c.ports[+um[1]] || {}).dir === 'in') ? 'univIn' : 'univOut');
        const cur = M.getPath(c, path);
        const def = M.fieldDef(path);
        let v;
        if (o.op === 'offset') {
          if (cur == null || cur === '' || isNaN(cur)) return;
          v = Number(cur) + Number(o.value);
        } else if (o.op === 'seq') {
          const step = Number(o.step || 1);
          if (def && def.kind === 'ip') v = U.isIp(o.value) ? U.nextIp(o.value, idx * step) : cur;
          else if (def && (def.kind === 'number' || def.kind === 'univ')) v = Number(o.value) + (/^ports\./.test(path) ? portOffset + pi : idx) * step;
          else v = String(o.value).replace(/#+/g, h => String(idx + Number(o.start == null ? 1 : o.start)).padStart(h.length, '0'));
        } else if (o.op === 'unset') {
          v = undefined;
        } else v = o.value;
        M.setPath(c, path, v);
      });
    }
    return c;
  };

  // ------------------------------------------------------------ Art-Net (ArtPollReply)
  /** Réglages communs déductibles d'un ArtPollReply (lecture seule, partielle) */
  M.fromPoll = function (r) {
    if (!r) return null;
    const c = { shortName: r.shortName, longName: r.longName, ipNow: r.ip, ports: [] };
    if (r.dhcpCapable || r.dhcp) c.ipMode = r.dhcp ? 'dhcp' : 'static';
    if (c.ipMode === 'static' && r.ip) c.ip = r.ip;
    if (r.protocolGuess === 'sacn' || r.protocolGuess === 'artnet') c.protocol = r.protocolGuess;
    (r.ports || []).forEach((p, i) => {
      const dir = p.canOut && !p.canIn ? 'out' : (p.canIn && !p.canOut ? 'in' : (p.inData && !p.outData ? 'in' : 'out'));
      const port = { dir };
      if (c.protocol !== 'sacn') {
        if (p.canOut) port.univOut = p.univOut;
        if (p.canIn) port.univIn = p.univIn;
      }
      c.ports[i] = port;
    });
    return c;
  };

  // ------------------------------------------------------------ firmware
  /** Clé de modèle : nombre de ports + nom du produit s'il est connu */
  M.modelKey = function (node) {
    const ports = node.model || (node.last && node.last.ports) || 0;
    const prod = U.norm(node.product || (node.last && node.last.product) || '').replace(/[^a-z0-9 ]/g, '').trim();
    return (ports ? ports + 'p' : '?p') + (prod ? ':' + prod : '');
  };
  M.modelLabel = function (node) {
    const ports = node.model || (node.last && node.last.ports) || 0;
    const prod = node.product || (node.last && node.last.product) || '';
    return (prod ? prod : 'Node') + (ports ? ' · ' + ports + ' univers' : '');
  };

  /**
   * État firmware de chaque node : la référence d'un modèle est la plus récente vue dans le parc,
   * sauf si une version de référence est fixée à la main.
   * Renvoie { byNode: { id: { status:'ok'|'old'|'unknown', fw, ref } }, refs: { modelKey: { fw, from } } }
   */
  M.firmwareStatus = function (nodes, pinned) {
    pinned = pinned || {};
    const refs = {};
    nodes.forEach(n => {
      const fw = n.firmware || (n.last && n.last.canon && n.last.canon.firmware);
      if (!fw) return;
      const k = M.modelKey(n);
      const cur = refs[k];
      if (!cur || U.compareFirmware(fw, cur.fw) > 0) refs[k] = { fw, from: n.id };
    });
    Object.keys(pinned).forEach(k => { if (pinned[k]) refs[k] = { fw: pinned[k], from: 'manuel', pinned: true }; });
    const byNode = {};
    nodes.forEach(n => {
      const fw = n.firmware || (n.last && n.last.canon && n.last.canon.firmware);
      const k = M.modelKey(n);
      const ref = refs[k];
      let status = 'unknown';
      if (fw && ref) {
        const cmp = U.compareFirmware(fw, ref.fw);
        status = cmp == null ? 'unknown' : cmp < 0 ? 'old' : 'ok';
      }
      byNode[n.id] = { status, fw: fw || '', ref: ref ? ref.fw : '', key: k };
    });
    return { byNode, refs };
  };

  // ------------------------------------------------------------ fichiers dmx-tools
  /**
   * Fichier JSON de dmx-tools ou de la page web du node ("Save Json" / "Save Parameters") :
   * { "ID0": { "value": "…", "name": "…" }, "ID5_IP0": { "value": "2" } … } (ancien format : valeur brute)
   * Renvoie [{ index, value }] en regroupant les 4 morceaux des adresses IP.
   */
  M.parseDmxToolsJson = function (obj, table) {
    const out = [];
    const ips = {};
    Object.keys(obj || {}).forEach(k => {
      const raw = obj[k];
      const v = raw && typeof raw === 'object' && 'value' in raw ? raw.value : raw;
      let m = /^ID(\d+)_IP([0-3])$/.exec(k);
      if (m) { (ips[m[1]] = ips[m[1]] || [])[+m[2]] = v; return; }
      m = /^ID(\d+)$/.exec(k);
      if (m) out.push({ index: +m[1], value: v, name: raw && raw.name });
    });
    Object.keys(ips).forEach(i => out.push({ index: +i, value: ips[i].map(x => +x || 0).join('.') }));
    if (table) {
      out.forEach(o => {
        const p = (table.params || []).find(x => x.index === o.index);
        if (!p) return;
        if (p.type === M.T.LIST && isNaN(Number(o.value))) {
          const i = p.options.indexOf(o.value);
          if (i >= 0) o.value = i;
        } else if (p.type === M.T.NUMBER || p.type === M.T.LIST) o.value = Number(o.value);
      });
    }
    return out.sort((a, b) => a.index - b.index);
  };
  /** Table lue -> fichier compatible dmx-tools */
  M.toDmxToolsJson = function (table) {
    const o = {};
    (table.params || []).forEach(p => {
      if (p.type === M.T.IP) {
        String(p.value || '0.0.0.0').split('.').forEach((x, i) => { o['ID' + p.index + '_IP' + i] = { value: String(x), name: p.label }; });
      } else o['ID' + p.index] = { value: String(p.value == null ? '' : p.value), name: p.label };
    });
    return o;
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = M;
  else root.Model = M;
})(typeof self !== 'undefined' ? self : this);
