/*
 * Node Pocket — lecture et remplissage de la page web d'un node (configuration par le réseau).
 *
 * Electroconcept ne publie pas d'API réseau : l'appli ouvre la page du node en arrière-plan,
 * y injecte ce script, lit les champs avec leurs libellés, les remplit puis clique sur « Apply ».
 * La page fait elle-même l'envoi au node, quelle que soit sa façon de faire.
 */
(function (root) {
  'use strict';
  const U = root.U || (typeof require !== 'undefined' ? require('./util.js') : null);

  /* ------------------------------------------------------------------
   * Code exécuté DANS la page du node (doit rester autonome)
   * ------------------------------------------------------------------ */
  function inject() {
    if (window.__NP && window.__NP.v === 5) return 'ok';
    var NP = { v: 5, alerts: [], last: {} };
    window.__NP = NP;
    try {
      window.alert = function (m) { NP.alerts.push(String(m)); };
      window.confirm = function (m) { NP.alerts.push(String(m)); return true; };
    } catch (e) { /* page verrouillée */ }

    function txt(el) {
      if (!el) return '';
      var t = el.innerText != null && el.offsetParent !== undefined ? el.innerText : el.textContent;
      if (!t || !String(t).trim()) t = el.textContent || '';
      return String(t).replace(/\s+/g, ' ').trim();
    }
    function ownText(el) {
      var c = el.cloneNode(true);
      var kill = c.querySelectorAll('input,select,textarea,option,button,script,style');
      for (var i = 0; i < kill.length; i++) kill[i].parentNode.removeChild(kill[i]);
      return txt(c);
    }
    function docs() {
      var out = [document];
      try {
        for (var i = 0; i < window.frames.length; i++) {
          try { var d = window.frames[i].document; if (d && d.body) out.push(d); } catch (e) { /* autre origine */ }
        }
      } catch (e) { /* rien */ }
      return out;
    }
    function qsa(sel) {
      var all = [];
      docs().forEach(function (d) { all = all.concat(Array.prototype.slice.call(d.querySelectorAll(sel))); });
      return all;
    }
    function isFieldEl(el) {
      if (el.tagName === 'SELECT' || el.tagName === 'TEXTAREA') return true;
      var t = (el.type || 'text').toLowerCase();
      return !/^(hidden|submit|button|reset|image|file)$/.test(t);
    }
    function short(s) { s = String(s || '').trim(); return s.length > 0 && s.length < 90 ? s : ''; }

    function labelFor(el) {
      var t;
      if (el.id) {
        var ls = el.ownerDocument.getElementsByTagName('label');
        for (var i = 0; i < ls.length; i++) if (ls[i].htmlFor === el.id && (t = short(ownText(ls[i])))) return t;
      }
      var pl = el.closest ? el.closest('label') : null;
      if (pl && (t = short(ownText(pl)))) return t;
      // texte juste avant le champ
      var n = el.previousSibling, hops = 0;
      while (n && hops < 8) {
        if (n.nodeType === 3 && (t = short(n.textContent))) return t;
        if (n.nodeType === 1) {
          if (/^(INPUT|SELECT|TEXTAREA|BUTTON)$/.test(n.tagName)) break;
          if (n.tagName !== 'BR' && (t = short(ownText(n)))) return t;
        }
        n = n.previousSibling; hops++;
      }
      // tableau : cellule de gauche
      var td = el.closest ? el.closest('td,th') : null;
      if (td && td.parentElement) {
        var cells = Array.prototype.slice.call(td.parentElement.children);
        for (var k = cells.indexOf(td) - 1; k >= 0; k--) if ((t = short(ownText(cells[k])))) return t;
      }
      // disposition en blocs : élément précédent du parent
      var p = el.parentElement, depth = 0;
      while (p && depth < 3) {
        if (p.children.length > 1 && p.querySelectorAll('input,select,textarea').length > 1) break;
        var ps = p.previousElementSibling;
        if (ps && !ps.querySelector('input,select,textarea') && (t = short(ownText(ps)))) return t;
        if ((t = short(ownText(p)))) return t;
        p = p.parentElement; depth++;
      }
      return el.getAttribute('aria-label') || el.title || el.placeholder || el.name || el.id || '';
    }

    var tabButtons = null;
    function groupFor(el) {
      if (!tabButtons) tabButtons = qsa('button,a,li,div[onclick],span[onclick],[role=tab],[data-tab],[data-target],[aria-controls]');
      var a = el.parentElement;
      while (a && a !== a.ownerDocument.body && a !== a.ownerDocument.documentElement) {
        if (a.id) {
          var id = a.id;
          for (var i = 0; i < tabButtons.length; i++) {
            var b = tabButtons[i];
            if (b === a || a.contains(b) || b.contains(a)) continue;
            var oc = b.getAttribute('onclick') || '';
            if (oc.indexOf("'" + id + "'") >= 0 || oc.indexOf('"' + id + '"') >= 0 || b.getAttribute('href') === '#' + id ||
              b.getAttribute('data-target') === '#' + id || b.getAttribute('data-target') === id || b.getAttribute('data-tab') === id || b.getAttribute('aria-controls') === id) {
              var bt = short(txt(b));
              if (bt) return bt;
            }
          }
        }
        if (a.tagName === 'FIELDSET') {
          var lg = a.querySelector('legend');
          if (lg && short(txt(lg))) return txt(lg);
        }
        var kids = a.children;
        for (var j = 0; j < kids.length && j < 4; j++) {
          var c = kids[j];
          if (c.contains(el)) break;
          if ((/^H[1-6]$/.test(c.tagName) || /title|header|heading|legend|caption/i.test(c.className || '')) && !c.querySelector('input,select,textarea')) {
            var ht = short(txt(c));
            if (ht) return ht;
          }
        }
        a = a.parentElement;
      }
      return '';
    }

    NP.scan = function () {
      tabButtons = null;
      var all = qsa('input,select,textarea').filter(isFieldEl);
      var fields = [], ipParts = {}, byKey = {};
      all.forEach(function (el, i) {
        var key = el.id || el.name || ('f' + i);
        if (el.type === 'radio') {
          if (!el.name || byKey['r:' + el.name]) return;
          var radios = all.filter(function (r) { return r.type === 'radio' && r.name === el.name; });
          var f0 = { key: 'r:' + el.name, kind: 'list', label: labelFor(radios[0].closest('div,td,p,fieldset') || radios[0]), group: groupFor(el), options: radios.map(function (r) { return labelFor(r) || r.value; }), value: radios.findIndex(function (r) { return r.checked; }), readonly: radios.every(function (r) { return r.disabled; }) };
          byKey[f0.key] = radios; fields.push(f0);
          return;
        }
        var m = /^(.*?)[_-]?IP([0-3])$/i.exec(key);
        if (m && el.tagName === 'INPUT') {
          var base = m[1] || key;
          var ip = ipParts[base];
          if (!ip) {
            ip = ipParts[base] = { key: base, kind: 'ip', label: labelFor(el), group: groupFor(el), parts: [], value: '', readonly: false };
            fields.push(ip);
          }
          ip.parts[+m[2]] = el;
          ip.readonly = ip.readonly || el.readOnly || el.disabled;
          return;
        }
        var f = { key: key, label: labelFor(el), group: groupFor(el), readonly: !!(el.readOnly || el.disabled) };
        if (el.tagName === 'SELECT') {
          f.kind = 'list';
          f.options = Array.prototype.map.call(el.options, function (o) { return (o.text || o.value || '').trim(); });
          f.value = el.selectedIndex;
        } else if (el.type === 'checkbox') {
          f.kind = 'bool'; f.value = !!el.checked;
        } else {
          f.kind = el.type === 'number' || el.type === 'range' ? 'number' : (el.type === 'password' ? 'password' : 'text');
          f.value = el.value;
          if (el.min !== '' && el.min != null) f.min = Number(el.min);
          if (el.max !== '' && el.max != null) f.max = Number(el.max);
          if (el.maxLength > 0) f.maxLen = el.maxLength;
          if (f.kind === 'text' && /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(String(el.value).trim())) f.kind = 'ip';
        }
        if (byKey[key]) key = f.key = key + '#' + i;
        byKey[key] = el;
        fields.push(f);
      });
      Object.keys(ipParts).forEach(function (k) {
        var ip = ipParts[k];
        ip.value = ip.parts.map(function (p) { return p ? String(p.value).trim() || '0' : '0'; }).join('.');
        byKey[k] = ip.parts;
        delete ip.parts;
      });
      NP.byKey = byKey;
      var buttons = qsa('button,input[type=button],input[type=submit],a[onclick],a[role=button],[role=button]')
        .map(function (b, i) { return { i: i, text: short(b.value && b.tagName === 'INPUT' ? b.value : txt(b)) }; })
        .filter(function (b) { return b.text; });
      var pw = qsa('input[type=password]')[0];
      var isLogin = !!pw && fields.filter(function (f) { return f.kind !== 'password'; }).length <= 3;
      var alerts = NP.alerts.splice(0);
      return JSON.stringify({ url: location.href, title: document.title, isLogin: isLogin, fields: fields, buttons: buttons, alerts: alerts, ready: document.readyState });
    };

    function setNative(el, v) {
      var w = el.ownerDocument.defaultView || window;
      var proto = el.tagName === 'TEXTAREA' ? w.HTMLTextAreaElement.prototype : w.HTMLInputElement.prototype;
      var d = Object.getOwnPropertyDescriptor(proto, 'value');
      if (d && d.set) d.set.call(el, v); else el.value = v;
    }
    function fire(el) {
      ['input', 'change', 'blur'].forEach(function (t) {
        var ev;
        var W = el.ownerDocument.defaultView || window;
        try { ev = new W.Event(t, { bubbles: true }); } catch (e) { ev = el.ownerDocument.createEvent('Event'); ev.initEvent(t, true, true); }
        el.dispatchEvent(ev);
      });
    }

    /** changes = [{ key, value }] (liste : index de l'option) */
    NP.set = function (json) {
      if (!NP.byKey) NP.scan();
      var changes = typeof json === 'string' ? JSON.parse(json) : json;
      var ok = [], missing = [];
      changes.forEach(function (c) {
        var t = NP.byKey[c.key];
        if (!t) { missing.push(c.key); return; }
        if (Array.isArray(t) && t.length && t[0] && t[0].type === 'radio') {
          var r = t[Number(c.value)];
          if (!r) { missing.push(c.key); return; }
          r.checked = true; fire(r); r.click && r.click();
        } else if (Array.isArray(t)) {
          var parts = String(c.value).split('.');
          t.forEach(function (el, i) { if (el) { setNative(el, parts[i] || '0'); fire(el); } });
        } else if (t.tagName === 'SELECT') {
          var idx = typeof c.value === 'number' ? c.value : Array.prototype.findIndex.call(t.options, function (o) { return o.text.trim() === String(c.value); });
          if (idx < 0 || idx >= t.options.length) { missing.push(c.key); return; }
          t.selectedIndex = idx; fire(t);
        } else if (t.type === 'checkbox') {
          t.checked = !!c.value; fire(t);
        } else {
          setNative(t, String(c.value)); fire(t);
        }
        ok.push(c.key);
      });
      return JSON.stringify({ ok: ok, missing: missing });
    };

    /** Clique sur le bouton dont le texte correspond (expression régulière), en évitant "exclude" */
    NP.click = function (pattern, exclude) {
      var re = new RegExp(pattern, 'i'), ex = exclude ? new RegExp(exclude, 'i') : null;
      var list = qsa('button,input[type=button],input[type=submit],a[onclick],a[role=button],[role=button],a[href]');
      for (var i = 0; i < list.length; i++) {
        var b = list[i];
        var t = (b.tagName === 'INPUT' ? b.value : txt(b)) || '';
        if (re.test(t) && !(ex && ex.test(t))) {
          b.click();
          return JSON.stringify({ clicked: t.trim() });
        }
      }
      return JSON.stringify({ clicked: null });
    };

    NP.login = function (user, pass) {
      var pw = qsa('input[type=password]')[0];
      if (!pw) return JSON.stringify({ ok: false, why: 'pas de champ mot de passe' });
      var inputs = qsa('input').filter(function (i) { return /^(text|email|)$/.test((i.getAttribute('type') || '').toLowerCase()); });
      var u = inputs.find(function (i) { return /user|login|name|ident|utilisateur/i.test((i.name || '') + ' ' + (i.id || '') + ' ' + (i.placeholder || '')); }) || inputs[0];
      if (u) { setNative(u, user || ''); fire(u); }
      setNative(pw, pass || ''); fire(pw);
      var form = pw.form;
      var btn = (form || pw.ownerDocument).querySelector('button[type=submit],input[type=submit],button');
      if (btn) btn.click();
      else if (form) { if (form.requestSubmit) form.requestSubmit(); else form.submit(); }
      return JSON.stringify({ ok: true });
    };
    return 'ok';
  }

  const S = {};
  S.inject = inject;
  S.SCRIPT = '(' + inject.toString() + ')()';
  /** Boutons de la page : Appliquer (et pas « Save Parameters », qui télécharge un fichier) */
  S.APPLY = '^\\s*(apply|appliquer|valider|enregistrer|save|submit|ok|envoyer|update|mettre (a|à) jour)(\\s+(settings?|config(uration)?|changes|all|les r(e|é)glages|et red(e|é)marrer|(and|&) reboot))?\\s*!?\\s*$';
  S.APPLY_EXCLUDE = 'param|json|load|charger|status|reset|usine|dfu';

  /** Résultat de scan -> table de paramètres au même format que l'USB */
  S.toTable = function (scan) {
    const groups = [];
    const gIndex = {};
    const params = [];
    (scan.fields || []).forEach((f, i) => {
      if (f.kind === 'password' && scan.isLogin) return;
      const g = f.group || 'Page';
      if (gIndex[g] == null) { gIndex[g] = groups.length; groups.push({ index: groups.length, name: g }); }
      const p = { index: i, key: f.key, group: gIndex[g], label: f.label || f.key, options: f.options || [], value: f.value, min: f.min == null ? 0 : f.min, max: f.max == null ? 0 : f.max, readonly: !!f.readonly, maxLen: f.maxLen || 0 };
      if (f.kind === 'list') p.type = 4;
      else if (f.kind === 'bool') p.type = 6;
      else if (f.kind === 'ip') p.type = 2;
      else if (f.kind === 'number') p.type = 0;
      else p.type = f.readonly ? 5 : 1;
      if (p.type === 0) p.value = p.value === '' ? '' : Number(p.value);
      // champ texte contenant un nombre (anciennes pages) : traité comme un nombre
      if (p.type === 1 && /^-?\d+$/.test(String(p.value).trim()) && /univ|fps|priorit|max/i.test(p.label)) { p.type = 0; p.value = Number(p.value); }
      params.push(p);
    });
    return { name: scan.title || '', groups, params, at: Date.now(), url: scan.url };
  };

  /** Compte rendu lisible de ce que la page contient (pour le diagnostic) */
  S.describe = function (scan) {
    const lines = ['Page : ' + scan.url, 'Titre : ' + scan.title, 'Login : ' + (scan.isLogin ? 'oui' : 'non')];
    (scan.fields || []).forEach(f => lines.push('  [' + (f.group || '-') + '] ' + f.label + ' = ' + (f.kind === 'list' ? (f.options[f.value] + ' (' + f.value + ' / ' + f.options.join('|') + ')') : f.value) + '  <' + f.kind + (f.readonly ? ', lecture seule' : '') + ', clé ' + f.key + '>'));
    lines.push('Boutons : ' + (scan.buttons || []).map(b => b.text).join(' | '));
    return lines.join('\n');
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = S;
  else root.Scraper = S;
})(typeof self !== 'undefined' ? self : this);
