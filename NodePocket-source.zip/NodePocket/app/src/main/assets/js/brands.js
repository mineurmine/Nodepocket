/*
 * Node Pocket — marques de nodes : reconnaissance et pilotes.
 * Développé par 3DP.
 *
 * Tous les nodes partagent la même interface (noms, IP, Art-Net / sACN, univers par port).
 * Chaque marque dit seulement par où passer et ce qu'on peut modifier :
 *   usb    : protocole USB Electroconcept (dmx-tools)
 *   api    : API web Luminex (LumiNode / LumiCore)
 *   web    : page web du node, lue et remplie par l'appli
 *   artnet : norme Art-Net (ArtPoll pour l'état, ArtAddress / ArtIpProg pour écrire)
 */
(function (root) {
  'use strict';
  const OEM = root.OEM || (typeof require !== 'undefined' ? require('./oem.js') : null);

  const LIST = [
    {
      id: 'electroconcept', name: 'Electroconcept', level: 'full',
      routes: ['usb', 'web', 'artnet'], write: { usb: true, web: true, artnet: true },
      maker: /electro ?concept/i, names: /electro ?concept/i, esta: [0x4345], usb: [[0x1fc9, 0x0052]], sacnBase: 'auto',
      tool: 'dmx-tools (USB) ou la page web du node',
      note: 'Réglage complet par USB ou par la page web du node.'
    },
    {
      id: 'luminex', name: 'Luminex', level: 'partial',
      routes: ['api', 'web', 'artnet'], write: { web: true, artnet: true },
      maker: /luminex/i, names: /lumi ?(node|core|net|split|hub)|luminex|ethernet[- ]?dmx ?\d/i, esta: [], sacnBase: 1,
      tool: 'Luminex Araneo ou la page web du node (API documentée sur http://IP/api/doc)',
      note: 'API Luminex : noms, firmware, identification, redémarrage et reset. Univers et IP : par la page web (à confirmer sur ton modèle) ou Art-Net.'
    },
    {
      id: 'etc', name: 'ETC', level: 'readonly',
      routes: ['artnet'], write: {},
      maker: /electronic theat(re|er)|^etc\b/i, names: /\bresponse\b|net ?3|\betc\b|gadget|\bconcert\b|ion ?xe|\beos\b/i, esta: [0x6574], sacnBase: 1,
      tool: 'ETC Concert ou le menu du boîtier (Setup › Ports)',
      note: 'Les gateways ETC se règlent avec ETC Concert : l\'appli affiche leur état et leurs univers en direct.'
    },
    {
      id: 'chamsys', name: 'ChamSys', level: 'readonly',
      routes: ['artnet'], write: {},
      maker: /chamsys/i, names: /snake ?sys|chamsys|magic ?q/i, esta: [], sacnBase: 1,
      tool: 'MagicQ › Net Manager (mode ChamNet) ou les boutons du boîtier',
      note: 'Les SnakeSys se règlent depuis MagicQ ou leurs boutons : l\'appli affiche leur état et leurs univers en direct.'
    },
    {
      id: 'ma', name: 'MA Lighting', level: 'readonly',
      routes: ['artnet'], write: {},
      maker: /ma lighting/i, names: /\bma\b.{0,4}(\d ?port|node|npu)|\d ?port node|grand ?ma|ma-?net|\bnpu\b|dot2/i, esta: [0x4d41], sacnBase: 1,
      tool: 'la console grandMA (Setup › Network Config) ou le menu du node',
      note: 'Les nodes MA se règlent depuis la console grandMA : l\'appli affiche leur état et leurs univers en direct.'
    },
    {
      id: 'dmxking', name: 'DMXking', level: 'full',
      routes: ['web', 'artnet'], write: { web: true, artnet: true },
      maker: /jpk|dmx ?king/i, names: /dmx ?king|\bedmx|ultra ?dmx|lekatech/i, esta: [0x6a6b], sacnBase: 1,
      tool: 'la page web du node ou DMXking eDMX Configuration',
      note: 'Réglage par la page web du node ou par Art-Net.'
    },
    {
      id: 'enttec', name: 'Enttec', level: 'full',
      routes: ['web', 'artnet'], write: { web: true },
      maker: /enttec/i, names: /\bode\b|enttec|ethergate|storm ?\d|datagate|pixelator/i, esta: [0x454e], sacnBase: 1,
      tool: 'la page web du node',
      note: 'Réglage par la page web du node (pas de configuration par Art-Net sur ces modèles).'
    },
    {
      id: 'china', name: 'Node Art-Net générique', level: 'full',
      routes: ['web', 'artnet'], write: { web: true, artnet: true },
      maker: /pknight|colordreamer|seachip|greentao|highendled|sqd|chaiyi|hycl|ltech|shenzhen|guangzhou|xiamen|shanghai|zhuhai|ningbo/i,
      names: /pknight|art-?net ?(to ?)?(dmx)? ?node|dmx ?node|artnet ?to ?dmx|\bcr0\d\d|\bsp20\d|^dmx ?(512)? ?(controller|converter)/i, esta: [0x0000], sacnBase: 1,
      tool: 'la page web du node ou DMX-Workshop',
      note: 'Petits nodes Art-Net (souvent chinois) : réglage par leur page web ou par Art-Net.'
    },
    {
      id: 'generic', name: 'Autre node Art-Net', level: 'full',
      routes: ['web', 'artnet'], write: { web: true, artnet: true },
      maker: null, names: null, esta: [], sacnBase: 'auto',
      tool: 'la page web du node ou le logiciel du fabricant',
      note: 'Marque non reconnue : l\'appli essaie la page web du node puis la norme Art-Net.'
    }
  ];
  const BY = {};
  LIST.forEach(b => { BY[b.id] = b; });

  const B = { LIST, BY };
  B.get = id => BY[id] || BY.generic;
  B.options = () => [['auto', 'Automatique']].concat(LIST.map(b => [b.id, b.name]));

  /**
   * Reconnaît la marque d'un node.
   * ctx = { poll (ArtPollReply fusionné), product, title (page web), usb:{vid,pid}, brand (choix manuel) }
   * Renvoie { id, how, model, maker }
   */
  B.detect = function (ctx) {
    ctx = ctx || {};
    if (ctx.brand && ctx.brand !== 'auto' && BY[ctx.brand]) return { id: ctx.brand, how: 'manuel' };
    if (ctx.usb) {
      const b = LIST.find(x => (x.usb || []).some(u => u[0] === ctx.usb.vid && u[1] === ctx.usb.pid));
      if (b) return { id: b.id, how: 'usb' };
    }
    const p = ctx.poll;
    let oem = null;
    if (p && p.oem != null && p.oem !== 0xffff && p.oem !== 0x00ff && p.oem !== 0) {
      oem = OEM ? OEM.lookup(p.oem) : null;
      if (oem) {
        const b = LIST.find(x => x.maker && x.maker.test(oem.maker));
        if (b) return { id: b.id, how: 'code OEM', model: oem.product, maker: oem.maker };
      }
    }
    const texts = [p && p.shortName, p && p.longName, ctx.product, ctx.title].filter(Boolean).join(' | ');
    if (texts) {
      for (const b of LIST) if (b.names && b.names.test(texts)) return { id: b.id, how: 'nom', maker: oem ? oem.maker : '', model: oem ? oem.product : '' };
    }
    if (p && p.estaMan) {
      const b = LIST.find(x => (x.esta || []).indexOf(p.estaMan) >= 0 && x.id !== 'china');
      if (b) return { id: b.id, how: 'code ESTA' };
    }
    return { id: 'generic', how: oem ? 'code OEM' : 'inconnu', maker: oem ? oem.maker : '', model: oem ? oem.product : '' };
  };

  /** Libellé fabricant + modèle pour l'affichage */
  B.label = function (det) {
    if (!det) return '';
    const b = B.get(det.id);
    const model = det.model && !/^oem/i.test(det.model) && det.model.toLowerCase().indexOf(b.name.toLowerCase()) < 0 ? det.model : '';
    if (det.id === 'generic' && det.maker) return det.maker + (model ? ' ' + model : '');
    return b.name + (model ? ' ' + model : '');
  };

  /** Chemins de lecture / écriture autorisés pour une marque */
  B.canWrite = (id, route) => !!(B.get(id).write || {})[route];
  B.readonly = id => B.get(id).level === 'readonly';

  if (typeof module !== 'undefined' && module.exports) module.exports = B;
  else root.Brands = B;
})(typeof self !== 'undefined' ? self : this);
