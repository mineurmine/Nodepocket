/* Page « Fiche » : tous les réglages d'un node, prévu / lu, lecture et écriture */
(function () {
  'use strict';
  const esc = U.esc, C = App.C, M = Model;
  const TABS = [['cfg', 'Réglages'], ['raw', 'Tous les paramètres'], ['state', 'État'], ['hist', 'Historique']];
  const P = { tab: 'cfg', via: 'auto', live: true };

  const node = () => Store.node(App.params.id);

  function shown(v) {
    if (v === undefined || v === null || v === '') return '—';
    return v;
  }
  function fmtVal(path, v) {
    const d = M.fieldDef(path);
    if (v === undefined || v === null || v === '') return '—';
    if (d && d.kind === 'univ') return v;
    if (d && (d.kind === 'enum' || d.kind === 'bool')) return M.enumLabel(path, v);
    if (d && d.secret) return '••••';
    return v;
  }

  /** Une ligne de réglage : contrôle (valeur voulue) + valeur lue si différente */
  function field(n, path, opts) {
    opts = opts || {};
    const d = M.fieldDef(path);
    const want = M.getPath(Store.wanted(n), path);
    const planned = M.getPath(n.plan, path);
    const pollC = !(n.last && n.last.canon) && RT.poll[n.id] ? M.fromPoll(RT.poll[n.id]) : null;
    const have = n.last && n.last.canon ? M.getPath(n.last.canon, path) : pollC ? M.getPath(pollC, path) : undefined;
    const differs = planned !== undefined && planned !== '' && !U.same(planned, have);
    const label = opts.label || d.label;
    const fid = 'f_' + path;
    let ctl;
    if (d.kind === 'ro') {
      ctl = '<span class="ro">' + esc(shown(have != null ? have : want)) + '</span>';
    } else if (d.kind === 'enum' && d.values.length <= 3) {
      ctl = UI.seg(path, d.values, want);
    } else if (d.kind === 'enum') {
      ctl = '<select data-path="' + path + '" data-fid="' + fid + '"><option value="">—</option>' + d.values.map(v => '<option value="' + v[0] + '"' + (v[0] === want ? ' selected' : '') + '>' + esc(v[1]) + '</option>').join('') + '</select>';
    } else if (d.kind === 'bool') {
      ctl = UI.seg(path, [['false', 'Non'], ['true', 'Oui']], want === undefined ? '' : String(!!want));
    } else if (d.kind === 'number' || d.kind === 'univ') {
      ctl = '<input type="number" inputmode="numeric" data-path="' + path + '" data-fid="' + fid + '" value="' + esc(want == null ? '' : want) + '"' + (d.min != null ? ' min="' + d.min + '"' : ' min="0"') + (d.max != null ? ' max="' + d.max + '"' : '') + ' placeholder="—">';
      if (d.kind === 'univ') {
        const c = Store.wanted(n);
        const ma = want == null || want === '' ? '' : (c.protocol === 'sacn' ? Number(want) : Number(want) + 1);
        ctl += '<span class="ma" data-ma="' + path + '">' + (ma === '' ? '' : 'MA ' + ma) + '</span>';
      }
    } else {
      ctl = '<input type="' + (d.secret ? 'password' : 'text') + '" data-path="' + path + '" data-fid="' + fid + '" value="' + esc(want == null ? '' : want) + '"' + (d.max ? ' maxlength="' + d.max + '"' : '') + (d.kind === 'ip' ? ' inputmode="decimal"' : '') + ' placeholder="—" autocomplete="off" autocapitalize="off" spellcheck="false">';
      if (d.secret) ctl += '<button type="button" class="btn xs" data-act="reveal" data-arg="' + path + '">voir</button>';
    }
    const probs = (opts.probs || []).filter(p => p.path === path);
    return '<div class="fld' + (differs ? ' diff' : '') + (probs.some(p => p.level === 'err') ? ' bad' : '') + '" data-row="' + path + '">' +
      '<label>' + esc(label) + (d.hint ? ' <i class="hint" title="' + esc(d.hint) + '">?</i>' : '') + '</label><div class="ctl">' + ctl + '</div>' +
      (differs ? '<div class="was">' + (pollC ? 'Art-Net' : 'lu') + ' : ' + esc(fmtVal(path, have)) + ' <button type="button" class="btn xs" data-act="unplan" data-arg="' + path + '" title="Revenir à la valeur lue">annuler</button></div>' : '') +
      probs.map(p => '<div class="' + (p.level === 'err' ? 'err' : 'warn') + '">' + esc(p.msg) + '</div>').join('') +
      '</div>';
  }

  function tabCfg(n) {
    const c = Store.wanted(n);
    const probs = M.validate(c);
    const lastC = (n.last && n.last.canon) || {};
    const has = path => M.getPath(lastC, path) !== undefined || M.getPath(n.plan, path) !== undefined;
    let h = '';
    h += '<section class="box"><h3>Identité</h3>' + field(n, 'longName', { probs }) + field(n, 'shortName', { probs }) + '</section>';
    h += '<section class="box"><h3>Réseau</h3>' + field(n, 'ipMode', { probs }) +
      (c.ipMode !== 'dhcp' ? field(n, 'ip', { probs, label: 'Adresse IP fixe' }) + field(n, 'mask', { probs }) : '') +
      (has('gateway') ? field(n, 'gateway', { probs }) : '') +
      (lastC.ipNow ? field(n, 'ipNow') : '') + '</section>';
    h += '<section class="box"><h3>DMX</h3>' + field(n, 'protocol', { probs }) + field(n, 'outMode', { probs }) +
      (c.outMode !== 'sync' ? field(n, 'fps', { probs }) : '') + (has('maxUniv') ? field(n, 'maxUniv', { probs }) : '') + '</section>';
    const np = Store.ports(n);
    h += '<section class="box ports-box"><h3>Ports DMX</h3><div class="pgrid">';
    for (let i = 0; i < np; i++) {
      const p = c.ports[i] || {};
      const pre = 'ports.' + i + '.';
      const poll = RT.poll[n.id] && RT.poll[n.id].ports[i];
      h += '<div class="port"><h4>DMX ' + (i + 1) + (poll && RT.isOnline(n) ? (p.dir === 'in' ? (poll.inData ? ' ' + UI.badge('reçoit', 'ok') : '') : (poll.outData ? ' ' + UI.badge('données', 'ok') : ' ' + UI.badge('rien', 'mute'))) : '') + '</h4>' +
        field(n, pre + 'dir', { probs }) +
        (p.dir === 'in' ? field(n, pre + 'univIn', { probs }) : field(n, pre + 'univOut', { probs })) +
        (p.dir === 'in' && (c.protocol === 'sacn' || has(pre + 'prio')) ? field(n, pre + 'prio', { probs }) : '') +
        (p.dir === 'in' && has(pre + 'castIp') ? field(n, pre + 'castIp', { probs }) : '') +
        (c.protocol === 'sacn' && has(pre + 'sacnMode') ? field(n, pre + 'sacnMode', { probs }) : '') +
        '</div>';
    }
    h += '</div></section>';
    h += '<section class="box"><h3>Sécurité</h3>' + field(n, 'loginPage', { probs }) + field(n, 'login', { probs }) + field(n, 'pass', { probs }) + '</section>';
    h += '<section class="box"><h3>Infos</h3>' + field(n, 'firmware') + field(n, 'serial') +
      '<div class="fld"><label>Produit</label><div class="ctl"><span class="ro">' + esc(n.product || '—') + (n.last && n.last.family ? ' · firmware ' + esc(n.last.family) : '') + '</span></div></div>' +
      '<div class="fld"><label>Numérotation sACN</label><div class="ctl">' + UI.seg('sacnBase', [['auto', 'Auto'], ['0', '0 = univ. 1'], ['1', '1 = univ. 1']], String(n.sacnBase == null ? 'auto' : n.sacnBase)) + '</div><div class="muted small">Anciens firmwares : le champ « Universe » vaut 0 pour l\'univers sACN 1 (239.255.0.1).</div></div></section>';
    return h;
  }

  function tabRaw(n) {
    const raw = n.last && n.last.raw;
    if (!raw || !raw.params) return '<div class="empty muted">Pas encore lu par USB ni par la page web.<div class="row-btns center"><button type="button" class="btn primary" data-act="read">Lire maintenant</button></div></div>';
    const usbLive = USB.state === 'ready' && USB.nodeId === n.id && USB.info && USB.info.kind === 'table';
    const mapped = M.mapTable(raw, { sacnBase: n.sacnBase });
    let h = '<div class="muted small">Lu ' + U.timeAgo(n.last.at) + ' par ' + esc(Ops.VIA[n.last.via]) + ' · ' + raw.params.length + ' paramètres' +
      (usbLive ? ' · <b>modifiables directement (USB)</b>' : '') + '</div>';
    const groups = raw.groups.length ? raw.groups : [{ index: 0, name: 'Paramètres' }];
    groups.forEach(g => {
      const ps = raw.params.filter(p => (raw.groups.length ? p.group === g.index : true));
      if (!ps.length) return;
      h += '<section class="box"><h3>' + esc(g.name || 'Page') + '</h3><table class="raw">';
      ps.forEach(p => {
        const path = mapped.used[p.index];
        const act = Object.keys(mapped.actions).find(k => mapped.actions[k] === p.index);
        let v = p.value;
        if (p.type === 4) v = (p.options[p.value] != null ? p.options[p.value] : '?') + ' <small class="muted">(' + p.options.map(esc).join(' | ') + ')</small>';
        else if (p.type === 6) v = p.value ? 'oui' : 'non';
        else v = esc(v);
        h += '<tr' + (!path && !act ? ' class="unmapped"' : '') + '><th>' + esc(p.label) + '</th><td>' + v + '</td><td class="map">' +
          (path ? esc(M.pathLabel(path)) : act ? 'action ' + act : '<span class="warn">non reconnu</span>') + '</td>' +
          (usbLive && !p.readonly ? '<td><button type="button" class="btn xs" data-act="rawEdit" data-arg="' + p.index + '">modifier</button></td>' : '<td></td>') + '</tr>';
      });
      h += '</table></section>';
    });
    h += '<div class="row-btns">' + (n.last.raw && n.last.via === 'usb' ? '<button type="button" class="btn sm" data-act="exportDmxTools">Exporter (format dmx-tools)</button>' : '') +
      '<button type="button" class="btn sm" data-act="importDmxTools">Importer un fichier dmx-tools…</button>' +
      (n.last.scanText ? '<button type="button" class="btn sm" data-act="diag">Diagnostic de la page web</button>' : '') + '</div>';
    return h;
  }

  function tabState(n) {
    const on = RT.online[n.id];
    const pr = RT.probe[n.id];
    const m = RT.poll[n.id];
    let h = '<section class="box"><h3>Présence</h3><table class="kv">' +
      '<tr><th>État</th><td>' + C.statusDot(n) + ' ' + esc({ usb: 'branché en USB', busy: 'occupé', on: 'en ligne', lost: 'ne répond plus', off: 'pas vu' }[RT.status(n)]) + '</td></tr>' +
      '<tr><th>Dernier signe</th><td>' + (on ? esc(U.timeAgo(on.at)) + ' (' + (on.via === 'artnet' ? 'Art-Net' : 'page web') + ')' : '—') + '</td></tr>' +
      '<tr><th>Page web (port 80)</th><td>' + (pr ? (pr.open ? 'répond en ' + pr.ms + ' ms' : 'ne répond pas') + ' · ' + esc(U.timeAgo(pr.at)) : '—') + '</td></tr></table>' +
      '<div class="row-btns"><button type="button" class="btn sm" data-act="pollOne">Interroger en Art-Net</button><button type="button" class="btn sm" data-act="probe">Tester la page web</button><button type="button" class="btn sm" data-act="identify">Identifier</button></div></section>';
    if (m) {
      h += '<section class="box"><h3>Art-Net (ArtPollReply)</h3><table class="kv">' +
        '<tr><th>Nom court / long</th><td>' + esc(m.shortName) + ' / ' + esc(m.longName) + '</td></tr>' +
        '<tr><th>Adresse</th><td>' + esc(m.ip) + (m.dhcp ? ' (DHCP)' : ' (fixe)') + ' · MAC ' + esc(m.mac) + '</td></tr>' +
        '<tr><th>Rapport</th><td>' + esc(m.nodeReport) + '</td></tr>' +
        '<tr><th>Version</th><td>0x' + m.versInfo.toString(16).padStart(4, '0') + ' · OEM 0x' + m.oem.toString(16).padStart(4, '0') + ' · ESTA ' + esc(m.estaCode || m.estaMan) + '</td></tr>' +
        '<tr><th>Capacités</th><td>' + [m.webConfig && 'page web', m.dhcpCapable && 'DHCP', m.port15bit && 'adresses 15 bits', m.canSwitchSacn && 'bascule sACN', m.rdmCapable && 'RDM', m.canSwitchDirection && 'sens des ports'].filter(Boolean).join(', ') + '</td></tr>' +
        '<tr><th>Voyant</th><td>' + esc(m.indicator) + '</td></tr>' +
        '<tr><th>Protocole vu</th><td>' + esc(m.protocolGuess === 'sacn' ? 'sACN' : m.protocolGuess === 'artnet' ? 'Art-Net' : m.protocolGuess || '—') + '</td></tr>' +
        '</table><table class="raw"><tr><th>Port</th><th>Type</th><th>Univers Art-Net</th><th>Données</th></tr>' +
        m.ports.map((p, i) => '<tr><td>DMX ' + (i + 1) + (m.binds.length > 1 ? ' <small>(bind ' + p.bindIndex + ')</small>' : '') + '</td><td>' + (p.canOut ? 'sortie' : '') + (p.canIn ? (p.canOut ? ' + ' : '') + 'entrée' : '') + '</td><td>' + (p.canOut ? esc(ArtNet.fmtPortAddr(p.univOut)) : esc(ArtNet.fmtPortAddr(p.univIn))) + '</td><td>' +
          [p.outData && 'émet', p.inData && 'reçoit', p.outMerging && 'fusion', p.outSacn && 'sACN', p.inErrors && 'erreurs'].filter(Boolean).join(', ') + '</td></tr>').join('') + '</table></section>';
    } else h += '<section class="box"><h3>Art-Net</h3><p class="muted">Pas de réponse ArtPoll reçue pour ce node.</p></section>';
    return h;
  }

  function tabHist(n) {
    let h = '<section class="box"><h3>Lectures</h3>';
    if (!n.history.length) h += '<p class="muted">Aucune lecture enregistrée.</p>';
    else h += '<table class="raw">' + n.history.slice().reverse().map((e, i) => '<tr><td>' + esc(U.fmtDate(e.at)) + '</td><td>' + esc(Ops.VIA[e.via]) + '</td><td>' + esc(e.canon.shortName || '') + ' · ' + esc(e.canon.ip || e.canon.ipNow || '') + ' · ' + C.protoName(e.canon.protocol) + '</td><td><button type="button" class="btn xs" data-act="histView" data-arg="' + (n.history.length - 1 - i) + '">voir</button> <button type="button" class="btn xs" data-act="histUse" data-arg="' + (n.history.length - 1 - i) + '">reprendre</button></td></tr>').join('') + '</table>';
    h += '</section>';
    const j = Store.state.journal.filter(x => x.id === n.id).slice(-30).reverse();
    h += '<section class="box"><h3>Journal</h3>' + (j.length ? '<table class="raw">' + j.map(x => '<tr class="' + (x.ok ? '' : 'bad') + '"><td>' + esc(U.fmtDate(x.at)) + '</td><td>' + (x.ok ? '✓' : '✗') + ' ' + esc(x.what) + '</td><td class="muted">' + esc(x.detail) + '</td></tr>').join('') + '</table>' : '<p class="muted">Rien pour l\'instant.</p>') + '</section>';
    if (n.notes) h += '<section class="box"><h3>Notes</h3><p>' + esc(n.notes).replace(/\n/g, '<br>') + '</p></section>';
    return h;
  }

  P.render = function () {
    const n = node();
    if (!n) return '<div class="empty">Node introuvable. <button type="button" class="btn" data-act="back">Retour</button></div>';
    const pend = Store.pending(n);
    const routes = Ops.routes(n);
    const via = P.via;
    const usbOk = USB.state === 'ready' && USB.nodeId === n.id;
    const busy = RT.busy[n.id];
    let h = '<div class="pghead fiche"><button type="button" class="btn icon" data-act="back" aria-label="Retour">‹</button>' +
      '<h1>' + C.statusDot(n) + esc(Store.label(n)) + ' <small>' + esc(n.ip || '') + (n.tags.length ? ' · ' + n.tags.map(esc).join(', ') : '') + '</small></h1>' +
      '<div class="tools">' +
      '<button type="button" class="btn" data-act="read" data-fid="b_read"' + (busy ? ' disabled' : '') + '>Lire</button>' +
      '<button type="button" class="btn ' + (pend.length ? 'primary' : '') + '" data-act="apply" data-fid="b_apply"' + (pend.length && !busy ? '' : ' disabled') + '>Appliquer' + (pend.length ? ' (' + pend.length + ')' : '') + '</button>' +
      '<button type="button" class="btn" data-act="web" data-fid="b_web"' + (U.isIp(n.ip) ? '' : ' disabled') + '>Page web</button>' +
      '<button type="button" class="btn icon" data-act="menu" data-fid="b_menu" aria-label="Plus">⋯</button></div></div>';
    h += '<div class="viabar"><span class="muted">Passer par</span>' + UI.seg('via', [['auto', 'Auto (' + (Ops.VIA[routes[0]] || '—') + ')'], ['usb', 'USB'], ['web', 'Page web'], ['artnet', 'Art-Net']], via)
      .replace('data-v="usb"', 'data-v="usb"' + (usbOk ? '' : ' disabled')) +
      (busy ? '<span class="busy">' + esc(busy) + '…</span>' : n.last ? '<span class="muted small">lu ' + esc(U.timeAgo(n.last.at)) + ' (' + esc(Ops.VIA[n.last.via]) + ')</span>' : (RT.poll[n.id] ? '<span class="warn small">pas encore lu en détail : valeurs annoncées en Art-Net</span>' : '<span class="warn small">jamais lu : les valeurs affichées sont celles prévues</span>')) + '</div>';
    if (pend.length) h += '<div class="pendbar">' + U.plural(pend.length, 'écart') + ' entre le prévu et le node : ' + pend.slice(0, 4).map(d => esc(d.label)).join(', ') + (pend.length > 4 ? '…' : '') +
      ' <button type="button" class="btn xs" data-act="adopt">garder le lu</button></div>';
    h += '<div class="tabs">' + TABS.map(t => '<button type="button" class="tab' + (P.tab === t[0] ? ' on' : '') + '" data-act="tab" data-arg="' + t[0] + '">' + t[1] + '</button>').join('') + '</div>';
    h += '<div class="tabbody">' + (P.tab === 'raw' ? tabRaw(n) : P.tab === 'state' ? tabState(n) : P.tab === 'hist' ? tabHist(n) : tabCfg(n)) + '</div>';
    return h;
  };

  /** Valeur saisie -> valeur canonique */
  function parseVal(path, raw) {
    const d = M.fieldDef(path);
    if (raw === '' || raw == null) return undefined;
    if (d.kind === 'number' || d.kind === 'univ') return Number(raw);
    if (d.kind === 'bool') return raw === true || raw === 'true';
    return raw;
  }
  function setPlan(n, path, v) {
    M.setPath(n.plan, path, v);
    Store.save();
  }

  P.mount = function (el) {
    const n = node();
    if (!n) return;
    el.addEventListener('segchange', e => {
      const { name, value } = e.detail;
      if (name === 'via') { P.via = value; App.render(); return; }
      if (name === 'sacnBase') { n.sacnBase = value === 'auto' ? 'auto' : Number(value); if (n.last && n.last.raw) { const m = M.mapTable(n.last.raw, { sacnBase: n.sacnBase }); n.last.canon = m.canon; } Store.save(); App.render(); return; }
      setPlan(n, name, parseVal(name, value));
      App.render();
    });
    el.querySelectorAll('[data-path]').forEach(inp => {
      const path = inp.dataset.path;
      inp.addEventListener('change', () => {
        let v = inp.value.trim();
        const d = M.fieldDef(path);
        if (d.kind === 'ip' && v && !U.isIp(v)) { UI.toast('Adresse invalide : ' + v, 'err'); inp.classList.add('bad'); return; }
        setPlan(n, path, parseVal(path, v));
        App.render();
      });
      if (M.fieldDef(path).kind === 'univ') {
        inp.addEventListener('input', () => {
          const ma = el.querySelector('[data-ma="' + path + '"]');
          const c = Store.wanted(n);
          if (ma) ma.textContent = inp.value === '' ? '' : 'MA ' + (c.protocol === 'sacn' ? Number(inp.value) : Number(inp.value) + 1);
        });
      }
    });
  };

  P.enter = function (params) {
    // autre node : on revient sur l'onglet Réglages
    if (params && params.id !== P.lastId) { P.tab = 'cfg'; P.via = 'auto'; P.lastId = params.id; }
    if (params && params.tab) P.tab = params.tab;
    const n = node();
    if (!n) return;
    if (!RT.probe[n.id] && U.isIp(n.ip)) Probe.one(n);
  };

  P.acts = {
    tab: el => { P.tab = el.dataset.arg; App.render(true); },
    read: () => C.read(node(), P.via),
    apply: async () => {
      const n = node();
      const pend = Store.pending(n);
      const target = M.unflat(Object.fromEntries(pend.map(d => [d.path, d.want])));
      if (!n.last) Object.assign(target, n.plan);
      const ok = pend.length > 6 || pend.some(d => /^(ip|mask|ipMode)$/.test(d.path)) ?
        await UI.confirm('Appliquer', 'Écrire dans <b>' + esc(Store.label(n)) + '</b> :<ul>' + pend.map(d => '<li>' + esc(d.label) + ' : ' + esc(fmtVal(d.path, d.have)) + ' → <b>' + esc(fmtVal(d.path, d.want)) + '</b></li>').join('') + '</ul>' +
          (pend.some(d => /^(ip|mask|ipMode)$/.test(d.path)) ? '<p class="warn">L\'adresse du node change : il sera joint ensuite à sa nouvelle adresse.</p>' : ''), 'Écrire') : true;
      if (ok) await C.apply(n, P.via, target);
    },
    web: () => C.openWeb(node()),
    menu: () => P.menu(),
    unplan: el => { const n = node(); setPlan(n, el.dataset.arg, undefined); App.render(); },
    adopt: () => { const n = node(); Store.pending(n).forEach(d => M.setPath(n.plan, d.path, undefined)); Store.save(); App.render(); },
    reveal: el => { const i = document.querySelector('[data-path="' + el.dataset.arg + '"]'); if (i) i.type = i.type === 'password' ? 'text' : 'password'; },
    pollOne: async () => { const n = node(); const m = await Disco.pollOne(n.ip, 1500); if (m) { RT.poll[n.id] = m; Disco.live[m.ip] = Object.assign(m, { at: Date.now() }); Disco.match(m); UI.toast('Réponse Art-Net reçue'); } else UI.toast('Pas de réponse Art-Net', 'err'); App.render(); },
    probe: async () => { const ok = await Probe.one(node()); UI.toast(ok ? 'La page web répond' : 'La page web ne répond pas', ok ? '' : 'err'); App.render(); },
    identify: async () => UI.toast(await Ops.action(node(), 'identify')),
    histView: el => {
      const e = node().history[+el.dataset.arg];
      const f = M.flat(e.canon);
      UI.alert('Lecture du ' + U.fmtDate(e.at), '<table class="raw">' + Object.keys(f).map(k => '<tr><th>' + esc(M.pathLabel(k)) + '</th><td>' + esc(fmtVal(k, f[k])) + '</td></tr>').join('') + '</table>');
    },
    histUse: async el => {
      const n = node();
      const e = n.history[+el.dataset.arg];
      if (!await UI.confirm('Reprendre', 'Remplacer la config prévue par celle lue le ' + esc(U.fmtDate(e.at)) + ' ?', 'Reprendre')) return;
      n.plan = U.clone(e.canon);
      ['firmware', 'serial', 'ipNow'].forEach(k => delete n.plan[k]);
      Store.save();
      P.tab = 'cfg';
      App.render();
    },
    rawEdit: async el => {
      const n = node();
      if (!(USB.state === 'ready' && USB.nodeId === n.id)) { UI.toast('Branche le node en USB pour modifier un paramètre brut', 'err'); return; }
      const p = USB.info.table.params.find(x => x.index === +el.dataset.arg);
      const f = { key: 'v', label: p.label, value: p.value };
      if (p.type === 4) { f.type = 'select'; f.options = p.options.map((o, i) => [i, o]); }
      else if (p.type === 0) { f.type = 'number'; f.min = p.min; f.max = p.max; }
      const v = await UI.form('Paramètre « ' + p.label + ' »', [f], 'Écrire', { validate: v => ECHid.validate(p, p.type === 4 || p.type === 0 ? Number(v.v) : v.v) });
      if (!v) return;
      try {
        const val = p.type === 4 || p.type === 0 ? Number(v.v) : v.v;
        await USB.client.writeValue(p, val);
        const got = await USB.client.readValue(p);
        await USB.read();
        Store.log(n, 'Paramètre « ' + p.label + ' » écrit (USB)', U.same(got, val), 'relu ' + got);
        UI.toast(U.same(got, val) ? 'Écrit et vérifié' : 'Écrit, mais le node renvoie ' + got, U.same(got, val) ? '' : 'err');
      } catch (e) { UI.toast(e.message, 'err'); }
      App.render();
    },
    exportDmxTools: () => {
      const n = node();
      Bridge.saveFile(JSON.stringify(M.toDmxToolsJson(n.last.raw), null, 1), (Store.label(n) || 'node').replace(/[^\w-]+/g, '_') + '.json', 'application/json');
    },
    importDmxTools: async () => {
      const n = node();
      let f;
      try { f = await Bridge.pickFile('application/json'); } catch (e) { return; }
      try {
        const obj = JSON.parse(U.utf8dec(f.bytes));
        const raw = n.last && n.last.raw;
        if (!raw) throw new Error('lis d\'abord le node (USB) pour connaître ses paramètres');
        const vals = M.parseDmxToolsJson(obj, raw);
        const t = U.clone(raw);
        vals.forEach(v => { const p = t.params.find(x => x.index === v.index); if (p && !p.readonly) p.value = v.value; });
        const m = M.mapTable(t, { sacnBase: n.sacnBase });
        const f2 = M.flat(m.canon);
        Object.keys(f2).forEach(k => { if (M.fieldDef(k) && M.fieldDef(k).kind !== 'ro') M.setPath(n.plan, k, f2[k]); });
        Store.save();
        UI.toast(vals.length + ' valeurs importées dans le prévu : vérifie puis Appliquer');
        P.tab = 'cfg';
        App.render();
      } catch (e) { UI.toast('Import impossible : ' + e.message, 'err'); }
    },
    diag: () => {
      const n = node();
      UI.dialog({ title: 'Ce que l\'appli lit dans la page', wide: true, body: '<pre class="pre">' + esc(n.last.scanText) + '</pre>', buttons: [{ label: 'Partager', value: 'share' }, { label: 'Fermer', value: null, kind: 'primary' }] })
        .then(v => { if (v === 'share') Bridge.share(n.last.scanText, 'Page du node ' + Store.label(n)); });
    }
  };

  P.menu = async function () {
    const n = node();
    const usbOk = USB.state === 'ready' && USB.nodeId === n.id;
    const v = await UI.choose(Store.label(n), [
      { label: 'Modifier nom, IP, étiquettes, identifiants…', value: 'edit' },
      { label: 'Lire par USB', value: 'r-usb', disabled: !usbOk },
      { label: 'Lire par la page web', value: 'r-web', disabled: !U.isIp(n.ip) },
      { label: 'Lire en Art-Net (partiel)', value: 'r-art', disabled: !U.isIp(n.ip) },
      { label: 'Garder la config lue comme prévue', hint: 'efface les écarts', value: 'adopt', disabled: !n.last },
      { label: 'Effacer tout le prévu', value: 'clear' },
      { label: 'Identifier (Art-Net)', value: 'identify', disabled: !U.isIp(n.ip) },
      { label: 'Mettre à jour le firmware…', value: 'fw' },
      { label: 'Reset usine…', value: 'reset', danger: true },
      { label: 'Dupliquer / supprimer…', value: 'more' }
    ]);
    if (!v) return;
    if (v === 'edit') { await C.nodeForm(n); App.render(); }
    else if (v === 'r-usb') await C.read(n, 'usb');
    else if (v === 'r-web') await C.read(n, 'web');
    else if (v === 'r-art') { const r = await C.read(n, 'artnet'); if (r) { P.tab = 'state'; App.render(); } }
    else if (v === 'adopt') P.acts.adopt();
    else if (v === 'clear') { if (await UI.confirm('Effacer le prévu', 'Oublier toutes les valeurs prévues de ce node ?', 'Effacer', true)) { n.plan = { ports: [] }; Store.save(); App.render(); } }
    else if (v === 'identify') UI.toast(await Ops.action(n, 'identify'));
    else if (v === 'fw') App.go('firmware', { id: n.id });
    else if (v === 'reset') {
      if (!await UI.confirm('Reset usine', '<b>' + esc(Store.label(n)) + '</b> va perdre tous ses réglages (retour en DHCP, noms et univers par défaut).<br><br>Sa config prévue reste dans l\'appli : tu pourras la réécrire par USB.', 'Remettre à zéro', true)) return;
      try { UI.toast(await Ops.action(n, 'reset', P.via)); } catch (e) { UI.toast(e.message, 'err'); }
      App.render();
    } else if (v === 'more') C.nodeMenu(n);
  };

  P.padTab = d => {
    const i = TABS.findIndex(t => t[0] === P.tab);
    P.tab = TABS[(i + d + TABS.length) % TABS.length][0];
    App.render(true);
  };
  P.padStart = () => { const n = node(); if (n && Store.pending(n).length) P.acts.apply(); else UI.toast('Rien à appliquer'); };
  P.padY = () => P.acts.read();
  P.padX = () => P.menu();
  P.padHelp = { X: 'menu du node', Y: 'lire le node', START: 'appliquer le prévu', L1: 'onglet précédent / suivant' };

  App.Pages.fiche = P;
})();
