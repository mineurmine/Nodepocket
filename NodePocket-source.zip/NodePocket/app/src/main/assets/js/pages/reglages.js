/* Page « Réglages » : réseau, écriture, console portable, données, journal */
(function () {
  'use strict';
  const esc = U.esc;
  const P = { sec: 'mode' };
  const SECS_FULL = [['mode', 'Mode'], ['net', 'Réseau'], ['write', 'Écriture'], ['pad', 'Console & affichage'], ['data', 'Données'], ['log', 'Journal'], ['about', 'À propos']];
  // mode simple : seulement de quoi revenir au mode complet et régler l'affichage
  const SECS_SIMPLE = [['mode', 'Mode'], ['pad', 'Console & affichage'], ['about', 'À propos']];
  const secs = () => (App.simple() ? SECS_SIMPLE : SECS_FULL);

  function row(key, label, type, hint, extra) {
    const s = Store.settings();
    const v = s[key];
    let ctl;
    if (type === 'bool') ctl = UI.seg('set:' + key, [['false', 'Non'], ['true', 'Oui']], String(!!v));
    else if (type === 'select') ctl = '<select data-set="' + key + '">' + extra.map(o => '<option value="' + esc(o[0]) + '"' + (String(o[0]) === String(v) ? ' selected' : '') + '>' + esc(o[1]) + '</option>').join('') + '</select>';
    else ctl = '<input type="' + (type === 'number' ? 'number' : type === 'password' ? 'password' : 'text') + '" data-set="' + key + '" value="' + esc(v == null ? '' : v) + '"' + (extra || '') + ' autocomplete="off" autocapitalize="off" spellcheck="false">';
    return '<div class="fld"><label>' + esc(label) + '</label><div class="ctl">' + ctl + '</div>' + (hint ? '<div class="muted small">' + hint + '</div>' : '') + '</div>';
  }

  function secMode() {
    const simple = App.simple();
    return '<section class="box"><h3>Mode de l\'appli</h3>' +
      '<div class="fld"><label>Affichage</label><div class="ctl">' + UI.seg('set:simple', [['false', 'Mode complet'], ['true', 'Mode simple']], String(simple)) + '</div>' +
      '<div class="muted small">' + (simple ? 'Mode simple : la liste des nodes, et pour chacun l\'adresse IP, Art-Net ou sACN et l\'univers de chaque port. Rien d\'autre à toucher.' :
        'Mode complet : parc, plan d\'univers, modifications en lot, firmware, sauvegardes, moniteur. Le mode simple est fait pour les techniciens : juste l\'IP, le protocole et l\'univers de chaque port.') + '</div></div></section>';
  }
  function secNet() {
    const ifs = Bridge.netInfo();
    return '<section class="box"><h3>Cet appareil</h3>' + (ifs.length ? '<table class="kv">' + ifs.map(i => '<tr><th>' + esc(i.name) + '</th><td>' + esc(i.ip) + ' / ' + i.prefix + ' · diffusion ' + esc(i.broadcast || '—') + '</td></tr>').join('') + '</table>' : '<p class="warn">Aucune interface réseau active.</p>') +
      '<p class="muted small">Art-Net : ' + esc(Disco.detail || Disco.status) + '. Adresses de recherche : ' + esc(Disco.targets().join(', ')) + '</p></section>' +
      '<section class="box"><h3>Réseau de la régie</h3>' +
      row('subnetIp', 'Adresse du réseau', 'text', 'sert aux vérifications (nodes hors réseau) et aux séries d\'adresses', ' inputmode="decimal"') +
      row('subnetMask', 'Masque', 'text', '', ' inputmode="decimal"') +
      row('expected', 'Univers de la console (MA)', 'text', 'ex. 1-12 : repère les univers qu\'aucun node ne sort') + '</section>' +
      '<section class="box"><h3>Découverte</h3>' +
      row('autoPoll', 'Recherche Art-Net automatique', 'bool') +
      row('pollEvery', 'Toutes les (secondes)', 'number', '', ' min="2" max="120"') +
      row('broadcasts', 'Adresses de diffusion en plus', 'text', 'ex. 10.255.255.255 (séparées par des virgules)') +
      row('probeEvery', 'Test de la page web toutes les (secondes)', 'number', 'pour les nodes qui ne répondent pas en Art-Net', ' min="5" max="600"') + '</section>';
  }
  function secWrite() {
    return '<section class="box"><h3>Pages web des nodes</h3>' +
      row('defaultUser', 'Utilisateur par défaut', 'text', 'quand la page de login est activée sur un node') +
      row('defaultPass', 'Mot de passe par défaut', 'password') +
      row('webTimeout', 'Délai de chargement (secondes)', 'number', '', ' min="3" max="60"') +
      row('webApply', 'Bouton « Appliquer » (avancé)', 'text', 'expression régulière ; vide = automatique (Apply, Appliquer, Valider…)') + '</section>' +
      '<section class="box"><h3>USB</h3>' +
      row('usbAllParams', 'Renvoyer tous les paramètres', 'bool', 'comme le bouton Appliquer de dmx-tools ; sinon seuls les réglages modifiés sont envoyés (puis relus)') + '</section>' +
      '<section class="box"><h3>Art-Net</h3>' +
      row('artnetWrite', 'Autoriser l\'écriture Art-Net standard', 'bool', 'ArtAddress / ArtIpProg : noms, univers, protocole, adresse. Utilisé seulement si tu choisis « Art-Net » dans une fiche.') +
      row('numbering', 'Affichage des univers', 'select', '', [['both', 'Réseau + MA'], ['net', 'Réseau (comme le node)'], ['ma', 'Numérotation MA2']]) + '</section>';
  }
  function secPad() {
    return '<section class="box"><h3>Console portable (RG556…)</h3>' +
      row('swapAB', 'Inverser A et B', 'bool', 'si ta console a la disposition Nintendo') +
      row('immersive', 'Plein écran', 'bool') +
      row('orientation', 'Orientation', 'select', '', [['auto', 'Automatique'], ['landscape', 'Paysage'], ['portrait', 'Portrait']]) +
      row('keepScreenOn', 'Garder l\'écran allumé', 'bool') +
      row('zoom', 'Taille du texte (%)', 'number', '', ' min="70" max="160" step="5"') +
      '<div class="row-btns"><button type="button" class="btn sm" data-act="help">Voir les boutons</button></div></section>';
  }
  function secData() {
    const st = Store.state;
    return '<section class="box"><h3>Données</h3><p class="muted">' + U.plural(st.nodes.length, 'node') + ', ' + U.plural(st.prods.length, 'sauvegarde') + ', ' + st.journal.length + ' entrées de journal. Tout est enregistré dans l\'appareil à chaque changement.</p>' +
      '<div class="row-btns"><button type="button" class="btn" data-act="exportAll">Exporter</button><button type="button" class="btn" data-act="importAll">Importer…</button><button type="button" class="btn" data-act="csv">Feuille de patch (CSV)</button></div></section>' +
      '<section class="box"><h3>Remise à zéro</h3><div class="row-btns"><button type="button" class="btn" data-act="clearRead">Oublier les configs lues</button><button type="button" class="btn danger" data-act="wipe">Tout effacer…</button></div></section>';
  }
  function secLog() {
    const j = Store.state.journal.slice(-150).reverse();
    return '<section class="box"><h3>Journal <small>' + j.length + ' dernières opérations</small></h3><div class="row-btns"><button type="button" class="btn sm" data-act="shareLog">Partager</button><button type="button" class="btn sm" data-act="clearLog">Vider</button></div>' +
      (j.length ? '<table class="raw">' + j.map(x => '<tr class="' + (x.ok ? '' : 'bad') + '"><td class="nowrap">' + esc(U.fmtDate(x.at)) + '</td><td>' + esc(x.node) + '</td><td>' + (x.ok ? '✓ ' : '✗ ') + esc(x.what) + '</td><td class="muted">' + esc(x.detail) + '</td></tr>').join('') + '</table>' : '<p class="muted">Vide.</p>') + '</section>';
  }
  function secAbout() {
    const brands = Brands.LIST.filter(b => b.id !== 'generic');
    return '<section class="box about"><h3>Node Pocket ' + esc(Bridge.appVersion()) + '</h3><p class="sigline">' + esc(App.SIGNATURE) + '</p><p class="muted">' + esc(Bridge.deviceInfo()) + '</p>' +
      '<h4>Comment l\'appli parle aux nodes</h4><ul class="txt">' +
      '<li><b>USB</b> (Electroconcept) : même protocole que dmx-tools (HID 1FC9:0052, rapports de 64 octets). Le node décrit lui-même ses réglages : rien n\'est figé dans l\'appli.</li>' +
      '<li><b>Page web</b> : l\'appli ouvre la page du node en arrière-plan, remplit les champs, clique sur Appliquer puis relit la page pour vérifier. Elle reconnaît les libellés courants (IP, Net / Sub-Net / Universe, protocole, sens des ports…).</li>' +
      '<li><b>API Luminex</b> : identité, firmware, identification, redémarrage et reset des LumiNode / LumiCore.</li>' +
      '<li><b>Art-Net</b> : recherche (ArtPoll), marque et modèle (code OEM), état des ports en direct, identification ; écriture standard (ArtAddress, ArtIpProg) si le node la gère.</li>' +
      '<li><b>Firmware</b> (Electroconcept) : passage en DFU comme dmx-tools, puis envoi du fichier par la norme USB DFU.</li></ul>' +
      '<h4>Marques</h4><table class="raw">' + brands.map(b => '<tr><th>' + esc(b.name) + '</th><td>' + ({ full: 'réglage', partial: 'réglage partiel', readonly: 'lecture seule' }[b.level]) + '</td><td class="muted">' + esc(b.note) + '</td></tr>').join('') + '</table>' +
      '<p class="muted small">Les parties qui n\'ont pas encore pu être vérifiées sur un vrai node (pages web réelles, mode DFU) s\'arrêtent sans rien écrire en cas de doute, et ont un diagnostic à partager.</p>' +
      '<p class="sigline">Node Pocket — ' + esc(App.SIGNATURE) + '</p></section>';
  }

  P.render = function () {
    if (!secs().some(x => x[0] === P.sec)) P.sec = 'mode';
    let h = '<div class="pghead"><h1>Réglages</h1></div><div class="tabs">' + secs().map(s => '<button type="button" class="tab' + (P.sec === s[0] ? ' on' : '') + '" data-act="sec" data-arg="' + s[0] + '">' + s[1] + '</button>').join('') + '</div><div class="tabbody">';
    h += ({ mode: secMode, net: secNet, write: secWrite, pad: secPad, data: secData, log: secLog, about: secAbout }[P.sec] || secMode)();
    return h + '</div>';
  };

  function setVal(key, raw) {
    const s = Store.settings();
    const def = Store.DEFAULT_SETTINGS[key];
    let v = raw;
    if (typeof def === 'number') { v = Number(raw); if (!isFinite(v)) v = def; }
    if (typeof def === 'boolean') v = raw === true || raw === 'true';
    if ((key === 'subnetIp' || key === 'subnetMask') && v && !U.isIp(v)) { UI.toast('Adresse invalide', 'err'); return; }
    s[key] = v;
    Store.save();
    if (['zoom', 'immersive', 'orientation', 'keepScreenOn'].indexOf(key) >= 0) App.applyDisplay();
    if (key === 'simple') { App.stack = []; App.render(true); UI.toast(v ? 'Mode simple : IP, protocole et univers' : 'Mode complet'); }
  }

  P.mount = function (el) {
    el.addEventListener('change', e => {
      const x = e.target.closest('[data-set]');
      if (!x || App.page !== 'reglages') return;
      setVal(x.dataset.set, x.value);
      App.render();
    });
    el.addEventListener('segchange', e => {
      if (e.detail.name.indexOf('set:') === 0) { setVal(e.detail.name.slice(4), e.detail.value); App.render(); }
    });
  };

  P.acts = {
    sec: el => { P.sec = el.dataset.arg; App.render(true); },
    help: () => App.help(),
    exportAll: () => App.Pages.prods.acts.exportAll(),
    importAll: () => App.Pages.prods.acts.importAll(),
    csv: () => App.Pages.prods.acts.csv(),
    clearRead: async () => {
      if (!await UI.confirm('Oublier', 'Effacer les configs lues de tous les nodes (le parc et le prévu restent) ?', 'Effacer', true)) return;
      Store.nodes().forEach(n => { n.last = null; n.history = []; });
      Store.save(); App.render();
    },
    wipe: async () => {
      if (!await UI.confirm('Tout effacer', 'Supprimer le parc, les sauvegardes, le journal et les réglages ? Pense à exporter avant.', 'Tout effacer', true)) return;
      Store.state = Store.migrate(null);
      Store.state.welcomed = true;
      Store.save(true);
      App.go('parc', {}, { replace: true });
    },
    shareLog: () => Bridge.share(Store.state.journal.slice(-300).map(x => U.fmtDate(x.at) + ' ' + (x.ok ? 'OK ' : 'ÉCHEC ') + x.node + ' — ' + x.what + (x.detail ? ' (' + x.detail + ')' : '')).join('\n'), 'Journal Node Pocket'),
    clearLog: () => { Store.state.journal = []; Store.save(); App.render(); }
  };
  P.padTab = d => {
    const L = secs();
    const i = L.findIndex(s => s[0] === P.sec);
    P.sec = L[(i + d + L.length) % L.length][0];
    App.render(true);
  };
  P.padHelp = { L1: 'section précédente / suivante' };
  App.Pages.reglages = P;
})();
