/* Page « Sauvegardes » : configs du parc par production, comparaison, restauration */
(function () {
  'use strict';
  const esc = U.esc, C = App.C, M = Model;
  const P = { open: null };
  const RO = ['firmware', 'serial', 'ipNow'];

  function strip(c) {
    const x = U.clone(c || { ports: [] });
    RO.forEach(k => delete x[k]);
    return x;
  }

  function list() {
    const prods = Store.state.prods.slice().sort((a, b) => b.at - a.at);
    let h = '<div class="pghead"><h1>Sauvegardes <small>' + U.plural(prods.length, 'sauvegarde') + '</small></h1><div class="tools">' +
      '<button type="button" class="btn primary" data-act="snap" data-fid="p_snap">+ Nouvelle sauvegarde</button>' +
      '<button type="button" class="btn" data-act="importProd">Importer…</button></div></div>';
    if (!prods.length) h += '<div class="empty muted">Une sauvegarde garde la config de tous les nodes (ou ceux d\'une production) à un instant donné. Tu peux ensuite comparer, ou tout remettre comme avant en un geste.</div>';
    else h += '<div class="grid">' + prods.map(p => '<div class="card" data-act="openProd" data-arg="' + p.id + '" tabindex="0" data-fid="p_' + p.id + '"><div class="c-h"><b class="nm">' + esc(p.name) + '</b></div>' +
      '<div class="c-m muted">' + esc(U.fmtDate(p.at)) + ' · ' + U.plural(Object.keys(p.nodes).length, 'node') + ' · ' + (p.source === 'read' ? 'config lue' : 'config prévue') + '</div>' + (p.note ? '<div class="c-f">' + esc(p.note) + '</div>' : '') + '</div>').join('') + '</div>';
    h += '<section class="box"><h3>Tout le parc</h3><div class="row-btns"><button type="button" class="btn" data-act="exportAll">Exporter toutes les données</button><button type="button" class="btn" data-act="importAll">Importer des données…</button><button type="button" class="btn" data-act="csv">Feuille de patch (CSV)</button></div>' +
      '<p class="muted small">Le fichier exporté contient le parc, les configs prévues et lues, les sauvegardes et les réglages : de quoi passer d\'un appareil à l\'autre.</p></section>';
    return h;
  }

  function detail(p) {
    const ids = Object.keys(p.nodes);
    let h = '<div class="pghead"><button type="button" class="btn icon" data-act="close" aria-label="Retour">‹</button><h1>' + esc(p.name) + ' <small>' + esc(U.fmtDate(p.at)) + '</small></h1><div class="tools">' +
      '<button type="button" class="btn primary" data-act="restore" data-fid="p_restore">Remettre cette config…</button><button type="button" class="btn" data-act="prodMenu">⋯</button></div></div>';
    if (p.note) h += '<p class="muted">' + esc(p.note) + '</p>';
    h += '<table class="raw"><thead><tr><th>Node</th><th>Adresse</th><th>Protocole</th><th>Ports</th><th>Aujourd\'hui</th></tr></thead><tbody>' + ids.map(id => {
      const e = p.nodes[id];
      const n = Store.node(id);
      const c = e.canon;
      const cur = n ? ((n.last && n.last.canon) || null) : null;
      const diff = cur ? M.diff(strip(c), cur) : null;
      return '<tr><td>' + esc(e.name) + (n ? '' : ' <small class="warn">(plus dans le parc)</small>') + '</td><td>' + esc(c.ipMode === 'dhcp' ? 'DHCP' : (c.ip || e.ip || '—')) + '</td><td>' + C.protoName(c.protocol) + '</td><td>' +
        (c.ports || []).map((pt, i) => { const pu = M.portUniverse(c, pt); return pu ? (i + 1) + (pu.dir === 'in' ? '◂' : '▸') + pu.univ : ''; }).filter(Boolean).join(' ') + '</td><td>' +
        (!n ? '' : !cur ? '<span class="muted">jamais lu</span>' : diff.length ? '<span class="warn" title="' + esc(diff.map(d => d.label).join(', ')) + '">' + U.plural(diff.length, 'différence') + '</span>' : '<span class="ok">identique</span>') + '</td></tr>';
    }).join('') + '</tbody></table>';
    return h;
  }

  P.render = function () {
    const p = P.open && Store.state.prods.find(x => x.id === P.open);
    return p ? detail(p) : list();
  };

  P.acts = {
    openProd: el => { P.open = el.dataset.arg; App.render(true); },
    close: () => { P.open = null; App.render(true); },
    snap: async () => {
      const tags = C.allTags();
      const v = await UI.form('Nouvelle sauvegarde', [
        { key: 'name', label: 'Nom', value: 'Config du ' + U.fmtDate(Date.now()).slice(0, 10), autofocus: true },
        { key: 'src', label: 'Quelle config ?', type: 'select', value: 'read', options: [['read', 'Config lue (l\'état réel des nodes)'], ['readnow', 'Lire d\'abord les nodes en ligne, puis sauvegarder'], ['want', 'Config prévue']] },
        { key: 'tag', label: 'Nodes', type: 'select', value: '', options: [['', 'Tout le parc']].concat(tags.map(t => [t, 'Production « ' + t + ' »'])) },
        { key: 'note', label: 'Note', type: 'textarea', rows: 2, value: '' }
      ], 'Sauvegarder');
      if (!v) return;
      const nodes = Store.nodes().filter(n => !v.tag || (n.tags || []).indexOf(v.tag) >= 0);
      if (v.src === 'readnow') {
        const on = nodes.filter(n => RT.isOnline(n) || USB.nodeId === n.id);
        if (on.length) await C.readMany(on);
      }
      const prod = { id: U.uid('p'), name: v.name.trim() || 'Sauvegarde', at: Date.now(), note: v.note, source: v.src === 'want' ? 'want' : 'read', tag: v.tag, nodes: {} };
      let skipped = 0;
      nodes.forEach(n => {
        const c = v.src === 'want' ? Store.wanted(n) : (n.last && n.last.canon);
        if (!c) { skipped++; return; }
        prod.nodes[n.id] = { name: Store.label(n), ip: n.ip, model: n.model, canon: U.clone(c) };
      });
      Store.state.prods.push(prod);
      Store.save();
      UI.toast(U.plural(Object.keys(prod.nodes).length, 'node') + ' sauvegardé' + (Object.keys(prod.nodes).length > 1 ? 's' : '') + (skipped ? ' (' + skipped + ' jamais lu' + (skipped > 1 ? 's' : '') + ')' : ''));
      P.open = prod.id;
      App.render(true);
    },
    restore: async () => {
      const p = Store.state.prods.find(x => x.id === P.open);
      const ids = Object.keys(p.nodes).filter(id => Store.node(id));
      const chosen = await C.pickNodes('Remettre la config de « ' + p.name + ' »', ids, n => ids.indexOf(n.id) >= 0);
      if (!chosen || !chosen.length) return;
      chosen.forEach(id => {
        const n = Store.node(id);
        n.plan = strip(p.nodes[id].canon);
        Store.log(n, 'Config prévue reprise de « ' + p.name + ' »', true);
      });
      Store.save();
      const ns = chosen.map(id => Store.node(id));
      const pend = ns.filter(n => Store.pending(n).length);
      if (!pend.length) { UI.toast('Config prévue mise à jour : les nodes sont déjà conformes'); App.render(); return; }
      if (await UI.confirm('Appliquer', U.plural(pend.length, 'node') + ' diffèrent de cette sauvegarde. Les écrire maintenant ?', 'Appliquer')) await C.applyMany(pend);
      else App.render();
    },
    prodMenu: async () => {
      const p = Store.state.prods.find(x => x.id === P.open);
      const v = await UI.choose(p.name, [{ label: 'Renommer / note…', value: 'ren' }, { label: 'Exporter cette sauvegarde', value: 'exp' }, { label: 'Supprimer', value: 'del', danger: true }]);
      if (v === 'ren') {
        const r = await UI.form('Renommer', [{ key: 'name', label: 'Nom', value: p.name }, { key: 'note', label: 'Note', type: 'textarea', value: p.note || '' }], 'OK');
        if (r) { p.name = r.name.trim() || p.name; p.note = r.note; Store.save(); App.render(); }
      } else if (v === 'exp') {
        Bridge.saveFile(JSON.stringify({ app: 'Node Pocket', format: 1, prod: p }, null, 1), 'sauvegarde-' + p.name.replace(/[^\w-]+/g, '_') + '.json', 'application/json');
      } else if (v === 'del') {
        if (await UI.confirm('Supprimer', 'Supprimer la sauvegarde « ' + esc(p.name) + ' » ?', 'Supprimer', true)) {
          Store.state.prods = Store.state.prods.filter(x => x.id !== p.id);
          Store.save(); P.open = null; App.render(true);
        }
      }
    },
    importProd: async () => {
      let f;
      try { f = await Bridge.pickFile('application/json'); } catch (e) { return; }
      try {
        const o = JSON.parse(U.utf8dec(f.bytes));
        if (o.prod && o.prod.nodes) {
          o.prod.id = U.uid('p');
          Store.state.prods.push(o.prod);
          Store.save();
          UI.toast('Sauvegarde importée');
        } else if (o.state || o.nodes) {
          await P.acts.importAll(null, o);
          return;
        } else throw new Error('format inconnu');
      } catch (e) { UI.toast('Import impossible : ' + e.message, 'err'); }
      App.render();
    },
    exportAll: () => Bridge.saveFile(Store.exportAll(), 'node-pocket-' + new Date().toISOString().slice(0, 10) + '.json', 'application/json'),
    importAll: async (el, obj) => {
      let txt;
      if (obj) txt = JSON.stringify(obj);
      else {
        let f;
        try { f = await Bridge.pickFile('application/json'); } catch (e) { return; }
        txt = U.utf8dec(f.bytes);
      }
      const mode = await UI.choose('Importer les données', [{ label: 'Fusionner avec mon parc', hint: 'ajoute et met à jour les nodes', value: 'merge' }, { label: 'Remplacer tout', hint: 'efface le parc actuel', value: 'replace', danger: true }]);
      if (!mode) return;
      try { UI.toast(Store.importAll(txt, mode)); } catch (e) { UI.toast('Import impossible : ' + e.message, 'err'); }
      App.render();
    },
    csv: () => Bridge.saveFile('﻿' + Store.csv(), 'patch-nodes-' + new Date().toISOString().slice(0, 10) + '.csv', 'text/csv')
  };
  P.padStart = () => (P.open ? P.acts.restore() : P.acts.snap());
  P.padHelp = { START: 'nouvelle sauvegarde / remettre la config' };
  P.leave = () => { P.open = null; };
  P.back = () => { if (!P.open) return false; P.open = null; App.render(true); return true; };
  App.Pages.prods = P;
})();
