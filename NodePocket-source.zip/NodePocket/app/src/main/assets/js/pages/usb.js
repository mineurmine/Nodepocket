/* Page « USB » : le node branché à la console / au téléphone */
(function () {
  'use strict';
  const esc = U.esc, C = App.C, M = Model;
  const P = { live: true };

  function summary(c) {
    if (!c) return '';
    const rows = [
      ['Nom long', c.longName], ['Nom court', c.shortName],
      ['Adressage', c.ipMode === 'dhcp' ? 'DHCP' + (c.ipNow ? ' (' + c.ipNow + ')' : '') : (c.ip || '—') + ' / ' + (c.mask || '—')],
      ['Protocole', C.protoName(c.protocol)], ['Sortie DMX', M.enumLabel('outMode', c.outMode) + (c.outMode && c.outMode !== 'sync' && c.fps ? ' · ' + c.fps + ' i/s' : '')],
      ['Firmware', c.firmware ? U.fmtFirmware(c.firmware) : ''], ['N° de série', c.serial]
    ];
    let h = '<table class="kv">' + rows.filter(r => r[1] != null && r[1] !== '').map(r => '<tr><th>' + esc(r[0]) + '</th><td>' + esc(r[1]) + '</td></tr>').join('') + '</table>';
    h += '<div class="ports">' + (c.ports || []).map((p, i) => {
      const pu = M.portUniverse(c, p);
      return '<span class="pt ' + (p.dir === 'in' ? 'in' : 'out') + '"><b>' + (i + 1) + '</b>' + (p.dir === 'in' ? '◂' : '▸') + (pu ? C.univText(pu.proto, pu.univ, true) : '?') + '</span>';
    }).join('') + '</div>';
    return h;
  }

  function devLine(d) {
    const kind = USB.isEc(d) ? 'Electroconcept (HID)' : USB.isDfu(d) ? 'mode mise à jour (DFU)' : (d.interfaces || []).map(i => 'classe ' + i.cls).join(', ');
    return '<tr><td>' + esc(d.vid.toString(16).padStart(4, '0') + ':' + d.pid.toString(16).padStart(4, '0')) + '</td><td>' + esc((d.manufacturer || '') + ' ' + (d.product || '')) + '</td><td>' + esc(kind) + '</td><td>' + (d.permission ? 'autorisé' : '—') + '</td></tr>';
  }

  P.render = function () {
    let h = '<div class="pghead"><h1>USB <small>node branché à l\'appareil</small></h1><div class="tools"><button type="button" class="btn" data-act="rescan" data-fid="u_rescan">Actualiser</button></div></div>';
    if (!Bridge.usbAvailable()) return h + '<div class="empty">Cet appareil ne gère pas l\'USB hôte (OTG) : impossible de piloter un node en USB.</div>';
    const s = USB.scan();
    if (s.dfu) {
      h += '<section class="box warnbox"><h3>Node en mode mise à jour (DFU)</h3><p>Un périphérique DFU est branché (' + esc(s.dfu.vid.toString(16) + ':' + s.dfu.pid.toString(16)) + '). Le firmware se charge depuis l\'onglet Firmware.</p>' +
        '<div class="row-btns"><button type="button" class="btn primary" data-act="toFw">Aller à Firmware</button></div></section>';
    }
    const st = USB.state;
    if (st === 'none' && !s.ec) {
      h += '<section class="box hero"><div class="big">' + App.icon('usb', 'xl') + '</div><h3>Branche un node en USB</h3><p class="muted">Câble USB-C (OTG) entre la console et le port USB du node : il est alimenté par la console et l\'appli le reconnaît toute seule. Pratique quand le réseau n\'est pas encore installé.</p></section>';
    } else if (st === 'perm') {
      h += '<section class="box hero"><h3>Autorisation USB</h3><p>Accepte l\'accès au node dans la fenêtre d\'Android (coche « toujours » pour ne plus avoir la question).</p><div class="row-btns center"><button type="button" class="btn" data-act="retry">Redemander</button></div></section>';
    } else if (st === 'opening' || st === 'reading' || (st === 'none' && s.ec)) {
      h += '<section class="box hero"><div class="spin"></div><h3>Lecture du node…</h3><p class="muted">' + esc(s.ec ? (s.ec.product || 'Node Electroconcept') : '') + '</p>' + (st === 'none' ? '<div class="row-btns center"><button type="button" class="btn primary" data-act="retry">Connecter</button></div>' : '') + '</section>';
    } else if (st === 'error') {
      h += '<section class="box errbox"><h3>Problème USB</h3><p>' + esc(USB.error) + '</p><div class="row-btns"><button type="button" class="btn primary" data-act="retry">Réessayer</button></div></section>';
    } else if (st === 'ready' && USB.info) {
      const info = USB.info;
      const c = info.mapped ? info.mapped.canon : null;
      const n = USB.nodeId && Store.node(USB.nodeId);
      h += '<section class="box usbnode"><h3>' + esc(info.product || 'Node') + ' ' + UI.badge('branché', 'usb') + '</h3>' +
        '<p class="muted small">' + (info.kind === 'table' ? info.table.params.length + ' paramètres (protocole dmx-tools)' : info.kind === 'gui' ? 'interface web embarquée (firmware 2026)' : 'aucun réglage exposé') + (info.web && info.kind === 'table' ? ' · interface web disponible' : '') + ' · lu ' + esc(U.timeAgo(info.at)) + '</p>' +
        (c ? summary(c) : '') + '</section>';
      if (n) {
        const pend = Store.pending(n);
        h += '<section class="box okbox"><h3>C\'est « ' + esc(Store.label(n)) + ' » du parc</h3>' +
          (pend.length ? '<p class="warn">' + U.plural(pend.length, 'écart') + ' avec la config prévue : ' + pend.slice(0, 5).map(d => esc(d.label)).join(', ') + (pend.length > 5 ? '…' : '') + '</p>' : '<p class="ok">Le node est conforme à la config prévue.</p>') +
          '<div class="row-btns"><button type="button" class="btn ' + (pend.length ? 'primary' : '') + '" data-act="writePlan" data-fid="u_write"' + (pend.length ? '' : ' disabled') + '>Écrire la config prévue</button>' +
          '<button type="button" class="btn" data-act="openNode" data-fid="u_open">Ouvrir la fiche</button>' +
          '<button type="button" class="btn sm" data-act="unlink">Ce n\'est pas ce node</button></div></section>';
      } else {
        // même adresse IP qu'un node du parc pas encore lu en USB : on propose l'association
        const guess = c && c.ipMode === 'static' && U.isIp(c.ip) ? Store.nodes().find(x => (x.ip === c.ip || Store.wanted(x).ip === c.ip) && (!x.serial || x.serial === info.serial)) : null;
        h += '<section class="box warnbox"><h3>Ce node n\'est pas encore dans le parc</h3><p class="muted">N° de série ' + esc(info.serial || 'inconnu') + '.</p>' +
          (guess ? '<p>Il a l\'adresse ' + esc(c.ip) + ', comme « <b>' + esc(Store.label(guess)) + '</b> ». <button type="button" class="btn sm primary" data-act="linkGuess" data-arg="' + guess.id + '" data-fid="u_guess">C\'est lui</button></p>' : '') +
          '<div class="row-btns"><button type="button" class="btn primary" data-act="prepare" data-fid="u_prep">Le préparer comme…</button>' +
          '<button type="button" class="btn" data-act="addNew" data-fid="u_add">L\'ajouter au parc</button>' +
          '<button type="button" class="btn" data-act="link" data-fid="u_link">C\'est un node du parc…</button></div>' +
          '<p class="muted small">« Le préparer comme… » écrit dans ce node la config prévue d\'un node du parc (IP fixe, noms, univers), puis relit pour vérifier.</p></section>';
      }
      h += '<section class="box"><h3>Outils</h3><div class="row-btns">' +
        (info.web ? '<button type="button" class="btn" data-act="gui" data-fid="u_gui">Interface du node</button>' : '') +
        '<button type="button" class="btn" data-act="reread" data-fid="u_reread">Relire</button>' +
        '<button type="button" class="btn" data-act="params">Paramètres bruts</button>' +
        '<button type="button" class="btn" data-act="dfu">Passer en DFU…</button>' +
        '<button type="button" class="btn danger" data-act="reset">Reset usine…</button></div></section>';
    }
    h += '<details class="box"><summary>Inspecteur USB (' + s.list.length + ' périphérique' + (s.list.length > 1 ? 's' : '') + ')</summary>' +
      (s.list.length ? '<table class="raw"><tr><th>VID:PID</th><th>Nom</th><th>Type</th><th>Accès</th></tr>' + s.list.map(devLine).join('') + '</table>' : '<p class="muted">Aucun périphérique USB.</p>') +
      '<div class="row-btns"><button type="button" class="btn sm" data-act="inspect">Rapport détaillé…</button></div></details>';
    return h;
  };

  P.acts = {
    rescan: () => { const s = USB.scan(); if (s.ec && USB.state !== 'ready') USB.connect(s.ec); App.render(); },
    retry: () => { const s = USB.scan(); if (s.ec) USB.connect(s.ec); else UI.toast('Aucun node Electroconcept branché', 'err'); },
    toFw: () => App.go('firmware'),
    openNode: () => App.go('fiche', { id: USB.nodeId }),
    reread: async () => {
      const ctl = UI.progress('Lecture USB');
      try {
        await USB.read((f, p) => ctl.set(f, p.label));
        ctl.done('Lu : ' + (USB.info.kind === 'table' ? USB.info.table.params.length + ' paramètres' : 'interface web'), 'ok');
      } catch (e) { ctl.log(e.message, 'err'); ctl.done('Lecture impossible', 'err'); }
      App.render();
    },
    writePlan: async () => {
      const n = Store.node(USB.nodeId);
      const pend = Store.pending(n);
      const target = M.unflat(Object.fromEntries(pend.map(d => [d.path, d.want])));
      await C.apply(n, 'usb', target);
    },
    unlink: () => { USB.nodeId = null; RT.changed('usb'); },
    linkGuess: el => { USB.associate(Store.node(el.dataset.arg)); App.render(); },
    link: async () => {
      const list = Store.nodes();
      if (!list.length) { UI.toast('Le parc est vide'); return; }
      const id = await UI.choose('Quel node du parc ?', list.map(n => ({ label: Store.label(n), hint: (n.ip || '') + (n.serial ? ' · série ' + n.serial : ' · pas encore lu en USB'), value: n.id })));
      if (!id) return;
      USB.associate(Store.node(id));
      App.render();
    },
    addNew: async () => {
      const info = USB.info;
      const c = info.mapped ? info.mapped.canon : {};
      const n = await C.nodeForm(null, { name: c.shortName || c.longName || info.product, ip: c.ipMode === 'static' ? c.ip : '', model: info.mapped ? (info.mapped.ports > 2 ? 4 : info.mapped.ports || 1) : 4, serial: info.serial, plan: {} });
      if (!n) return;
      USB.associate(n);
      App.render();
    },
    prepare: async () => {
      const list = Store.nodes().filter(n => Object.keys(M.flat(n.plan)).length);
      if (!list.length) { UI.alert('Préparer', 'Aucun node du parc n\'a de config prévue. Ajoute des nodes (ou « Préparer une série » dans le Parc), puis reviens ici.'); return; }
      const id = await UI.choose('Écrire la config prévue de…', list.map(n => ({ label: Store.label(n), hint: (Store.wanted(n).ip || n.ip || 'DHCP') + ' · ' + U.plural(Object.keys(M.flat(n.plan)).length, 'réglage prévu') + (n.serial ? ' · déjà associé à ' + n.serial : ''), value: n.id })), { wide: true });
      if (!id) return;
      const n = Store.node(id);
      const before = USB.info.mapped.canon;
      const diff = M.diff(n.plan, before);
      if (!diff.length) { USB.associate(n); UI.toast('Ce node a déjà exactement cette config'); App.render(); return; }
      const ok = await UI.confirm('Préparer comme « ' + esc(Store.label(n)) + ' »', 'Écrire dans le node USB :<ul>' + diff.map(d => '<li>' + esc(d.label) + ' : ' + esc(d.have == null ? '—' : M.enumLabel(d.path, d.have)) + ' → <b>' + esc(M.enumLabel(d.path, d.want)) + '</b></li>').join('') + '</ul>', 'Écrire');
      if (!ok) return;
      const prevSerial = n.serial;
      USB.nodeId = n.id;
      n.serial = USB.info.serial || n.serial;
      const rep = await C.apply(n, 'usb', U.clone(n.plan));
      if (rep && rep.ok) Store.log(n, 'Préparé par USB (série ' + (USB.info.serial || '?') + ')', true);
      else if (prevSerial !== undefined && !rep) n.serial = prevSerial;
      App.render();
    },
    gui: async () => {
      try {
        UI.toast('Chargement de l\'interface du node…');
        await UsbGui.show();
      } catch (e) { UI.toast(e.message, 'err'); }
    },
    params: () => {
      const info = USB.info;
      if (USB.nodeId) { App.go('fiche', { id: USB.nodeId, tab: 'raw' }); return; }
      const txt = info.kind === 'table' ? ECHid.describe(info.table) : (info.scan ? Scraper.describe(info.scan) : 'rien');
      UI.dialog({ title: 'Paramètres du node USB', wide: true, body: '<pre class="pre">' + esc(txt) + '</pre>', buttons: [{ label: 'Partager', value: 's' }, { label: 'Fermer', value: null, kind: 'primary' }] })
        .then(v => { if (v === 's') Bridge.share(txt, 'Node USB ' + info.product); });
    },
    dfu: async () => {
      const n = USB.nodeId && Store.node(USB.nodeId);
      if (n) { App.go('firmware', { id: n.id }); return; }
      if (!await UI.confirm('Mode DFU', 'Le node va redémarrer en mode mise à jour (DFU) : il ne fonctionnera plus normalement tant qu\'un firmware n\'aura pas été chargé (ou qu\'il n\'aura pas été débranché, selon le modèle).', 'Passer en DFU', true)) return;
      try { UI.toast(await USB.action('dfu')); } catch (e) { UI.toast(e.message, 'err'); }
    },
    reset: async () => {
      const n = USB.nodeId && Store.node(USB.nodeId);
      if (!await UI.confirm('Reset usine', 'Remettre le node USB aux réglages d\'usine (DHCP, noms et univers par défaut) ?' + (n ? '<br><br>La config prévue de « ' + esc(Store.label(n)) + ' » reste dans l\'appli.' : ''), 'Remettre à zéro', true)) return;
      try { UI.toast(await USB.action('reset', null, n)); } catch (e) { UI.toast(e.message, 'err'); }
      App.render();
    },
    inspect: async () => {
      const s = USB.scan();
      const lines = ['Node Pocket ' + Bridge.appVersion() + ' — ' + Bridge.deviceInfo(), 'Périphériques USB : ' + s.list.length];
      for (const d of s.list) {
        lines.push('', '• ' + d.vid.toString(16).padStart(4, '0') + ':' + d.pid.toString(16).padStart(4, '0') + ' ' + (d.manufacturer || '') + ' ' + (d.product || '') + ' (' + d.name + ')' + (d.serial ? ' série ' + d.serial : ''));
        (d.interfaces || []).forEach(i => lines.push('   interface ' + i.id + '/' + i.alt + ' classe ' + i.cls + '/' + i.sub + '/' + i.proto + (i.label ? ' « ' + i.label + ' »' : '') + ' : ' + (i.endpoints || []).map(e => e.dir + ' 0x' + e.addr.toString(16) + ' type ' + e.type + ' ' + e.max + 'o').join(', ')));
        if (d.permission) {
          try {
            const h = USB.dev && USB.dev.name === d.name && USB.h != null ? USB.h : Bridge.usbOpenRaw(d.name, -1);
            lines.push('   descripteurs : ' + U.hex(Bridge.usbRawDescriptors(h)));
            if (h !== USB.h) Bridge.usbClose(h);
          } catch (e) { lines.push('   descripteurs : ' + e.message); }
        } else lines.push('   (autorisation nécessaire pour lire les descripteurs)');
      }
      const txt = lines.join('\n');
      UI.dialog({ title: 'Rapport USB', wide: true, body: '<pre class="pre">' + esc(txt) + '</pre>', buttons: [{ label: 'Autoriser les périphériques', value: 'perm' }, { label: 'Partager', value: 's' }, { label: 'Fermer', value: null, kind: 'primary' }] })
        .then(v => {
          if (v === 's') Bridge.share(txt, 'Rapport USB Node Pocket');
          if (v === 'perm') s.list.filter(d => !d.permission).forEach(d => Bridge.usbPermission(d.name));
        });
    }
  };
  P.padY = () => P.acts.reread();
  P.padStart = () => { if (USB.nodeId) P.acts.writePlan(); else if (USB.state === 'ready') P.acts.prepare(); };
  P.padHelp = { Y: 'relire le node USB', START: 'écrire la config prévue / préparer' };
  App.Pages.usb = P;
})();
