/* Page « Lot » : modifier plusieurs nodes d'un coup (protocole, fréquence, adresses, univers…) */
(function () {
  'use strict';
  const esc = U.esc, C = App.C, M = Model;
  const P = { ids: [], f: null };
  const DEF = { proto: '', outMode: '', fps: 30, addr: '', ip: '', mask: '', univ: '', univVal: 0, dir: '', name: '', namePat: 'NODE-##', login: '', user: 'admin', pass: '', prio: '', prioVal: 100 };

  function chosen() {
    return P.ids.map(id => Store.node(id)).filter(Boolean).sort((a, b) => U.ipCompare(a.ip, b.ip) || Store.label(a).localeCompare(Store.label(b)));
  }

  function ops() {
    const f = P.f, o = [];
    if (f.proto) o.push({ path: 'protocol', value: f.proto });
    if (f.outMode) { o.push({ path: 'outMode', value: f.outMode }); if (f.outMode !== 'sync' && f.fps) o.push({ path: 'fps', value: Number(f.fps) }); }
    if (f.addr === 'seq' && U.isIp(f.ip)) { o.push({ path: 'ipMode', value: 'static' }, { path: 'ip', op: 'seq', value: f.ip }); if (U.isMask(f.mask)) o.push({ path: 'mask', value: f.mask }); }
    if (f.addr === 'dhcp') o.push({ path: 'ipMode', value: 'dhcp' });
    if (f.addr === 'mask' && U.isMask(f.mask)) o.push({ path: 'mask', value: f.mask });
    if (f.dir) o.push({ path: 'ports.*.dir', value: f.dir });
    if (f.univ === 'seq') o.push({ path: 'ports.*.univ', op: 'seq', value: Number(f.univVal) });
    if (f.univ === 'offset') o.push({ path: 'ports.*.univ', op: 'offset', value: Number(f.univVal) });
    if (f.name === 'pat') { o.push({ path: 'shortName', op: 'seq', value: f.namePat }, { path: 'longName', op: 'seq', value: f.namePat }); }
    if (f.login === 'off') o.push({ path: 'loginPage', value: false });
    if (f.login === 'on') { o.push({ path: 'loginPage', value: true }, { path: 'login', value: f.user }, { path: 'pass', value: f.pass }); }
    if (f.prio === 'set') o.push({ path: 'ports.*.prio', value: Number(f.prioVal) });
    return o;
  }

  /** Résultat pour chaque node : { n, after, diff, probs } */
  function preview() {
    const list = chosen();
    const o = ops();
    let portOffset = 0;
    return list.map((n, idx) => {
      const wanted = Store.wanted(n);
      const np = Store.ports(n);
      const after = M.applyOps(wanted, o, { idx, portOffset, nPorts: np });
      portOffset += np;
      // les noms trop longs sont coupés à la limite du node
      if (after.shortName && after.shortName.length > 17) after.shortName = after.shortName.slice(0, 17);
      const diff = M.diff(after, wanted);
      return { n, after, diff, probs: M.validate(after).filter(p => p.level === 'err') };
    });
  }

  function sel(key, options, attrs) {
    return '<select data-lot="' + key + '"' + (attrs || '') + '>' + options.map(o => '<option value="' + esc(o[0]) + '"' + (String(P.f[key]) === String(o[0]) ? ' selected' : '') + '>' + esc(o[1]) + '</option>').join('') + '</select>';
  }
  function inp(key, type, extra) {
    return '<input type="' + (type || 'text') + '" data-lot="' + key + '" value="' + esc(P.f[key]) + '" ' + (extra || '') + '>';
  }

  P.enter = function (params) {
    if (params && params.ids) P.ids = params.ids.slice();
    if (!P.f) P.f = Object.assign({}, DEF, { mask: Store.settings().subnetMask });
  };

  P.render = function () {
    if (!P.f) P.enter({});
    const list = chosen();
    const f = P.f;
    let h = '<div class="pghead"><h1>Lot <small>modifier plusieurs nodes</small></h1><div class="tools"><button type="button" class="btn' + (list.length ? '' : ' primary') + '" data-act="pick" data-fid="l_pick">Choisir les nodes (' + list.length + ')</button>' +
      '<button type="button" class="btn sm" data-act="reset">Tout remettre à « inchangé »</button></div></div>';
    h += '<div class="chosen">' + (list.length ? list.map(n => '<span class="pchip">' + C.statusDot(n) + esc(Store.label(n)) + ' <small>' + esc(n.ip || '') + '</small></span>').join('') : '<span class="muted">Aucun node choisi.</span>') + '</div>';
    h += '<section class="box lotform"><h3>Modifications</h3>' +
      '<div class="lrow"><label>Protocole</label>' + sel('proto', [['', 'inchangé'], ['artnet', 'Art-Net'], ['sacn', 'sACN']]) + '</div>' +
      '<div class="lrow"><label>Sortie DMX</label>' + sel('outMode', [['', 'inchangée'], ['sync', 'Synchro sur le flux'], ['fixed', 'Fréquence fixe'], ['fixed_always', 'Fixe, sans arrêt'], ['change', 'Sur changement']]) +
      (f.outMode && f.outMode !== 'sync' ? '<span class="sub">' + inp('fps', 'number', 'min="16" max="44" data-num') + ' images/s</span>' : '') + '</div>' +
      '<div class="lrow"><label>Adresses</label>' + sel('addr', [['', 'inchangées'], ['seq', 'IP fixes à la suite'], ['mask', 'changer seulement le masque'], ['dhcp', 'DHCP']]) +
      (f.addr === 'seq' ? '<span class="sub">à partir de ' + inp('ip', 'text', 'inputmode="decimal" placeholder="2.0.0.11"') + '</span>' : '') +
      (f.addr === 'seq' || f.addr === 'mask' ? '<span class="sub">masque ' + inp('mask', 'text', 'inputmode="decimal"') + '</span>' : '') + '</div>' +
      '<div class="lrow"><label>Sens des ports</label>' + sel('dir', [['', 'inchangé'], ['out', 'tous en sortie DMX'], ['in', 'tous en entrée DMX']]) + '</div>' +
      '<div class="lrow"><label>Univers</label>' + sel('univ', [['', 'inchangés'], ['seq', 'à la suite à partir de'], ['offset', 'décaler de']]) +
      (f.univ ? '<span class="sub">' + inp('univVal', 'number', (f.univ === 'seq' ? 'min="0"' : '') + ' data-num') + (f.univ === 'seq' ? ' (réseau' + (f.proto === 'sacn' ? ', sACN ≥ 1' : ', Art-Net 0 = MA 1') + ')' : '') + '</span>' : '') + '</div>' +
      '<div class="lrow"><label>Noms</label>' + sel('name', [['', 'inchangés'], ['pat', 'modèle']]) + (f.name ? '<span class="sub">' + inp('namePat', 'text', 'placeholder="NODE-##"') + ' (## = numéro)</span>' : '') + '</div>' +
      '<div class="lrow"><label>Page de login</label>' + sel('login', [['', 'inchangée'], ['off', 'désactivée'], ['on', 'activée']]) + (f.login === 'on' ? '<span class="sub">' + inp('user', 'text', 'placeholder="utilisateur"') + inp('pass', 'text', 'placeholder="mot de passe"') + '</span>' : '') + '</div>' +
      '<div class="lrow"><label>Priorité sACN</label>' + sel('prio', [['', 'inchangée'], ['set', 'fixer à']]) + (f.prio ? '<span class="sub">' + inp('prioVal', 'number', 'min="0" max="200" data-num') + '</span>' : '') + '</div>' +
      '</section>';
    const pv = preview();
    const touched = pv.filter(x => x.diff.length);
    h += '<section class="box"><h3>Aperçu <small>' + U.plural(touched.length, 'node') + ' modifié' + (touched.length > 1 ? 's' : '') + '</small></h3>';
    if (!ops().length) h += '<p class="muted">Choisis au moins une modification.</p>';
    else if (!touched.length) h += '<p class="muted">Ces nodes ont déjà ces valeurs.</p>';
    else h += '<table class="raw">' + touched.map(x => '<tr' + (x.probs.length ? ' class="bad"' : '') + '><th>' + esc(Store.label(x.n)) + '</th><td>' +
      x.diff.map(d => esc(d.label) + ' : <s>' + esc(d.have == null ? '—' : M.enumLabel(d.path, d.have)) + '</s> → <b>' + esc(M.enumLabel(d.path, d.want)) + '</b>').join('<br>') +
      x.probs.map(p => '<div class="err">' + esc(p.msg) + '</div>').join('') + '</td></tr>').join('') + '</table>';
    // conflits après modification
    const others = Store.nodes().filter(n => P.ids.indexOf(n.id) < 0).map(n => ({ id: n.id, name: Store.label(n), ip: n.ip, canon: Store.wanted(n), ports: Store.ports(n) }));
    const plan = M.universePlan(others.concat(pv.map(x => ({ id: x.n.id, name: Store.label(x.n), ip: x.n.ip, canon: x.after, ports: Store.ports(x.n) }))), {});
    const bad = plan.issues.filter(i => i.level !== 'info');
    if (touched.length && bad.length) h += '<div class="issues">' + bad.map(i => '<div class="iss ' + i.level + '">' + (i.level === 'err' ? '✗ ' : '⚠ ') + esc(i.msg) + '</div>').join('') + '</div>';
    h += '</section>';
    const blocked = touched.some(x => x.probs.length);
    h += '<div class="row-btns end"><button type="button" class="btn" data-act="save" data-fid="l_save"' + (touched.length && !blocked ? '' : ' disabled') + '>Enregistrer dans le prévu</button>' +
      '<button type="button" class="btn primary" data-act="saveApply" data-fid="l_apply"' + (touched.length && !blocked ? '' : ' disabled') + '>Enregistrer et appliquer</button></div>';
    return h;
  };

  P.mount = function (el) {
    el.querySelectorAll('[data-lot]').forEach(x => {
      const ev = x.tagName === 'SELECT' ? 'change' : 'change';
      x.addEventListener(ev, () => { P.f[x.dataset.lot] = x.value; App.render(); });
    });
  };

  function commit() {
    const pv = preview().filter(x => x.diff.length);
    pv.forEach(x => {
      x.diff.forEach(d => M.setPath(x.n.plan, d.path, d.want));
      Store.log(x.n, 'Modifié en lot (prévu)', true, x.diff.map(d => d.label).join(', '));
    });
    Store.save();
    return pv.map(x => x.n);
  }

  P.acts = {
    pick: async () => {
      const ids = await C.pickNodes('Nodes à modifier', P.ids);
      if (ids) { P.ids = ids; App.render(); }
    },
    reset: () => { P.f = Object.assign({}, DEF, { mask: Store.settings().subnetMask }); App.render(); },
    save: () => { const ns = commit(); UI.toast(U.plural(ns.length, 'node') + ' : config prévue mise à jour'); App.render(); },
    saveApply: async () => {
      const ns = commit();
      if (!await UI.confirm('Appliquer', 'Écrire maintenant dans ' + U.plural(ns.length, 'node') + ' (USB si branché, sinon page web) ?', 'Appliquer')) { App.render(); return; }
      await C.applyMany(ns);
    }
  };
  P.padStart = () => P.acts.saveApply();
  P.padY = () => P.acts.pick();
  P.padHelp = { Y: 'choisir les nodes', START: 'enregistrer et appliquer' };
  App.Pages.lot = P;
})();
