/* Page « Moniteur » : ce qui passe sur le réseau (Art-Net / sACN), test de sortie */
(function () {
  'use strict';
  const esc = U.esc, C = App.C, M = Model;
  const P = { on: false, snapshot: [], timer: null, prev: {}, fps: {}, extraSacn: '', test: null, detail: null };

  function sacnList() {
    const set = new Set();
    Store.nodes().forEach(n => {
      const c = Store.wanted(n);
      if (c.protocol !== 'sacn') return;
      (c.ports || []).forEach(p => { const pu = M.portUniverse(c, p); if (pu) set.add(pu.univ); });
    });
    M.parseRanges(P.extraSacn).forEach(u => { if (u >= 1) set.add(u); });
    return Array.from(set).sort((a, b) => a - b).slice(0, 64);
  }

  P.start = function () {
    P.on = true;
    Bridge.monitor(true, sacnList());
    clearInterval(P.timer);
    P.timer = setInterval(P.tick, 300);
    P.tick();
  };
  P.stop = function () {
    P.on = false;
    clearInterval(P.timer);
    P.timer = null;
    Bridge.monitor(false, []);
    P.snapshot = [];
  };
  P.tick = function () {
    const snap = Bridge.monitorSnapshot();
    const now = Date.now();
    snap.forEach(u => {
      const k = u.proto + ':' + u.univ;
      const pv = P.prev[k];
      if (pv && now > pv.t) P.fps[k] = Math.round(((u.frames - pv.frames) * 1000 / (now - pv.t)) * 0.5 + (P.fps[k] || 0) * 0.5);
      P.prev[k] = { t: now, frames: u.frames };
      u.levels = U.fromB64(u.data);
    });
    P.snapshot = snap;
    if (App.page === 'moniteur') P.paint();
    if (P.detail) P.paintDetail();
  };

  function bars(levels) {
    let h = '';
    for (let i = 0; i < 64; i++) {
      let m = 0;
      for (let k = 0; k < 8; k++) m = Math.max(m, levels[i * 8 + k] || 0);
      h += '<i style="height:' + Math.round(m / 255 * 100) + '%"></i>';
    }
    return h;
  }

  P.paint = function () {
    const box = document.getElementById('monGrid');
    if (!box) return;
    const list = P.snapshot.slice().sort((a, b) => (a.proto === 'sacn' ? a.univ : a.univ + 1) - (b.proto === 'sacn' ? b.univ : b.univ + 1));
    if (!list.length) { box.innerHTML = '<div class="empty muted">' + (P.on ? 'Rien reçu pour l\'instant… (Art-Net : tout le réseau ; sACN : univers ' + (sacnList().join(', ') || 'aucun') + ')' : 'Moniteur arrêté.') + '</div>'; return; }
    box.innerHTML = list.map(u => {
      const k = u.proto + ':' + u.univ;
      const ma = u.proto === 'sacn' ? u.univ : u.univ + 1;
      const stale = u.age > 3000;
      const used = u.levels.reduce((s, x) => s + (x > 0 ? 1 : 0), 0);
      return '<div class="card mon' + (stale ? ' stale' : '') + (u.sources.length > 1 ? ' multi' : '') + '" data-act="monDetail" data-arg="' + k + '" tabindex="0" data-fid="m_' + k + '">' +
        '<div class="c-h"><b>MA ' + ma + '</b><span class="muted">' + C.protoName(u.proto) + ' ' + u.univ + '</span><span class="fps">' + (stale ? 'arrêté' : (P.fps[k] || 0) + ' i/s') + '</span></div>' +
        '<div class="bars">' + bars(u.levels) + '</div>' +
        '<div class="c-f">' + esc(u.sources.join(', ')) + (u.prio >= 0 ? ' · prio ' + u.prio : '') + ' · ' + used + ' canaux actifs' + (u.sources.length > 1 ? ' · <span class="warn">plusieurs sources</span>' : '') + '</div></div>';
    }).join('');
    const nb = document.getElementById('monNodes');
    if (nb) nb.innerHTML = nodesHtml();
  };

  function nodesHtml() {
    const rows = Store.nodes().filter(n => RT.poll[n.id] && RT.isOnline(n));
    if (!rows.length) return '<p class="muted">Aucun node n\'a répondu en Art-Net récemment.</p>';
    return '<table class="raw">' + rows.map(n => {
      const m = RT.poll[n.id];
      return '<tr><td>' + C.statusDot(n) + esc(Store.label(n)) + '</td><td>' + m.ports.map((p, i) => '<span class="pt ' + (p.canIn && !p.canOut ? 'in' : 'out') + ((p.canOut ? p.outData : p.inData) ? ' live' : '') + '"><b>' + (i + 1) + '</b>' + ((p.canOut ? p.outData : p.inData) ? 'données' : 'rien') + '</span>').join('') + '</td></tr>';
    }).join('') + '</table>';
  }

  P.paintDetail = function () {
    const d = P.detail;
    const cv = d && d.el && d.el.querySelector('canvas');
    if (!cv) return;
    const u = P.snapshot.find(x => x.proto + ':' + x.univ === d.key);
    const g = cv.getContext('2d');
    const w = cv.width, hgt = cv.height;
    g.fillStyle = '#0d0f12'; g.fillRect(0, 0, w, hgt);
    if (!u) return;
    const bw = w / 512;
    for (let i = 0; i < 512; i++) {
      const v = u.levels[i] || 0;
      g.fillStyle = v ? 'hsl(' + (28 - v / 255 * 10) + ',85%,' + (30 + v / 255 * 30) + '%)' : '#1c1f25';
      const bh = Math.max(1, v / 255 * (hgt - 14));
      g.fillRect(i * bw, hgt - bh, Math.max(1, bw - 0.3), bh);
    }
    g.fillStyle = '#888'; g.font = '10px sans-serif';
    [1, 64, 128, 192, 256, 320, 384, 448, 512].forEach(c => g.fillText(String(c), (c - 1) * bw, 10));
    const sel = d.el.querySelector('.chval');
    if (sel) {
      const ch = U.clamp(Number(d.el.querySelector('.chnum').value) || 1, 1, 512);
      sel.textContent = (u.levels[ch - 1] || 0) + ' (' + Math.round((u.levels[ch - 1] || 0) / 2.55) + ' %)';
    }
  };

  P.render = function () {
    let h = '<div class="pghead"><h1>Moniteur <small>Art-Net et sACN vus par l\'appareil</small></h1><div class="tools">' +
      '<button type="button" class="btn ' + (P.on ? '' : 'primary') + '" data-act="toggle" data-fid="m_toggle">' + (P.on ? 'Arrêter' : 'Démarrer') + '</button>' +
      '<button type="button" class="btn" data-act="sacn">Univers sACN…</button></div></div>' +
      '<div class="grid mons" id="monGrid"></div>' +
      '<section class="box"><h3>Nodes (Art-Net)</h3><div id="monNodes">' + nodesHtml() + '</div></section>' +
      '<section class="box"><h3>Test de sortie</h3><p class="muted small">Envoie de l\'Art-Net directement à un node pour vérifier ses sorties sans console. ' +
      '<span class="warn">Attention : le node reçoit aussi la console, les projecteurs vont réagir.</span></p>' +
      (P.test ? '<p class="ok">Test en cours : ' + esc(P.test.label) + '</p><div class="row-btns"><button type="button" class="btn danger" data-act="testStop" data-fid="m_tstop">Arrêter le test</button></div>'
        : '<div class="row-btns"><button type="button" class="btn" data-act="test" data-fid="m_test">Lancer un test…</button></div>') + '</section>';
    return h;
  };
  P.mount = function () { P.paint(); };
  P.enter = function () { if (!P.on) P.start(); };

  P.acts = {
    toggle: () => { if (P.on) P.stop(); else P.start(); App.render(); },
    sacn: async () => {
      const v = await UI.form('Univers sACN à écouter', [{ key: 'u', label: 'En plus de ceux du parc', value: P.extraSacn, placeholder: 'ex. 1-8', hint: 'Parc : ' + (sacnList().join(', ') || 'aucun') }], 'OK');
      if (!v) return;
      P.extraSacn = v.u;
      if (P.on) Bridge.monitor(true, sacnList());
      App.render();
    },
    monDetail: el => {
      const key = el.dataset.arg;
      const [proto, univ] = key.split(':');
      P.detail = { key };
      UI.dialog({
        title: C.protoName(proto) + ' ' + univ + ' — MA ' + (proto === 'sacn' ? univ : +univ + 1), wide: true,
        body: '<canvas width="1024" height="220" class="levels"></canvas><div class="row">Canal <input type="number" class="chnum" min="1" max="512" value="1" data-num> = <b class="chval">—</b></div>',
        onOpen: e => { P.detail.el = e; P.paintDetail(); }
      }).then(() => { P.detail = null; });
    },
    test: async () => {
      const nodes = Store.nodes().filter(n => U.isIp(n.ip));
      if (!nodes.length) { UI.toast('Aucun node avec une adresse', 'err'); return; }
      const v = await UI.form('Test de sortie', [
        { key: 'node', label: 'Node', type: 'select', value: nodes[0].id, options: nodes.map(n => [n.id, Store.label(n) + ' (' + n.ip + ')']) },
        { key: 'port', label: 'Port', type: 'select', value: 0, options: [[0, 'DMX 1'], [1, 'DMX 2'], [2, 'DMX 3'], [3, 'DMX 4']] },
        { key: 'mode', label: 'Test', type: 'select', value: 'chase', options: [['full', 'Tout à fond'], ['black', 'Tout à zéro'], ['chase', 'Chenillard canal par canal'], ['ch', 'Un canal']] },
        { key: 'ch', label: 'Canal (mode « un canal »)', type: 'number', value: 1, min: 1, max: 512 },
        { key: 'lvl', label: 'Niveau %', type: 'number', value: 100, min: 0, max: 100 }
      ], 'Démarrer');
      if (!v) return;
      const n = Store.node(v.node);
      const c = Store.wanted(n);
      if (c.protocol === 'sacn') { UI.alert('Test impossible', 'Ce node est en sACN : le test n\'envoie que de l\'Art-Net.'); return; }
      const p = c.ports[+v.port] || {};
      const u = p.univOut != null ? p.univOut : +v.port;
      const lvl = Math.round(U.clamp(v.lvl, 0, 100) * 2.55);
      let seq = 0, step = 0;
      const t0 = Date.now();
      P.test = { label: Store.label(n) + ' DMX ' + (+v.port + 1) + ' (Art-Net ' + u + ') — ' + { full: 'à fond', black: 'zéro', chase: 'chenillard', ch: 'canal ' + v.ch }[v.mode] };
      P.test.timer = setInterval(() => {
        if (Date.now() - t0 > 60000) { P.acts.testStop(); UI.toast('Test arrêté au bout d\'une minute'); return; }
        const d = new Uint8Array(512);
        if (v.mode === 'full') d.fill(lvl);
        else if (v.mode === 'ch') d[U.clamp(v.ch, 1, 512) - 1] = lvl;
        else if (v.mode === 'chase') d[Math.floor(step++ / 6) % 512] = lvl;
        Bridge.udpSend(n.ip, ArtNet.PORT, ArtNet.buildDmx(u, d, (seq = seq % 255 + 1)));
      }, 40);
      Store.log(n, 'Test de sortie ' + P.test.label, true);
      App.render();
    },
    testStop: () => {
      if (P.test) clearInterval(P.test.timer);
      P.test = null;
      App.render();
    }
  };
  P.padStart = () => P.acts.toggle();
  P.padHelp = { START: 'démarrer / arrêter le moniteur' };
  App.Pages.moniteur = P;
})();
