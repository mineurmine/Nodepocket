/*
 * Mode simple (techniciens) : la liste des nodes, et pour chacun les réglages de base
 * — adresse IP, Art-Net ou sACN, sens et univers de chaque port — puis « Envoyer au node ».
 * Même moteur que le mode complet (USB, page web, API, Art-Net selon la marque), sans menus.
 * Développé par 3DP.
 */
(function () {
  'use strict';
  const esc = U.esc, C = App.C, M = Model;
  // réglages proposés en mode simple
  const SIMPLE = /^(ip|mask|ipMode|protocol|ports\.\d+\.(dir|univOut|univIn))$/;
  const pendingSimple = n => Store.pending(n).filter(d => SIMPLE.test(d.path));

  // ================================================================ accueil : les nodes
  const A = { live: true, opened: null };

  function nodeCard(n) {
    const c = Store.wanted(n);
    const st = RT.status(n);
    const pend = pendingSimple(n).length;
    return '<div class="card node snode st-' + st + '" data-act="open" data-arg="' + n.id + '" data-fid="s_' + n.id + '" tabindex="0">' +
      '<div class="c-h">' + C.statusDot(n) + '<b class="nm">' + esc(Store.label(n)) + '</b><span class="ip">' + esc(n.ip || (c.ipMode === 'dhcp' ? 'DHCP' : '—')) + '</span></div>' +
      '<div class="c-m">' + C.brandBadge(n) + ' ' + C.protoName(c.protocol) + (st === 'usb' ? ' ' + UI.badge('USB', 'usb') : '') + (pend ? ' <span class="warn">· ' + U.plural(pend, 'changement') + ' pas envoyé' + (pend > 1 ? 's' : '') + '</span>' : '') + '</div>' +
      '<div class="ports">' + C.portChips(n, c) + '</div></div>';
  }
  function foundCard(m) {
    return '<div class="card found snode" data-act="addOpen" data-arg="' + esc(m.ip) + '" data-fid="sf_' + esc(m.ip) + '" tabindex="0">' +
      '<div class="c-h">' + UI.dot('ok') + '<b class="nm">' + esc(m.shortName || m.longName || 'Node') + '</b><span class="ip">' + esc(m.ip) + '</span></div>' +
      '<div class="c-m">' + UI.badge(Brands.label(Brands.detect({ poll: m })), 'brand') + ' <span class="muted">nouveau · toucher pour le régler</span></div></div>';
  }

  A.render = function () {
    const nodes = Store.nodes();
    const online = nodes.filter(n => RT.isOnline(n)).length;
    let h = '<div class="pghead"><h1>Nodes <small>' + online + ' en ligne' + (nodes.length ? ' sur ' + nodes.length : '') + '</small></h1><div class="tools">' +
      '<button type="button" class="btn" data-act="poll" data-fid="s_poll">Rechercher</button>' +
      '<button type="button" class="btn" data-act="addIp" data-fid="s_add">+ Par adresse IP</button></div></div>';
    // node branché en USB
    if (USB.state === 'opening' || USB.state === 'reading' || USB.state === 'perm') {
      h += '<div class="card usbcard"><div class="c-h">' + App.icon('usb', 'sm') + '<b>' + (USB.state === 'perm' ? 'Accepte l\'accès USB dans la fenêtre d\'Android' : 'Lecture du node branché en USB…') + '</b></div></div>';
    } else if (USB.state === 'error') {
      h += '<div class="card usbcard bad"><div class="c-h">' + App.icon('usb', 'sm') + '<b>USB : ' + esc(USB.error) + '</b></div><div class="row-btns"><button type="button" class="btn sm" data-act="usbRetry">Réessayer</button></div></div>';
    } else if (USB.state === 'ready' && USB.nodeId && Store.node(USB.nodeId)) {
      const n = Store.node(USB.nodeId);
      h += '<button type="button" class="card usbcard" data-act="open" data-arg="' + n.id + '" data-fid="s_usb">' + App.icon('usb', 'sm') + '<span>Branché en USB : <b>' + esc(Store.label(n)) + '</b></span><span class="go">Régler ›</span></button>';
    }
    const list = nodes.slice().sort((a, b) => (RT.isOnline(b) - RT.isOnline(a)) || U.ipCompare(a.ip, b.ip) || Store.label(a).localeCompare(Store.label(b)));
    const found = Disco.unknown().filter(m => !App.Pages.parc.isConsole(m));
    if (!nodes.length && !found.length) {
      h += '<div class="empty"><p>Aucun node pour l\'instant.</p><p class="muted">Branche un node en USB, ou relie l\'appareil au réseau des nodes et touche « Rechercher ».</p></div>';
    }
    if (list.length) h += '<div class="grid nodes">' + list.map(nodeCard).join('') + '</div>';
    if (found.length) h += '<h2 class="sub">Trouvés sur le réseau</h2><div class="grid nodes">' + found.map(foundCard).join('') + '</div>';
    h += '<p class="sigline">Node Pocket · ' + esc(App.SIGNATURE) + '</p>';
    return h;
  };

  /** Node USB pas encore connu : on l'ajoute (ou on le relie au node qui a la même adresse) */
  A.autoUsb = function () {
    if (!App.simple() || USB.state !== 'ready' || !USB.info || USB.nodeId) return;
    const info = USB.info;
    const c = info.mapped ? info.mapped.canon : {};
    const ip = c.ipMode === 'static' && U.isIp(c.ip) ? c.ip : '';
    const same = ip ? Store.nodes().find(x => (x.ip === ip || Store.wanted(x).ip === ip) && (!x.serial || x.serial === info.serial)) : null;
    if (same) { USB.associate(same); return; }
    const n = Store.addNode({ name: c.shortName || c.longName || info.product || 'Node USB', ip: ip && !Store.byIp(ip) ? ip : '', model: C.modelFor(info.mapped ? info.mapped.ports : 1), serial: info.serial || '', brand: 'electroconcept', plan: {} });
    Store.log(n, 'Ajouté depuis l\'USB (mode simple)', true);
    USB.associate(n);
  };
  RT.listeners.push(what => {
    if (what !== 'usb' || !App.simple()) return;
    A.autoUsb();
    // node branché : on ouvre directement ses réglages
    if (USB.state === 'ready' && USB.nodeId && USB.dev && A.opened !== USB.dev.name && App.page === 'accueil' && !UI.isOpen()) {
      A.opened = USB.dev.name;
      setTimeout(() => { if (App.page === 'accueil' && USB.nodeId) App.go('tech', { id: USB.nodeId }); }, 50);
    }
    if (USB.state === 'none') A.opened = null;
  });

  A.acts = {
    open: el => App.go('tech', { id: el.dataset.arg }),
    poll: async () => {
      UI.toast('Recherche sur le réseau…');
      const list = await Disco.poll();
      await Probe.tick(true);
      UI.toast(U.plural(list.length, 'node') + ' a répondu');
      App.render();
    },
    addOpen: el => {
      const m = Disco.live[el.dataset.arg];
      if (!m) return;
      const n = Store.byMac(m.mac) || Store.byIp(m.ip) || Store.addNode({ name: m.shortName || m.longName || ('Node ' + m.ip), ip: m.ip, model: C.modelFor(m.numPorts), mac: m.mac || '', plan: {} });
      if (!n.mac && m.mac) n.mac = m.mac;
      Disco.match(m);
      Store.log(n, 'Ajouté depuis le réseau (mode simple)', true);
      Store.save();
      App.go('tech', { id: n.id });
    },
    addIp: async () => {
      const s = Store.settings();
      const base = U.isIp(s.subnetIp) ? s.subnetIp.split('.').slice(0, 3).join('.') + '.' : '';
      const v = await UI.form('Node par adresse IP', [
        { key: 'ip', label: 'Adresse IP du node', type: 'ip', value: base, autofocus: true },
        { key: 'name', label: 'Nom (facultatif)', value: '' }
      ], 'Ajouter', { validate: v => (!U.isIp(v.ip) ? 'Adresse IP invalide' : '') });
      if (!v) return;
      const n = Store.byIp(v.ip) || Store.addNode({ name: v.name.trim(), ip: v.ip.trim(), plan: {} });
      Store.save();
      Probe.one(n);
      Disco.pollOne(n.ip, 1200).then(m => { if (m) { m.at = Date.now(); Disco.live[m.ip] = m; Disco.match(m); RT.changed('poll'); } });
      App.go('tech', { id: n.id });
    },
    usbRetry: () => { const s = USB.scan(); if (s.ec) USB.connect(s.ec); else UI.toast('Aucun node USB branché', 'err'); }
  };
  A.padY = () => A.acts.poll();
  A.padStart = () => A.acts.addIp();
  A.padX = el => { const c = el && el.closest('[data-act="open"]'); if (c) App.go('tech', { id: c.dataset.arg }); };
  A.padHelp = { X: 'régler le node sélectionné', Y: 'rechercher sur le réseau', START: 'ajouter par adresse IP', L1: 'Nodes / Réglages' };
  App.Pages.accueil = A;

  // ================================================================ réglages de base d'un node
  const T = { live: true, st: {} };
  const node = () => Store.node(App.params.id);

  function univInput(n, c, i, p) {
    const path = 'ports.' + i + '.' + (p.dir === 'in' ? 'univIn' : 'univOut');
    const v = M.getPath(c, path);
    const ma = v == null || v === '' ? '' : (c.protocol === 'sacn' ? Number(v) : Number(v) + 1);
    const diff = SIMPLE.test(path) && M.getPath(n.plan, path) !== undefined && n.last && n.last.canon && !U.same(M.getPath(n.plan, path), M.getPath(n.last.canon, path));
    return '<label class="uni' + (diff ? ' diff' : '') + '"><span>Univers</span><input type="number" inputmode="numeric" min="' + (c.protocol === 'sacn' ? 1 : 0) + '" max="' + (c.protocol === 'sacn' ? 63999 : 32767) + '" data-path="' + path + '" data-fid="t_' + path + '" value="' + esc(v == null ? '' : v) + '" placeholder="—"></label>' +
      '<span class="ma" data-ma="' + path + '">' + (ma === '' ? '' : 'MA ' + ma) + '</span>';
  }

  T.render = function () {
    const n = node();
    if (!n) return '<div class="empty">Node introuvable. <button type="button" class="btn" data-act="back">Retour</button></div>';
    const c = Store.wanted(n);
    const st = T.st.id === n.id ? T.st : {};
    const det = Store.brand(n), b = Brands.get(det.id);
    const no = Ops.cantWrite(n);
    const pend = pendingSimple(n);
    const busy = st.reading || st.sending || RT.busy[n.id];
    let h = '<div class="pghead fiche"><button type="button" class="btn icon" data-act="back" aria-label="Retour">‹</button>' +
      '<h1>' + C.statusDot(n) + esc(Store.label(n)) + ' <small>' + esc(n.ip || '') + '</small></h1>' +
      '<div class="tools"><button type="button" class="btn" data-act="read" data-fid="t_read"' + (busy ? ' disabled' : '') + '>Relire</button></div></div>';
    h += '<div class="brandbar">' + C.brandBadge(n) + ' ';
    if (st.reading) h += '<span class="busy">Lecture du node' + (st.step ? ' — ' + esc(st.step) : '') + '…</span>';
    else if (st.err) h += '<span class="err">Lecture impossible : ' + esc(st.err) + '</span>';
    else if (n.last) h += '<span class="muted small">lu ' + esc(U.timeAgo(n.last.at)) + ' (' + esc(Ops.VIA[n.last.via]) + ')' + (n.last.partial ? ' · noms, univers et protocole annoncés' : '') + '</span>';
    else if (RT.poll[n.id]) h += '<span class="muted small">valeurs annoncées par le node sur le réseau</span>';
    else h += '<span class="warn small">pas encore lu</span>';
    h += '</div>';
    if (no) h += '<div class="box infobox">' + esc(no) + '<br><span class="muted small">L\'appli affiche ses réglages en direct, sans pouvoir les modifier.</span></div>';
    const ro = !!no;
    const val = (path, v) => esc(M.enumLabel(path, v) == null ? '—' : M.enumLabel(path, v));
    // adresse
    h += '<section class="box tech"><h3>Adresse IP</h3>';
    if (ro) h += '<div class="trow"><span class="big">' + esc(c.ipNow || n.ip || '—') + '</span> <span class="muted">' + (c.ipMode === 'dhcp' ? 'DHCP' : c.ipMode === 'static' ? 'fixe' : '') + '</span></div>';
    else {
      h += '<div class="trow">' + UI.seg('ipMode', [['static', 'IP fixe'], ['dhcp', 'DHCP']], c.ipMode || '') + '</div>';
      if (c.ipMode !== 'dhcp') {
        h += '<div class="trow"><label class="ipf"><span>Adresse</span><input type="text" inputmode="decimal" data-path="ip" data-fid="t_ip" value="' + esc(c.ip || '') + '" placeholder="ex. 2.0.0.11" autocomplete="off" spellcheck="false"></label>' +
          '<label class="ipf"><span>Masque</span><input type="text" inputmode="decimal" data-path="mask" data-fid="t_mask" value="' + esc(c.mask || '') + '" placeholder="ex. 255.0.0.0" autocomplete="off" spellcheck="false"></label></div>';
      } else if (c.ipNow) h += '<div class="muted small">Adresse actuelle : ' + esc(c.ipNow) + '</div>';
    }
    h += '</section>';
    // protocole
    h += '<section class="box tech"><h3>Protocole</h3><div class="trow">' + (ro ? '<span class="big">' + C.protoName(c.protocol) + '</span>' : UI.seg('protocol', [['artnet', 'Art-Net'], ['sacn', 'sACN']], c.protocol || '')) +
      '</div><div class="muted small">' + (c.protocol === 'sacn' ? 'sACN : l\'univers 1 est l\'univers 1 de la console MA.' : 'Art-Net : l\'univers 0 est l\'univers 1 de la console MA.') + '</div></section>';
    // ports
    const np = Store.ports(n);
    h += '<section class="box tech"><h3>Univers par port</h3>';
    for (let i = 0; i < np; i++) {
      const p = c.ports[i] || {};
      if (ro) {
        const pu = M.portUniverse(c, p);
        h += '<div class="trow port-s"><b class="pn">DMX ' + (i + 1) + '</b><span>' + val('ports.0.dir', p.dir || 'out') + '</span><span class="big">' + (pu ? esc(pu.univ) + ' <small class="ma">MA ' + esc(pu.ma) + '</small>' : '—') + '</span></div>';
      } else {
        h += '<div class="trow port-s"><b class="pn">DMX ' + (i + 1) + '</b>' + UI.seg('ports.' + i + '.dir', [['out', 'Sortie'], ['in', 'Entrée']], p.dir || 'out') + univInput(n, c, i, p) + '</div>';
      }
    }
    h += '</section>';
    if (!ro) {
      const probs = M.validate(c).filter(x => x.level === 'err' && (!x.path || SIMPLE.test(x.path)));
      probs.forEach(x => { h += '<div class="err">✗ ' + esc(x.msg) + '</div>'; });
      h += '<div class="sendbar"><button type="button" class="btn primary big" data-act="send" data-fid="t_send"' + (pend.length && !busy && !probs.length ? '' : ' disabled') + '>' +
        (st.sending ? 'Envoi…' : 'Envoyer au node' + (pend.length ? ' (' + U.plural(pend.length, 'changement') + ')' : '')) + '</button>' +
        (pend.length && !st.sending ? '<button type="button" class="btn" data-act="undo" data-fid="t_undo">Annuler mes changements</button>' : '') + '</div>';
      if (pend.length && !st.sending) h += '<div class="muted small">À envoyer : ' + pend.map(d => esc(d.label) + ' → <b>' + esc(M.enumLabel(d.path, d.want)) + '</b>').join(' · ') + '</div>';
    }
    if (st.sending) h += '<div class="box"><div class="busy">' + esc(st.step || 'Envoi…') + '</div></div>';
    else if (st.rep) {
      const r = st.rep;
      h += '<div class="box result ' + (r.ok ? 'okbox' : 'errbox') + '"><h3>' + (r.ok ? '✓ Vérifié : le node a bien pris les réglages' : r.errors.length ? '✗ Pas envoyé' : '✗ Envoyé, mais le node ne montre pas tout') + '</h3>' + C.reportHtml(n, r) + '</div>';
    }
    h += '<p class="sigline">' + esc(App.SIGNATURE) + '</p>';
    return h;
  };

  T.enter = function (params) {
    const n = params && Store.node(params.id);
    if (!n) return;
    if (T.st.id !== n.id) T.st = { id: n.id };
    // lecture automatique en arrivant (sauf lecture récente)
    const recent = n.last && Date.now() - n.last.at < 45000;
    if (!recent && !T.st.reading) setTimeout(() => T.read(true), 30);
  };
  T.read = async function (auto) {
    const n = node();
    if (!n || T.st.reading || RT.busy[n.id]) return;
    if (auto && !Ops.routes(n).length) return;
    T.st = { id: n.id, reading: true };
    App.render();
    try {
      await Ops.read(n, 'auto', m => { T.st.step = m; App.render(); });
    } catch (e) {
      T.st.err = e.message;
    }
    T.st.reading = false;
    T.st.step = '';
    if (App.page === 'tech') App.render();
  };
  T.send = async function () {
    const n = node();
    const pend = pendingSimple(n);
    if (!pend.length) { UI.toast('Rien à envoyer'); return; }
    if (pend.some(d => /^(ip|mask|ipMode)$/.test(d.path))) {
      const ipd = pend.filter(d => /^(ip|mask|ipMode)$/.test(d.path)).map(d => '<li>' + esc(d.label) + ' : <b>' + esc(M.enumLabel(d.path, d.want)) + '</b></li>').join('');
      if (!await UI.confirm('Changer l\'adresse du node', 'Le node va changer d\'adresse :<ul>' + ipd + '</ul>Vérifie que l\'appareil pourra encore le joindre (même réseau).', 'Envoyer')) return;
    }
    T.st = { id: n.id, sending: true, step: 'Envoi par ' + (Ops.VIA[Ops.pick(n, 'auto', true)] || '?') + '…' };
    App.render();
    const target = M.unflat(Object.fromEntries(pend.map(d => [d.path, d.want])));
    const rep = await Ops.apply(n, target, 'auto', m => { T.st.step = m; App.render(); });
    T.st = { id: n.id, rep };
    if (App.page === 'tech') App.render();
    UI.toast(rep.ok ? 'Réglages envoyés et vérifiés' : 'Envoi incomplet : voir le détail', rep.ok ? '' : 'err');
  };

  T.mount = function (el) {
    el.addEventListener('segchange', e => {
      const n = node();
      if (!n || App.page !== 'tech') return;
      const { name, value } = e.detail;
      if (!SIMPLE.test(name)) return;
      M.setPath(n.plan, name, value);
      T.st.rep = null;
      Store.save();
      App.render();
    });
    el.addEventListener('change', e => {
      const inp = e.target.closest('[data-path]');
      const n = node();
      if (!inp || !n || App.page !== 'tech') return;
      const path = inp.dataset.path;
      const raw = inp.value.trim();
      const d = M.fieldDef(path);
      if (d.kind === 'ip' && raw && !U.isIp(raw)) { UI.toast('Adresse invalide : ' + raw, 'err'); inp.classList.add('bad'); return; }
      M.setPath(n.plan, path, raw === '' ? undefined : d.kind === 'univ' ? Number(raw) : raw);
      T.st.rep = null;
      Store.save();
      App.render();
    });
    el.addEventListener('input', e => {
      const inp = e.target.closest('[data-path]');
      const n = node();
      if (!inp || !n || M.fieldDef(inp.dataset.path).kind !== 'univ') return;
      const ma = el.querySelector('[data-ma="' + inp.dataset.path + '"]');
      if (ma) ma.textContent = inp.value === '' ? '' : 'MA ' + (Store.wanted(n).protocol === 'sacn' ? Number(inp.value) : Number(inp.value) + 1);
    });
  };

  T.acts = {
    read: () => T.read(false),
    send: () => T.send(),
    undo: () => {
      const n = node();
      pendingSimple(n).forEach(d => M.setPath(n.plan, d.path, undefined));
      T.st.rep = null;
      Store.save();
      App.render();
    }
  };
  T.padStart = () => { const n = node(); if (n && pendingSimple(n).length && !Ops.cantWrite(n)) T.send(); else UI.toast('Rien à envoyer'); };
  T.padY = () => T.read(false);
  T.padHelp = { Y: 'relire le node', START: 'envoyer au node', X: '—' };
  T.padX = () => {};
  App.Pages.tech = T;
})();
