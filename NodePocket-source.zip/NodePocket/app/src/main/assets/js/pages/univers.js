/* Page « Univers » : plan d'univers du parc, conflits et trous */
(function () {
  'use strict';
  const esc = U.esc, C = App.C, M = Model;
  const P = { live: true, src: 'want' };

  function entries() {
    return Store.nodes().map(n => ({
      id: n.id, name: Store.label(n), ip: n.ip,
      canon: P.src === 'read' ? ((n.last && n.last.canon) || { ports: [] }) : Store.wanted(n),
      ports: Store.ports(n)
    }));
  }

  function liveMap() {
    const m = {};
    (App.Pages.moniteur && App.Pages.moniteur.snapshot || []).forEach(u => { m[u.proto + ':' + u.univ] = u; });
    return m;
  }

  P.render = function () {
    const s = Store.settings();
    const expected = M.parseRanges(s.expected);
    const plan = M.universePlan(entries(), { expected, subnet: { ip: s.subnetIp, mask: s.subnetMask } });
    const live = liveMap();
    const errs = plan.issues.filter(i => i.level === 'err'), warns = plan.issues.filter(i => i.level === 'warn'), infos = plan.issues.filter(i => i.level === 'info');
    let h = '<div class="pghead"><h1>Univers <small>' + U.plural(plan.rows.length, 'univers utilisé') + '</small></h1><div class="tools">' +
      UI.seg('src', [['want', 'Config prévue'], ['read', 'Config lue']], P.src) +
      '<button type="button" class="btn" data-act="expected" data-fid="u_exp">Univers console…</button>' +
      '<button type="button" class="btn" data-act="share">Partager</button></div></div>';
    h += '<div class="issues">' +
      (errs.length ? errs.map(i => '<div class="iss err">✗ ' + esc(i.msg) + '</div>').join('') : '') +
      (warns.length ? warns.map(i => '<div class="iss warn">⚠ ' + esc(i.msg) + '</div>').join('') : '') +
      (infos.length ? '<details><summary>' + U.plural(infos.length, 'remarque') + '</summary>' + infos.map(i => '<div class="iss info">' + esc(i.msg) + '</div>').join('') + '</details>' : '') +
      (!plan.issues.length ? '<div class="iss ok">✓ Aucun conflit : chaque univers a une seule source, pas d\'adresse en double.</div>' : '') + '</div>';
    if (!expected.length) h += '<p class="muted small">Astuce : indique les univers patchés dans la console (« Univers console… ») pour repérer ceux qu\'aucun node ne sort.</p>';
    if (!plan.rows.length) return h + '<div class="empty muted">Aucun port configuré.</div>';
    h += '<table class="plan"><thead><tr><th>Univers</th><th>Sorties DMX (nodes qui reçoivent)</th><th>Entrées DMX (sources)</th><th>Réseau</th></tr></thead><tbody>';
    plan.rows.forEach(r => {
      const lv = live[r.proto + ':' + r.univ];
      const bad = r.issues.some(i => i.level === 'err'), warn = r.issues.some(i => i.level === 'warn');
      const chip = x => '<button type="button" class="pchip" data-act="node" data-arg="' + x.id + '">' + esc(x.name) + ' <small>DMX ' + (x.port + 1) + '</small></button>';
      h += '<tr class="' + (bad ? 'bad' : warn ? 'warnrow' : '') + '"><td class="un"><b>MA ' + r.ma + '</b><small>' + C.protoName(r.proto) + ' ' + r.univ + '</small></td>' +
        '<td>' + (r.outs.map(chip).join('') || '<span class="muted">—</span>') + '</td>' +
        '<td>' + (r.ins.map(chip).join('') || '<span class="muted">—</span>') + '</td>' +
        '<td>' + (lv ? (lv.sources.length > 1 ? UI.badge(lv.sources.length + ' sources', 'warn', lv.sources.join(', ')) : UI.badge('reçu', 'ok', lv.sources.join(', '))) : (App.Pages.moniteur && App.Pages.moniteur.on ? UI.badge('absent', 'mute') : '')) + '</td></tr>' +
        (r.issues.length ? '<tr class="sub"><td></td><td colspan="3">' + r.issues.map(i => '<span class="' + i.level + '">' + esc(i.msg) + '</span>').join(' · ') + '</td></tr>' : '');
    });
    h += '</tbody></table>';
    // univers libres
    const used = new Set(plan.rows.map(r => r.ma));
    const free = [];
    for (let u = 1; free.length < 8 && u < 512; u++) if (!used.has(u)) free.push(u);
    h += '<p class="muted small">Premiers univers libres (MA) : ' + free.join(', ') + '. Colonne « Réseau » : ce que le moniteur voit passer' + (App.Pages.moniteur && App.Pages.moniteur.on ? '.' : ' (démarre le moniteur pour l\'afficher).') + '</p>';
    return h;
  };
  P.mount = function (el) {
    el.addEventListener('segchange', e => { if (e.detail.name === 'src') { P.src = e.detail.value; App.render(); } });
  };
  P.acts = {
    expected: async () => {
      const s = Store.settings();
      const v = await UI.form('Univers utilisés par la console', [{ key: 'r', label: 'Univers (numérotation MA2)', value: s.expected, placeholder: 'ex. 1-12, 20', hint: 'MA 1 = Art-Net 0 = sACN 1' }], 'OK');
      if (!v) return;
      s.expected = v.r;
      Store.save();
      App.render();
    },
    share: () => {
      const s = Store.settings();
      const plan = M.universePlan(entries(), { expected: M.parseRanges(s.expected) });
      const txt = ['Plan d\'univers — ' + U.fmtDate(Date.now())].concat(plan.rows.map(r => 'MA ' + r.ma + ' (' + C.protoName(r.proto) + ' ' + r.univ + ') : ' +
        (r.outs.map(x => x.name + ' DMX' + (x.port + 1)).join(', ') || '—') + (r.ins.length ? ' ← entrée ' + r.ins.map(x => x.name + ' DMX' + (x.port + 1)).join(', ') : ''))).concat(plan.issues.length ? ['', 'Problèmes :'].concat(plan.issues.map(i => '- ' + i.msg)) : []).join('\n');
      Bridge.share(txt, 'Plan d\'univers');
    }
  };
  P.padY = () => P.acts.expected();
  P.padHelp = { Y: 'univers de la console' };
  App.Pages.univers = P;
})();
