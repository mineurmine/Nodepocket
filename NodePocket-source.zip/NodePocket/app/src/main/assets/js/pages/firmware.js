/* Page « Firmware » : versions du parc, nodes en retard, mise à jour par USB (DFU) */
(function () {
  'use strict';
  const esc = U.esc, C = App.C, M = Model;
  const P = { live: true, file: null, parsed: null, target: null };

  function statusBadge(st) {
    if (!st || !st.fw) return UI.badge('inconnu', 'mute', 'Lis le node (USB ou page web) pour connaître sa version');
    if (st.status === 'old') return UI.badge('en retard', 'warn', 'Référence : ' + U.fmtFirmware(st.ref));
    if (st.status === 'ok') return UI.badge('à jour', 'ok');
    return UI.badge('?', 'mute', 'Version non comparable');
  }

  P.enter = function (params) {
    if (params && params.id) P.target = params.id;
  };

  P.render = function () {
    const nodes = Store.nodes();
    const fs = M.firmwareStatus(nodes, Store.state.fwPinned);
    const old = nodes.filter(n => fs.byNode[n.id].status === 'old');
    const unknown = nodes.filter(n => !fs.byNode[n.id].fw);
    let h = '<div class="pghead"><h1>Firmware <small>' + (old.length ? U.plural(old.length, 'node') + ' en retard' : 'parc à jour') + (unknown.length ? ' · ' + unknown.length + ' inconnu' + (unknown.length > 1 ? 's' : '') : '') + '</small></h1>' +
      '<div class="tools"><button type="button" class="btn" data-act="readAll" data-fid="fw_read">Lire les versions</button></div></div>';
    // modèles
    const keys = Array.from(new Set(nodes.map(n => fs.byNode[n.id].key)));
    h += '<div class="grid models">' + keys.map(k => {
      const ns = nodes.filter(n => fs.byNode[n.id].key === k);
      const ref = fs.refs[k];
      const nOld = ns.filter(n => fs.byNode[n.id].status === 'old').length;
      return '<div class="card"><div class="c-h"><b>' + esc(M.modelLabel(ns[0])) + '</b></div><div class="c-m">Référence : <b>' + esc(ref ? U.fmtFirmware(ref.fw) : '—') + '</b> ' +
        (ref && ref.pinned ? UI.badge('fixée', 'mute') : ref ? '<span class="muted small">(la plus récente du parc)</span>' : '') + '</div>' +
        '<div class="c-f">' + U.plural(ns.length, 'node') + (nOld ? ' · <span class="warn">' + nOld + ' en retard</span>' : '') + ' <button type="button" class="btn xs" data-act="pin" data-arg="' + esc(k) + '">fixer…</button></div></div>';
    }).join('') + '</div>';
    // nodes
    h += '<table class="raw fwtable"><thead><tr><th>Node</th><th>Firmware</th><th>État</th><th></th></tr></thead><tbody>' +
      nodes.slice().sort((a, b) => (fs.byNode[a.id].status === 'old' ? -1 : 0) - (fs.byNode[b.id].status === 'old' ? -1 : 0) || U.ipCompare(a.ip, b.ip)).map(n => {
        const st = fs.byNode[n.id];
        const b = Store.brandInfo(n);
        const btn = b.id === 'electroconcept' || n.usbSeen ?
          '<button type="button" class="btn xs' + (st.status === 'old' ? ' primary' : '') + '" data-act="target" data-arg="' + n.id + '">' + (P.target === n.id ? 'choisi' : 'mettre à jour') + '</button>' :
          '<span class="muted small" title="' + esc('Mise à jour avec ' + b.tool) + '">' + esc(b.name) + ' : outil du fabricant</span>';
        return '<tr' + (P.target === n.id ? ' class="selrow"' : '') + '><td>' + C.statusDot(n) + esc(Store.label(n)) + ' <small class="muted">' + esc(n.ip || '') + '</small></td><td>' + esc(st.fw ? U.fmtFirmware(st.fw) : '—') + '</td><td>' + statusBadge(st) + '</td>' +
          '<td>' + btn + '</td></tr>';
      }).join('') + '</tbody></table>';
    // mise à jour
    const n = P.target && Store.node(P.target);
    const dfu = USB.scan().dfu;
    h += '<section class="box fwflow"><h3>Mise à jour par USB (Electroconcept)' + (n ? ' — ' + esc(Store.label(n)) : '') + '</h3>';
    if (!n && !dfu) h += '<p class="muted">Choisis un node dans la liste ci-dessus.</p>';
    else {
      const usbOk = n && USB.state === 'ready' && USB.nodeId === n.id;
      const step1 = !!P.parsed, step2 = usbOk || !!dfu;
      h += '<ol class="steps">' +
        '<li class="' + (step1 ? 'done' : 'cur') + '"><b>Fichier du firmware</b> ' + (P.parsed ? '<span>' + esc(P.file.name) + ' · ' + Math.round(P.parsed.size / 1024) + ' Ko · ' + esc({ dfu: 'DFU', dfuse: 'DfuSe', bin: 'binaire', hex: 'Intel HEX' }[P.parsed.kind]) +
          (P.parsed.suffix ? (P.parsed.suffix.crcOk ? ' · signature OK' : ' · <span class="err">signature fausse</span>') : '') + '</span>' : '<span class="muted">fourni par Electroconcept sur demande</span>') +
          ' <button type="button" class="btn sm" data-act="pick" data-fid="fw_pick">' + (P.parsed ? 'Changer' : 'Choisir le fichier…') + '</button></li>' +
        '<li class="' + (step2 ? 'done' : step1 ? 'cur' : '') + '"><b>Node branché en USB</b> ' + (dfu ? '<span class="warn">déjà en mode DFU</span>' : usbOk ? '<span class="ok">reconnu</span>' : '<span class="muted">branche-le à la console : il doit apparaître dans l\'onglet USB comme « ' + esc(n ? Store.label(n) : '') + ' »</span>') + '</li>' +
        '<li class="' + (step1 && step2 ? 'cur' : '') + '"><b>Envoi</b> <span class="muted">passage en DFU, écriture, redémarrage, relecture de la version</span></li></ol>';
      h += '<div class="row-btns"><button type="button" class="btn primary" data-act="go" data-fid="fw_go"' + (step1 && step2 ? '' : ' disabled') + '>Lancer la mise à jour</button></div>';
    }
    h += '<p class="muted small">Electroconcept ne publie pas ses firmwares : demande-les à electroconcept@electroconcept.fr. L\'appli met le node en mode DFU comme dmx-tools, puis envoie le fichier selon la norme USB DFU. Cette dernière étape n\'a pas encore pu être essayée sur un vrai node : si le node n\'apparaît pas en DFU standard, rien n\'est écrit et l\'inspecteur USB (onglet USB) donne le détail à m\'envoyer.</p></section>';
    return h;
  };

  P.acts = {
    target: el => { P.target = el.dataset.arg; App.render(); },
    pin: async el => {
      const k = el.dataset.arg;
      const v = await UI.form('Version de référence', [{ key: 'v', label: 'Firmware le plus récent pour ce modèle', value: Store.state.fwPinned[k] || '', placeholder: 'ex. Jul 15 2026 ou 15/07/2026', hint: 'vide = la plus récente vue dans le parc' }], 'OK');
      if (!v) return;
      if (v.v.trim()) Store.state.fwPinned[k] = v.v.trim(); else delete Store.state.fwPinned[k];
      Store.save();
      App.render();
    },
    readAll: () => {
      const ns = Store.nodes().filter(n => RT.isOnline(n) || (USB.nodeId === n.id && USB.state === 'ready'));
      if (!ns.length) { UI.toast('Aucun node en ligne', 'err'); return; }
      return C.batch('Lire les versions', ns, async (n, log) => {
        const r = await Ops.read(n, USB.nodeId === n.id && USB.state === 'ready' ? 'usb' : 'auto', log);
        return { ok: true, msg: r.canon.firmware ? U.fmtFirmware(r.canon.firmware) : 'version non communiquée (' + Store.brandInfo(n).name + ')' };
      });
    },
    pick: async () => {
      let f;
      try { f = await Bridge.pickFile('*/*'); } catch (e) { return; }
      try {
        const parsed = DFU.parseFile(f.bytes, f.name);
        P.file = f; P.parsed = parsed;
        const errs = DFU.check(parsed, null).filter(c => c.level === 'err');
        if (errs.length) UI.toast(errs[0].msg, 'err');
      } catch (e) { P.file = null; P.parsed = null; UI.toast('Fichier illisible : ' + e.message, 'err'); }
      App.render();
    },
    go: async () => {
      let n = P.target && Store.node(P.target);
      if (!n) {
        const id = await UI.choose('Quel node est en mode DFU ?', Store.nodes().map(x => ({ label: Store.label(x), hint: x.ip, value: x.id })));
        if (!id) return;
        n = Store.node(id); P.target = id;
      }
      const ok = await UI.confirm('Mise à jour du firmware', 'Envoyer <b>' + esc(P.file.name) + '</b> dans <b>' + esc(Store.label(n)) + '</b> ?<br><br>Ne débranche pas le node pendant l\'envoi. Si quelque chose se passe mal, le node reste en mode DFU et l\'envoi peut être relancé.', 'Lancer', true);
      if (!ok) return;
      const ctl = UI.progress('Mise à jour de ' + Store.label(n), { wide: true });
      try {
        const r = await Fw.update(n, P.file, ctl);
        ctl.log(r.msg, r.ok ? 'ok' : 'warn');
        ctl.done(r.ok ? 'Firmware mis à jour' : 'À vérifier', r.ok ? 'ok' : 'err');
      } catch (e) {
        ctl.log(e.message, 'err');
        Store.log(n, 'Mise à jour firmware', false, e.message);
        ctl.done('Mise à jour interrompue', 'err');
      }
      App.render();
    }
  };
  P.padStart = () => { if (P.parsed) P.acts.go(); else P.acts.pick(); };
  P.padY = () => P.acts.readAll();
  P.padHelp = { Y: 'lire les versions', START: 'choisir le fichier / lancer' };
  App.Pages.firmware = P;
})();
