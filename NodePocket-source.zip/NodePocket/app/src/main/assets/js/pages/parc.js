/* Page « Parc » : la liste des nodes */
(function () {
  'use strict';
  const esc = U.esc, C = App.C, M = Model;
  let filter = { q: '', tag: '' };

  function matches(n) {
    if (filter.tag && (n.tags || []).indexOf(filter.tag) < 0) return false;
    if (!filter.q) return true;
    const q = U.norm(filter.q);
    const c = Store.wanted(n);
    return [Store.label(n), n.ip, n.serial, c.shortName, c.longName, n.notes, C.brandText(n)].some(x => U.norm(x).indexOf(q) >= 0);
  }

  function card(n, fwst) {
    const c = Store.wanted(n);
    const pend = Store.pending(n);
    const st = RT.status(n);
    const sel = App.sel.has(n.id);
    const busy = RT.busy[n.id];
    const poll = RT.poll[n.id];
    const lastTxt = n.last ? 'lu ' + U.timeAgo(n.last.at) + ' (' + Ops.VIA[n.last.via] + ')' : 'jamais lu';
    const probs = M.validate(c).filter(p => p.level === 'err');
    return '<div class="card node st-' + st + (sel ? ' sel' : '') + '" data-act="' + (App.selecting ? 'toggle' : 'node') + '" data-arg="' + n.id + '" data-fid="n_' + n.id + '" tabindex="0">' +
      (App.selecting ? '<span class="tick">' + (sel ? '✓' : '') + '</span>' : '') +
      '<div class="c-h">' + C.statusDot(n) + '<b class="nm">' + esc(Store.label(n)) + '</b><span class="ip">' + esc(n.ip || (c.ipMode === 'dhcp' ? 'DHCP' : '—')) + '</span></div>' +
      '<div class="c-m">' + C.brandBadge(n) + ' ' + esc(n.model ? n.model + ' univers' : 'Node') + ' · ' + C.protoName(c.protocol) +
      (c.shortName && c.shortName !== Store.label(n) ? ' · <span class="muted">' + esc(c.shortName) + '</span>' : '') + ' ' + C.fwBadge(n, fwst) +
      (st === 'usb' ? UI.badge('USB', 'usb') : '') + '</div>' +
      '<div class="ports">' + C.portChips(n, c) + '</div>' +
      '<div class="c-f">' + (busy ? '<span class="busy">' + esc(busy) + '…</span>' :
        (pend.length ? '<span class="warn">' + U.plural(pend.length, 'écart') + ' à appliquer</span> · ' : '') +
        (probs.length ? '<span class="err">' + esc(probs[0].msg) + '</span> · ' : '') +
        '<span class="muted">' + esc(lastTxt) + (poll && RT.isOnline(n) && poll.nodeReport ? '' : '') + '</span>') + '</div>' +
      '</div>';
  }

  function foundCard(m) {
    return '<div class="card found">' +
      '<div class="c-h">' + UI.dot('ok') + '<b class="nm">' + esc(m.shortName || m.longName || 'Node') + '</b><span class="ip">' + esc(m.ip) + '</span></div>' +
      '<div class="c-m muted">' + UI.badge(Brands.label(Brands.detect({ poll: m })), 'brand') + ' ' + esc(m.longName) + ' · ' + m.numPorts + ' port(s) · ' + esc(m.mac || '') + (m.dhcp ? ' · DHCP' : '') + '</div>' +
      '<div class="row-btns"><button type="button" class="btn sm primary" data-act="addFound" data-arg="' + esc(m.ip) + '">Ajouter au parc</button></div></div>';
  }

  const P = {
    live: true,
    render() {
      const nodes = Store.nodes();
      const list = nodes.filter(matches).sort((a, b) => U.ipCompare(a.ip, b.ip) || Store.label(a).localeCompare(Store.label(b)));
      const tags = C.allTags();
      const fw = M.firmwareStatus(nodes, Store.state.fwPinned).byNode;
      const found = Disco.unknown();
      const online = nodes.filter(n => RT.isOnline(n)).length;
      let h = '<div class="pghead"><h1>Parc <small>' + U.plural(nodes.length, 'node') + ' · ' + online + ' en ligne</small></h1>' +
        '<div class="tools"><input type="search" class="search" id="parcSearch" placeholder="Nom, IP, n° de série…" value="' + esc(filter.q) + '">' +
        '<button type="button" class="btn" data-act="poll" data-fid="b_poll" title="Envoyer un ArtPoll">Rechercher</button>' +
        '<button type="button" class="btn primary" data-act="add" data-fid="b_add">+ Ajouter</button>' +
        '<button type="button" class="btn' + (App.selecting ? ' on' : '') + '" data-act="selmode" data-fid="b_sel">Sélection</button></div></div>';
      if (tags.length) h += '<div class="tagbar"><button type="button" class="tag' + (!filter.tag ? ' on' : '') + '" data-act="tag" data-arg="">Tous</button>' + tags.map(t => '<button type="button" class="tag' + (filter.tag === t ? ' on' : '') + '" data-act="tag" data-arg="' + esc(t) + '">' + esc(t) + '</button>').join('') + '</div>';
      if (!nodes.length) {
        h += '<div class="empty"><p>Aucun node dans le parc.</p><p class="muted">Ajoute tes nodes avec leur adresse IP fixe, ou branche-en un en USB, ou lance une recherche sur le réseau.</p>' +
          '<div class="row-btns center"><button type="button" class="btn primary" data-act="add">Ajouter un node</button><button type="button" class="btn" data-act="addSeries">Préparer une série</button>' +
          (Bridge.demo ? '<button type="button" class="btn" data-act="demoFleet">Charger le parc de démo</button>' : '') + '</div></div>';
      } else {
        h += '<div class="grid nodes">' + list.map(n => card(n, fw[n.id])).join('') + '</div>';
        if (!list.length) h += '<div class="empty muted">Aucun node ne correspond.</div>';
      }
      // consoles et logiciels qui répondent aussi en Art-Net : rangés à part
      const nodesFound = found.filter(m => !P.isConsole(m)), others = found.filter(P.isConsole);
      if (nodesFound.length) h += '<h2 class="sub">Détectés sur le réseau, pas encore dans le parc</h2><div class="grid nodes">' + nodesFound.map(foundCard).join('') + '</div>';
      if (others.length) h += '<details class="box"><summary>' + U.plural(others.length, 'autre appareil') + ' Art-Net (consoles, logiciels)</summary><div class="grid nodes">' + others.map(foundCard).join('') + '</div></details>';
      h += '<div class="row-btns foot"><button type="button" class="btn sm" data-act="addSeries">Préparer une série de nodes…</button><button type="button" class="btn sm" data-act="scanRange">Chercher par plage d\'IP…</button>' +
        (Bridge.demo ? '<button type="button" class="btn sm" data-act="demoTools">Outils de démo…</button>' : '') + '</div>';
      if (App.selecting) {
        const n = App.sel.size;
        h += '<div class="selbar"><span>' + U.plural(n, 'node') + ' sélectionné' + (n > 1 ? 's' : '') + '</span>' +
          '<button type="button" class="btn sm" data-act="selAll">Tout</button><button type="button" class="btn sm" data-act="selNone">Aucun</button>' +
          '<button type="button" class="btn sm" data-act="selRead"' + (n ? '' : ' disabled') + '>Lire</button>' +
          '<button type="button" class="btn sm" data-act="selApply"' + (n ? '' : ' disabled') + '>Appliquer le prévu</button>' +
          '<button type="button" class="btn sm primary" data-act="selLot"' + (n ? '' : ' disabled') + '>Modifier en lot…</button></div>';
      }
      return h;
    },
    // écouteurs posés une fois sur la zone de contenu (les cartes sont mises à jour sur place)
    mount(el) {
      el.addEventListener('input', e => {
        if (e.target.id !== 'parcSearch') return;
        filter.q = e.target.value;
        App.render();
      });
      App.longPress(el, '.card.node', c => C.nodeMenu(Store.node(c.dataset.arg)));
    },
    acts: {
      poll: async () => {
        UI.toast('Recherche Art-Net…');
        const list = await Disco.poll();
        await Probe.tick(true);
        UI.toast(U.plural(list.length, 'node') + ' a répondu en Art-Net');
        App.render();
      },
      add: async () => {
        const n = await C.nodeForm(null);
        if (n) { App.render(); if (U.isIp(n.ip)) Probe.one(n); }
      },
      addFound: async el => {
        const m = Disco.live[el.dataset.arg];
        if (!m) return;
        const plan = Model.fromPoll(m);
        delete plan.ipNow;
        const n = await C.nodeForm(null, { name: m.shortName, ip: m.ip, model: C.modelFor(m.numPorts), mac: m.mac, plan: {} });
        if (n) { n.mac = m.mac; Disco.match(m); Store.save(); App.render(); }
        void plan;
      },
      tag: el => { filter.tag = el.dataset.arg; App.render(); },
      selmode: () => { App.selecting = !App.selecting; if (!App.selecting) App.sel.clear(); App.render(); },
      toggle: el => { const id = el.dataset.arg; if (App.sel.has(id)) App.sel.delete(id); else App.sel.add(id); App.render(); },
      selAll: () => { Store.nodes().filter(matches).forEach(n => App.sel.add(n.id)); App.render(); },
      selNone: () => { App.sel.clear(); App.render(); },
      selRead: () => C.readMany(Store.nodes().filter(n => App.sel.has(n.id))),
      selApply: () => C.applyMany(Store.nodes().filter(n => App.sel.has(n.id))),
      selLot: () => App.go('lot', { ids: Array.from(App.sel) }),
      addSeries: () => P.series(),
      scanRange: () => P.scanRange(),
      demoFleet: () => P.loadDemo(),
      demoTools: () => P.demoTools()
    },
    padX(el) {
      const c = el && el.closest('.card.node');
      if (c) C.nodeMenu(Store.node(c.dataset.arg));
      else P.acts.add();
    },
    padY() { P.acts.poll(); },
    padStart() { P.acts.add(); },
    padHelp: { X: 'menu du node sélectionné', Y: 'rechercher sur le réseau', START: 'ajouter un node' },

    /** Prépare une série de nodes neufs (adresses, noms et univers à la suite) */
    async series() {
      const s = Store.settings();
      const v = await UI.form('Préparer une série de nodes', [
        { key: 'count', label: 'Nombre de nodes', type: 'number', value: 4, min: 1, max: 64 },
        { key: 'model', label: 'Modèle', type: 'select', value: 4, options: [[1, '1 univers'], [2, '2 univers'], [4, '4 univers']] },
        { key: 'ip', label: 'Première adresse IP', type: 'ip', value: U.nextIp(U.intToIp(U.ipToInt(s.subnetIp || '2.0.0.0')), 11) },
        { key: 'mask', label: 'Masque', type: 'ip', value: s.subnetMask || '255.0.0.0' },
        { key: 'name', label: 'Nom (## = numéro)', value: 'NODE-##' },
        { key: 'proto', label: 'Protocole', type: 'select', value: 'artnet', options: [['artnet', 'Art-Net'], ['sacn', 'sACN']] },
        { key: 'univ', label: 'Premier univers (réseau)', type: 'number', value: 0, min: 0, hint: 'Art-Net : 0 = univers MA 1 ; sACN : à partir de 1' },
        { key: 'tag', label: 'Production', value: '' }
      ], 'Créer', {
        validate: v => {
          if (!U.isIp(v.ip)) return 'Adresse IP invalide';
          if (!U.isMask(v.mask)) return 'Masque invalide';
          if (v.proto === 'sacn' && v.univ < 1) return 'sACN : univers 1 minimum';
          return '';
        }
      });
      if (!v) return;
      let u = Number(v.univ);
      const created = [];
      for (let i = 0; i < v.count; i++) {
        const ip = U.nextIp(v.ip, i);
        const name = String(v.name || 'NODE-##').replace(/#+/g, h => String(i + 1).padStart(h.length, '0'));
        const ports = [];
        for (let k = 0; k < v.model; k++) ports.push({ dir: 'out', univOut: u++ });
        const plan = { ipMode: 'static', ip, mask: v.mask, shortName: name.slice(0, 17), longName: name, protocol: v.proto, ports };
        created.push(Store.addNode({ name, ip, model: Number(v.model), tags: v.tag ? [v.tag.trim()] : [], plan }));
      }
      Store.log(null, 'Série de ' + created.length + ' nodes préparée', true);
      UI.alert('Série créée', U.plural(created.length, 'node') + ' ajouté' + (created.length > 1 ? 's' : '') + ' avec leur config prévue (IP ' + esc(v.ip) + ' et suivantes).<br><br>Branche ensuite chaque node en USB : l\'onglet USB propose d\'y écrire la config prévue.');
      App.render();
    },

    /** Teste une plage d'adresses (port 80) pour trouver les nodes qui ne répondent pas en Art-Net */
    async scanRange() {
      const s = Store.settings();
      const base = U.isIp(s.subnetIp) ? s.subnetIp.split('.').slice(0, 3).join('.') : '2.0.0';
      const v = await UI.form('Chercher par plage d\'IP', [
        { key: 'from', label: 'De', type: 'ip', value: base + '.1' },
        { key: 'to', label: 'À', type: 'ip', value: base + '.254' }
      ], 'Chercher', { validate: v => (!U.isIp(v.from) || !U.isIp(v.to) ? 'Adresses invalides' : (U.ipToInt(v.to) - U.ipToInt(v.from) > 1024 || U.ipToInt(v.to) < U.ipToInt(v.from) ? '1024 adresses maximum' : '')) });
      if (!v) return;
      const ips = [];
      for (let x = U.ipToInt(v.from); x <= U.ipToInt(v.to); x++) ips.push(U.intToIp(x));
      const ctl = UI.progress('Recherche sur ' + ips.length + ' adresses');
      let done = 0;
      const hits = [];
      await U.pool(ips, 16, async ip => {
        if (ctl.cancelled) return;
        const r = await Bridge.tcpProbe(ip, 80, 700).catch(() => ({ open: false }));
        done++;
        if (done % 8 === 0) ctl.set(done / ips.length, done + ' / ' + ips.length);
        if (r.open) { hits.push(ip); ctl.log('Page web trouvée : ' + ip + (Store.byIp(ip) ? ' (' + Store.label(Store.byIp(ip)) + ')' : ' — nouveau'), Store.byIp(ip) ? '' : 'ok'); }
      });
      const fresh = hits.filter(ip => !Store.byIp(ip));
      ctl.done(hits.length + ' appareil(s) avec une page web, ' + fresh.length + ' hors du parc');
      await ctl.closed;
      if (fresh.length && await UI.confirm('Ajouter', 'Ajouter ' + U.plural(fresh.length, 'appareil') + ' au parc (' + fresh.slice(0, 6).join(', ') + (fresh.length > 6 ? '…' : '') + ') ?', 'Ajouter')) {
        fresh.forEach(ip => Store.addNode({ ip, name: 'Node ' + ip.split('.').pop() }));
        App.render();
      }
    },

    /** Consoles et logiciels (pas des nodes) parmi les réponses Art-Net */
    isConsole(m) {
      const det = Brands.detect({ poll: m });
      const t = (m.shortName || '') + ' ' + (m.longName || '') + ' ' + (det.model || '');
      return /grand ?ma|onpc|madrix|magic ?q|quick ?q|\bhog\b|\beos\b|\bion\b|\bgio\b|dot2|avolites|titan|qlc|resolume|lightkey|daslight|sunlite|martin m|onyx|obsidian|console|\bdesk\b|magichd|magicvis/i.test(t) &&
        !/node|gateway|snake|npu|lumi|\d ?port|response|\bode\b/i.test(t);
    },

    welcome() {
      UI.dialog({
        title: 'Bienvenue dans Node Pocket',
        body: '<div class="txt"><p>Une seule appli pour tout ton parc de nodes : Electroconcept, Luminex, ETC, ChamSys, MA, Enttec, DMXking et les petits nodes Art-Net.</p><ul>' +
          '<li><b>Parc</b> : ta liste de nodes en IP fixe, leur marque, leur état en direct (Art-Net) et les écarts avec ce qui est prévu.</li>' +
          '<li><b>Fiche</b> d\'un node : ses réglages, lus et écrits par le meilleur chemin selon la marque (USB, page web, API, Art-Net), puis relus pour vérifier.</li>' +
          '<li><b>USB</b> : branche un node Electroconcept à la console pour le régler avant que le réseau soit monté.</li>' +
          '<li><b>Univers</b>, <b>Lot</b>, <b>Firmware</b>, <b>Sauvegardes</b> : plan d\'univers, modifications en série, versions, configs par production.</li></ul>' +
          '<p>Pour les techniciens : <b>Réglages › Mode › Mode simple</b> (juste l\'IP, Art-Net / sACN et l\'univers de chaque port).</p>' +
          (Bridge.demo ? '<p class="warn">Mode démo : les nodes sont simulés dans le navigateur.</p>' : '') + '<p class="sigline">' + App.SIGNATURE + '</p></div>',
        buttons: Bridge.demo ? [{ label: 'Commencer vide', value: null }, { label: 'Charger le parc de démo', value: 'demo', kind: 'primary' }] : [{ label: 'C\'est parti', value: null, kind: 'primary' }]
      }).then(v => { if (v === 'demo') P.loadDemo(); });
    },

    loadDemo() {
      Bridge.sim.fleet.forEach((sn, i) => {
        if (sn.s.ipMode === 'dhcp') return;
        if (Store.byIp(sn.s.ip)) return;
        Store.addNode({ name: sn.s.shortName, ip: sn.s.ip, model: sn.model, tags: [sn.brand ? 'Prestataire' : i < 6 ? 'Tournée 2026' : 'Salle A'], login: sn.s.loginPage ? { user: sn.s.login, pass: sn.s.pass } : {}, brand: 'auto' });
      });
      Store.save();
      Disco.poll().then(() => Probe.tick(true));
      App.render();
    },

    async demoTools() {
      const sim = Bridge.sim;
      const items = sim.fleet.map((n, i) => ({ n, i })).filter(x => !x.n.brand).map(({ n, i }) => ({ label: (sim.plugged === i ? '⏏ Débrancher ' : 'Brancher en USB : ') + n.s.shortName, hint: n.product + ' · ' + n.serial + (n.mode === 'dfu' ? ' · en DFU' : ''), value: 'plug' + i }));
      items.push({ label: 'Couper / rétablir le node « LOINTAIN »', value: 'cut' });
      items.push({ label: 'Fichier firmware de démo (Sep 2026)', hint: 'à choisir ensuite dans l\'onglet Firmware', value: 'fw' });
      const v = await UI.choose('Outils de démo', items);
      if (!v) return;
      if (v.indexOf('plug') === 0) {
        const i = +v.slice(4);
        if (sim.plugged === i) sim.unplug(); else sim.plug(i);
        App.go('usb');
      } else if (v === 'cut') {
        const n = sim.fleet[3];
        n.online = !n.online;
        UI.toast('LOINTAIN ' + (n.online ? 'rétabli' : 'coupé'));
      } else if (v === 'fw') {
        Bridge.nextPick = { name: 'node-firmware-2026-09.dfu', bytes: Sim.SimNode.demoFirmware('Sep 1 2026') };
        UI.toast('Fichier prêt : il sera pris au prochain « Choisir le fichier »');
      }
    }
  };
  App.Pages.parc = P;
})();
