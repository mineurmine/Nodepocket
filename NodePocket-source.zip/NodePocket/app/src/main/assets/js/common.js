/* Node Pocket — morceaux d'affichage et opérations partagés entre les pages */
(function (root) {
  'use strict';
  const esc = U.esc, M = Model;
  const C = {};
  App.C = C;

  // ------------------------------------------------------------ univers
  C.univText = function (proto, u, short) {
    if (u == null || u === '' || isNaN(u)) return '—';
    const num = Store.settings().numbering;
    const ma = proto === 'sacn' ? Number(u) : Number(u) + 1;
    if (num === 'ma') return (short ? '' : 'MA ') + ma;
    if (num === 'net' || short) return String(u);
    return u + ' <small>MA ' + ma + '</small>';
  };
  C.protoName = p => (p === 'sacn' ? 'sACN' : p === 'artnet' ? 'Art-Net' : '—');

  /** Puces des ports d'un node (config voulue ; données présentes d'après Art-Net) */
  C.portChips = function (n, canon) {
    canon = canon || Store.wanted(n);
    const poll = RT.poll[n.id];
    const np = Store.ports(n);
    let h = '';
    for (let i = 0; i < np; i++) {
      const p = canon.ports[i] || {};
      const pu = M.portUniverse(canon, p);
      const live = poll && poll.ports[i] && RT.isOnline(n) ? (p.dir === 'in' ? poll.ports[i].inData : poll.ports[i].outData) : false;
      const pend = Store.pending(n).some(d => d.path.indexOf('ports.' + i + '.') === 0);
      h += '<span class="pt ' + (p.dir === 'in' ? 'in' : 'out') + (live ? ' live' : '') + (pend ? ' pend' : '') + '" title="DMX ' + (i + 1) + (p.dir === 'in' ? ' : entrée, envoie ' : ' : sortie, reçoit ') + (pu ? C.protoName(pu.proto) + ' ' + pu.univ + ' (MA ' + pu.ma + ')' : '?') + (live ? ' — données présentes' : '') + '">' +
        '<b>' + (i + 1) + '</b>' + (p.dir === 'in' ? '◂' : '▸') + (pu ? C.univText(pu.proto, pu.univ, true) : '?') + '</span>';
    }
    return h;
  };

  C.statusDot = function (n) {
    const st = RT.status(n);
    const map = { usb: ['usb', 'branché en USB'], busy: ['busy', 'opération en cours'], on: ['ok', 'en ligne'], lost: ['warn', 'ne répond plus'], off: ['', 'pas vu sur le réseau'] };
    const m = map[st] || map.off;
    return UI.dot(m[0], m[1]);
  };

  C.fwBadge = function (n, st) {
    st = st || M.firmwareStatus(Store.nodes(), Store.state.fwPinned).byNode[n.id];
    if (!st || !st.fw) return '';
    if (st.status === 'old') return UI.badge('fw ' + U.fmtFirmware(st.fw) + ' ↓', 'warn', 'Plus ancien que ' + U.fmtFirmware(st.ref));
    return UI.badge('fw ' + U.fmtFirmware(st.fw), 'mute');
  };

  // ------------------------------------------------------------ comptes rendus
  C.reportHtml = function (n, rep) {
    let h = '';
    const fmt = (path, v) => {
      const d = M.fieldDef(path);
      if (d && (d.kind === 'enum' || d.kind === 'bool')) return esc(M.enumLabel(path, v));
      return esc(v == null ? '' : v);
    };
    if (rep.changes.length) h += '<div class="rep-ch">' + rep.changes.map(c => '<div>✓ ' + esc(c.label) + ' : <s>' + esc(c.from) + '</s> → <b>' + esc(c.to) + '</b></div>').join('') + '</div>';
    else if (!rep.errors.length) h += '<div class="muted">Aucun changement nécessaire.</div>';
    rep.remaining.forEach(r => { h += '<div class="err">✗ ' + esc(r.label) + ' : voulu ' + fmt(r.path, r.want) + ', relu ' + fmt(r.path, r.have) + '</div>'; });
    rep.errors.forEach(e => { h += '<div class="err">✗ ' + esc(e) + '</div>'; });
    if (rep.missing.length) h += '<div class="warn">Non disponible par ' + esc(Ops.VIA[rep.via]) + ' : ' + rep.missing.map(p => esc(M.pathLabel(p))).join(', ') + '</div>';
    rep.notes.forEach(x => { h += '<div class="warn">' + esc(x) + '</div>'; });
    return h;
  };

  // ------------------------------------------------------------ opérations avec fenêtre de suivi
  C.read = async function (n, via) {
    const ctl = UI.progress('Lecture de ' + Store.label(n));
    try {
      ctl.set(0.1, 'Lecture via ' + Ops.VIA[Ops.pick(n, via)] + '…');
      const r = await Ops.read(n, via, (m, k) => ctl.log(m, k));
      ctl.done(r.partial ? 'Lu en Art-Net (partiel : noms, univers, état)' : 'Lu via ' + Ops.VIA[r.via] + ' : ' + Object.keys(M.flat(r.canon)).length + ' réglages', 'ok');
      App.render();
      return r;
    } catch (e) {
      ctl.log(e.message, 'err');
      ctl.done('Lecture impossible', 'err');
      return null;
    }
  };

  /** Écrit le prévu d'un node (ou "target") avec suivi */
  C.apply = async function (n, via, target) {
    target = target || n.plan;
    const pend = M.flat(target);
    if (!Object.keys(pend).length) { UI.toast('Rien de prévu pour ce node'); return null; }
    const ctl = UI.progress('Écriture dans ' + Store.label(n));
    ctl.set(0.05, 'Écriture via ' + Ops.VIA[Ops.pick(n, via)] + '…');
    const rep = await Ops.apply(n, target, via, (m, k) => ctl.log(m, k));
    const box = document.createElement('div');
    box.className = 'rep';
    box.innerHTML = C.reportHtml(n, rep);
    const lg = UI.top() && UI.top().el.querySelector('.plog');
    if (lg) lg.appendChild(box);
    ctl.done(rep.ok ? 'Terminé et vérifié' : (rep.errors.length ? 'Échec' : 'Terminé avec des écarts'), rep.ok ? 'ok' : 'err');
    App.render();
    return rep;
  };

  /** Même opération sur plusieurs nodes, l'un après l'autre */
  C.batch = async function (title, nodes, fn) {
    const ctl = UI.progress(title, { wide: true });
    const results = [];
    for (let i = 0; i < nodes.length; i++) {
      if (ctl.cancelled) { ctl.log('Arrêté par l\'utilisateur', 'warn'); break; }
      const n = nodes[i];
      ctl.set(i / nodes.length, Store.label(n) + ' (' + (i + 1) + '/' + nodes.length + ')…');
      try {
        const r = await fn(n, m => ctl.log('  ' + m), ctl);
        results.push({ n, ok: r && r.ok !== false, r });
        ctl.log((r && r.ok === false ? '✗ ' : '✓ ') + Store.label(n) + (r && r.msg ? ' — ' + r.msg : ''), r && r.ok === false ? 'err' : 'ok');
      } catch (e) {
        results.push({ n, ok: false, err: e.message });
        ctl.log('✗ ' + Store.label(n) + ' — ' + e.message, 'err');
      }
    }
    const ok = results.filter(r => r.ok).length;
    ctl.done(ok + ' / ' + nodes.length + ' réussis', ok === nodes.length ? 'ok' : 'err');
    App.render();
    return results;
  };

  C.applyMany = function (nodes, via) {
    const list = nodes.filter(n => Store.pending(n).length);
    if (!list.length) { UI.toast('Aucun écart à appliquer'); return Promise.resolve([]); }
    return C.batch('Appliquer le prévu', list, async (n, log) => {
      const target = M.unflat(Object.fromEntries(Store.pending(n).map(d => [d.path, d.want])));
      const rep = await Ops.apply(n, target, via, log);
      return { ok: rep.ok, msg: rep.ok ? rep.changes.length + ' réglage(s) via ' + Ops.VIA[rep.via] : (rep.errors.concat(rep.remaining.map(r => r.label))).join(', ') };
    });
  };
  C.readMany = function (nodes, via) {
    return C.batch('Lire les nodes', nodes, async (n, log) => {
      const r = await Ops.read(n, via, log);
      return { ok: true, msg: 'via ' + Ops.VIA[r.via] + (r.partial ? ' (partiel)' : '') };
    });
  };

  /** Ouvre la page web d'origine du node, en plein écran */
  C.openWeb = async function (n) {
    if (!U.isIp(n.ip)) { UI.toast('Adresse IP inconnue', 'err'); return; }
    const page = Ops.pageFor(n);
    const cr = Ops.creds(n);
    UI.toast('Ouverture de http://' + n.ip + '/ …');
    page.show(true, Store.label(n) + ' — ' + n.ip);
    try {
      await page.open('http://' + n.ip + '/', cr.user, cr.pass, Store.settings().webTimeout * 1000);
    } catch (e) {
      UI.toast(e.message, 'err');
    }
  };

  /** Menu d'un node (appui long, bouton X, bouton ⋯) */
  C.nodeMenu = async function (n) {
    const pend = Store.pending(n).length;
    const items = [
      { label: 'Ouvrir la fiche', value: 'open' },
      { label: 'Lire les réglages', hint: 'par ' + Ops.VIA[Ops.pick(n)], value: 'read' },
      { label: 'Appliquer le prévu', hint: pend ? U.plural(pend, 'écart') : 'aucun écart', value: 'apply', disabled: !pend },
      { label: 'Page web du node', hint: 'http://' + (n.ip || '?') + '/', value: 'web', disabled: !U.isIp(n.ip) },
      { label: 'Identifier', hint: 'fait clignoter le node (Art-Net)', value: 'identify', disabled: !U.isIp(n.ip) },
      { label: App.sel.has(n.id) ? 'Retirer de la sélection' : 'Ajouter à la sélection', value: 'sel' },
      { label: 'Dupliquer', hint: 'nouveau node avec la même config', value: 'dup' },
      { label: 'Supprimer du parc', value: 'del', danger: true }
    ];
    const v = await UI.choose(Store.label(n), items);
    if (!v) return;
    if (v === 'open') App.go('fiche', { id: n.id });
    else if (v === 'read') await C.read(n);
    else if (v === 'apply') await C.apply(n);
    else if (v === 'web') await C.openWeb(n);
    else if (v === 'identify') UI.toast(await Ops.action(n, 'identify'));
    else if (v === 'sel') { if (App.sel.has(n.id)) App.sel.delete(n.id); else App.sel.add(n.id); App.selecting = App.sel.size > 0; App.render(); }
    else if (v === 'dup') {
      const copy = Store.addNode({ name: Store.label(n) + ' (copie)', model: n.model, ip: '', tags: n.tags.slice(), plan: U.clone(Store.wanted(n)) });
      ['firmware', 'serial', 'ipNow'].forEach(k => delete copy.plan[k]);
      copy.plan.ip = ''; copy.plan.ipMode = 'static';
      Store.save();
      App.go('fiche', { id: copy.id });
    } else if (v === 'del') {
      if (await UI.confirm('Supprimer', 'Retirer <b>' + esc(Store.label(n)) + '</b> du parc ? (le node lui-même n\'est pas modifié)', 'Supprimer', true)) {
        Store.removeNode(n.id);
        Store.log(n, 'Retiré du parc', true);
        App.sel.delete(n.id);
        if (App.page === 'fiche') App.back(); else App.render();
      }
    }
  };

  /** Formulaire d'ajout / modification d'un node */
  C.nodeForm = async function (n, preset) {
    const isNew = !n;
    const src = n || preset || {};
    const vals = await UI.form(isNew ? 'Ajouter un node' : 'Modifier ' + Store.label(n), [
      { key: 'name', label: 'Nom dans l\'appli', value: src.name || '', placeholder: 'ex. Node jardin face', autofocus: true },
      { key: 'ip', label: 'Adresse IP fixe', type: 'ip', value: src.ip || '', placeholder: 'ex. 2.0.0.11', hint: 'l\'adresse à laquelle l\'appli joint le node' },
      { key: 'model', label: 'Modèle', type: 'select', value: src.model || 4, options: [[1, 'Node 1 univers'], [2, 'Node 2 univers'], [4, 'Node 4 univers']] },
      { key: 'tags', label: 'Production / étiquettes', value: (src.tags || []).join(', '), placeholder: 'ex. Tournée 2026, Salle A' },
      { key: 'user', label: 'Utilisateur de la page web', value: (src.login && src.login.user) || '', placeholder: Store.settings().defaultUser || 'admin' },
      { key: 'pass', label: 'Mot de passe de la page web', type: 'password', value: (src.login && src.login.pass) || '', placeholder: 'si la page de login est activée' },
      { key: 'serial', label: 'N° de série', value: src.serial || '', hint: 'rempli tout seul à la première lecture USB' },
      { key: 'notes', label: 'Notes', type: 'textarea', rows: 2, value: src.notes || '' }
    ], isNew ? 'Ajouter' : 'Enregistrer', {
      validate: v => {
        if (v.ip && !U.isIp(v.ip)) return 'Adresse IP invalide';
        const other = v.ip && Store.nodes().find(x => x.ip === v.ip && x !== n);
        if (other) return 'Adresse déjà utilisée par ' + Store.label(other);
        return '';
      }
    });
    if (!vals) return null;
    const tags = vals.tags.split(',').map(t => t.trim()).filter(Boolean);
    const login = { user: vals.user.trim(), pass: vals.pass };
    if (isNew) {
      const plan = Object.assign({ ports: [] }, (preset && preset.plan) || {});
      if (vals.ip && !preset) { plan.ipMode = 'static'; plan.ip = vals.ip; }
      const node = Store.addNode({ name: vals.name.trim(), ip: vals.ip.trim(), model: Number(vals.model), tags, login, serial: vals.serial.trim(), notes: vals.notes, plan, mac: (preset && preset.mac) || '' });
      Store.log(node, 'Ajouté au parc', true);
      return node;
    }
    Object.assign(n, { name: vals.name.trim(), ip: vals.ip.trim(), model: Number(vals.model), tags, login, serial: vals.serial.trim(), notes: vals.notes });
    Store.save();
    return n;
  };

  C.allTags = () => Array.from(new Set([].concat(...Store.nodes().map(n => n.tags || [])))).sort();

  /** Choisit des nodes (cases à cocher) */
  C.pickNodes = function (title, preselect, filter) {
    const nodes = Store.nodes().filter(filter || (() => true));
    const sel = new Set(preselect || []);
    const body = '<div class="picklist">' + nodes.map(n => '<label class="pick"><input type="checkbox" value="' + n.id + '"' + (sel.has(n.id) ? ' checked' : '') + '><span>' + C.statusDot(n) + esc(Store.label(n)) + ' <small>' + esc(n.ip || '') + '</small></span></label>').join('') + '</div>' +
      '<div class="row-btns"><button type="button" class="btn sm" data-pk="all">Tous</button><button type="button" class="btn sm" data-pk="none">Aucun</button><button type="button" class="btn sm" data-pk="on">En ligne</button></div>';
    let result = null;
    return UI.dialog({
      title, body, wide: true,
      buttons: [{ label: 'Annuler', value: null }, { label: 'Valider', value: 'ok', kind: 'primary' }],
      onOpen: el => el.addEventListener('click', e => {
        const b = e.target.closest('[data-pk]');
        if (!b) return;
        el.querySelectorAll('.picklist input').forEach(x => {
          const n = Store.node(x.value);
          x.checked = b.dataset.pk === 'all' || (b.dataset.pk === 'on' && n && RT.isOnline(n));
        });
      }),
      onAction: (v, el) => { if (v === 'ok') result = Array.from(el.querySelectorAll('.picklist input:checked')).map(x => x.value); return true; }
    }).then(() => result);
  };
})(typeof self !== 'undefined' ? self : this);
