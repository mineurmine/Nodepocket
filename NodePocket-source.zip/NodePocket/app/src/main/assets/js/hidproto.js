/*
 * Node Pocket — protocole USB HID des produits Electroconcept (celui de dmx-tools)
 *
 * Relevé dans le code de https://dmx-tools.electroconcept.fr/dmx_tools/ (script.js, web_interface.js) :
 *  - périphérique HID VID 0x1FC9 / PID 0x0052, rapports de 64 octets sans identifiant (reportId 0)
 *  - une requête = un rapport de sortie ; la réponse = le rapport d'entrée suivant (pas de numéro de requête)
 *  - octet 0 = commande, réponse : octet 0 = écho de la commande
 *
 *   1  nombre de paramètres          -> [1] = nombre
 *   2  nombre de groupes (onglets)   -> [1] = nombre
 *   3  nom du groupe n               -> [1] = n, [2..] = nom (NUL)
 *   4  valeur numérique / IP / liste -> [2..5] = valeur 32 bits LE (IP : 4 octets dans l'ordre)
 *   5  définition du paramètre n     -> [1] = n, [2] = groupe, [3] = type, [4..5] = min, [6..7] = max, [8..] = nom
 *   6  écrire nombre / IP / liste    <- [1] = n, [2..5] = valeur
 *   7  nom du produit                -> [1..] = nom (NUL)
 *   9  valeur texte                  -> [2] = longueur max, [3..] = texte (NUL)
 *  10  écrire texte                  <- [1] = n, [2] = 0, [3..] = texte UTF-8 (61 octets max)
 *  12  fichier de l'interface web    <- [1..50] = nom ; -> [1] = trouvé, [22..41] = type MIME, [42..45] = taille, [46..47] = nb de blocs
 *  13  bloc de fichier               <- [1..2] = n° de bloc ; -> [3] = longueur, [4..] = données (60 max)
 *
 * Types : 0 nombre, 1 texte, 2 adresse IP, 3 (non géré par dmx-tools), 4 liste (options séparées par \r dans le nom), 5 texte en lecture seule
 */
(function (root) {
  'use strict';
  const U = root.U || (typeof require !== 'undefined' ? require('./util.js') : null);

  const H = {};
  H.VID = 0x1FC9;
  H.PID = 0x0052;
  H.LEN = 64;
  H.CMD = { MAX_PARAM: 1, MAX_GROUP: 2, GROUP_NAME: 3, GET_VAL: 4, PARAM_DEF: 5, SET_VAL: 6, NAME: 7, GET_STR: 9, SET_STR: 10, WEB_FILE: 12, WEB_CHUNK: 13 };
  H.TYPE = { NUMBER: 0, STRING: 1, IP: 2, OTHER: 3, LIST: 4, RO_STRING: 5 };
  H.TYPE_NAMES = ['nombre', 'texte', 'adresse IP', 'inconnu', 'liste', 'lecture seule'];

  H.req = function (cmd, idx, payloadAt2) {
    const b = new Uint8Array(H.LEN);
    b[0] = cmd;
    if (idx != null) b[1] = idx & 255;
    if (payloadAt2) b.set(payloadAt2.subarray ? payloadAt2.subarray(0, 62) : payloadAt2.slice(0, 62), 2);
    return b;
  };

  /**
   * Ajoute à la réponse les mêmes propriétés que dmx-tools (Name, Type, Val, IP0…), pour que
   * l'interface web embarquée dans le node fonctionne telle quelle dans l'appli.
   */
  H.decorate = function (r) {
    const g = i => r[i] || 0;
    r.Name = U.cstr(r, 1, 64);
    r.Type = g(3);
    r.MaxParam = g(1);
    r.Param = g(1);
    r.IP0 = g(2); r.IP1 = g(3); r.IP2 = g(4); r.IP3 = g(5);
    r.Val = g(2) + (g(3) << 8) + (g(4) << 16) + (g(5) << 24);
    r.ParamGroupe = g(2);
    r.Min = g(4) + (g(5) << 8);
    r.Max = g(6) + (g(7) << 8);
    r.ParamName = U.cstr(r, 8, 64);
    r.Serial1 = g(1) + (g(2) << 8) + (g(3) << 16) + (g(4) << 24);
    r.Serial2 = g(5) + (g(6) << 8) + (g(7) << 16) + (g(8) << 24);
    r.Groupe = g(1);
    r.GroupeName = U.cstr(r, 2, 64);
    r.MaxLenght = g(2);
    r.ParameStringName = U.cstr(r, 3, 64);
    return r;
  };

  /** Sépare le nom d'une liste : "DMX Protocol\rArt-Net\rsACN\r" -> { label, options } */
  H.splitList = function (name) {
    const parts = String(name || '').split('\r');
    const label = parts[0];
    const options = parts.slice(1);
    if (options.length && options[options.length - 1] === '') options.pop();
    return { label, options };
  };

  function encodeValue(p, v) {
    if (p.type === H.TYPE.STRING) {
      const bytes = U.utf8(String(v == null ? '' : v));
      if (bytes.length > 61) throw new Error('« ' + p.label + ' » : 61 caractères maximum');
      const b = new Uint8Array(H.LEN);
      b[0] = H.CMD.SET_STR; b[1] = p.index; b[2] = 0;
      b.set(bytes, 3);
      return b;
    }
    const b = new Uint8Array(H.LEN);
    b[0] = H.CMD.SET_VAL; b[1] = p.index;
    if (p.type === H.TYPE.IP) {
      if (!U.isIp(v)) throw new Error('« ' + p.label + ' » : adresse IP invalide');
      b.set(U.ipBytes(v), 2);
    } else if (p.type === H.TYPE.LIST) {
      const i = Number(v);
      if (!(i >= 0 && i < Math.max(1, p.options.length))) throw new Error('« ' + p.label + ' » : choix invalide');
      b[2] = i;
    } else {
      let n = Math.round(Number(v));
      if (!isFinite(n)) throw new Error('« ' + p.label + ' » : nombre invalide');
      n = n >>> 0;
      b[2] = n & 255; b[3] = (n >>> 8) & 255; b[4] = (n >>> 16) & 255; b[5] = (n >>> 24) & 255;
    }
    return b;
  }
  H.encodeValue = encodeValue;

  /** Vérifie une valeur avant envoi ; renvoie un message d'erreur ou '' */
  H.validate = function (p, v) {
    if (p.type === H.TYPE.NUMBER) {
      const n = Number(v);
      if (v === '' || !isFinite(n)) return 'nombre attendu';
      if (p.max > p.min && (n < p.min || n > p.max)) return 'entre ' + p.min + ' et ' + p.max;
    } else if (p.type === H.TYPE.IP) {
      if (!U.isIp(v)) return 'adresse IP attendue (ex. 2.0.0.10)';
    } else if (p.type === H.TYPE.STRING) {
      const n = U.utf8(String(v || '')).length;
      const max = Math.min(61, p.maxLen || 61);
      if (n > max) return max + ' caractères maximum';
    } else if (p.type === H.TYPE.LIST) {
      const i = Number(v);
      if (!(i >= 0 && i < p.options.length)) return 'choix invalide';
    }
    return '';
  };

  H.isGzip = b => b && b.length >= 18 && b[0] === 0x1f && b[1] === 0x8b && b[2] === 0x08;

  /**
   * Client : transport.xfer(Uint8Array(64)) -> Promise<Uint8Array(64)>
   * (côté Android : écriture sur l'endpoint OUT puis lecture du rapport d'entrée suivant)
   */
  class Client {
    constructor(transport, opts) {
      this.t = transport;
      this.opts = Object.assign({ retries: 1, log: null }, opts || {});
      this.queue = Promise.resolve();
      this.stats = { sent: 0, timeouts: 0 };
    }

    /** Exécute fn seul sur le lien USB (les autres requêtes attendent) */
    exclusive(fn) {
      const p = this.queue.then(fn, fn);
      this.queue = p.catch(() => {});
      return p;
    }

    /** Une requête à la fois, réponse vérifiée (écho de la commande) */
    xfer(req) {
      return this.exclusive(() => this._x(req));
    }

    /** Requête brute (pour l'interface web du node) : pas de vérification, mais toujours dans la file */
    raw(req) {
      return this.exclusive(() => this.t.xfer(req).then(r => {
        const resp = new Uint8Array(H.LEN);
        resp.set(r.subarray ? r.subarray(0, H.LEN) : r.slice(0, H.LEN));
        return H.decorate(resp);
      }));
    }

    async _x(req) {
      let lastErr = null;
      for (let attempt = 0; attempt <= this.opts.retries; attempt++) {
        try {
          this.stats.sent++;
          const r = await this.t.xfer(req);
          if (!r || !r.length) throw new Error('réponse vide');
          const resp = r.length >= H.LEN ? r : (() => { const x = new Uint8Array(H.LEN); x.set(r); return x; })();
          if (this.opts.log) this.opts.log(req, resp);
          if (resp[0] !== req[0] && !(req[0] === H.CMD.WEB_FILE && resp[0] === 0)) {
            lastErr = new Error('réponse inattendue (commande ' + resp[0] + ' au lieu de ' + req[0] + ')');
            if (this.t.flush) await this.t.flush();
            continue;
          }
          return H.decorate(resp);
        } catch (e) {
          lastErr = e;
          if (/timeout|délai/i.test(e && e.message)) this.stats.timeouts++;
          if (/fermé|débranché|absent/i.test(e && e.message)) break;
          if (this.t.flush) { try { await this.t.flush(); } catch (_) { /* rien */ } }
        }
      }
      throw lastErr || new Error('échec USB');
    }

    async productName() {
      return (await this.xfer(H.req(H.CMD.NAME))).Name;
    }

    /** Lit toute la table : nom, groupes, paramètres et valeurs */
    async readAll(progress) {
      const name = await this.productName();
      const nGroups = (await this.xfer(H.req(H.CMD.MAX_GROUP))).Groupe;
      const groups = [];
      for (let g = 0; g < nGroups; g++) {
        const r = await this.xfer(H.req(H.CMD.GROUP_NAME, g));
        groups.push({ index: g, name: r.GroupeName });
      }
      const nParams = (await this.xfer(H.req(H.CMD.MAX_PARAM))).MaxParam;
      const params = [];
      for (let i = 0; i < nParams; i++) {
        const d = await this.xfer(H.req(H.CMD.PARAM_DEF, i));
        const p = {
          index: i,
          group: d.ParamGroupe,
          type: d.Type,
          min: d.Min,
          max: d.Max,
          rawName: d.ParamName,
          label: d.ParamName,
          options: [],
          value: null
        };
        if (p.type === H.TYPE.LIST) {
          const sl = H.splitList(p.rawName);
          p.label = sl.label;
          p.options = sl.options;
        }
        p.readonly = p.type === H.TYPE.RO_STRING || p.type === H.TYPE.OTHER;
        await this.readValue(p);
        params.push(p);
        if (progress) progress((i + 1) / Math.max(1, nParams), p);
      }
      return { name, groups, params, at: Date.now() };
    }

    async readValue(p) {
      if (p.type === H.TYPE.STRING || p.type === H.TYPE.RO_STRING) {
        const r = await this.xfer(H.req(H.CMD.GET_STR, p.index));
        p.maxLen = r.MaxLenght;
        p.value = r.ParameStringName;
      } else {
        const r = await this.xfer(H.req(H.CMD.GET_VAL, p.index));
        if (p.type === H.TYPE.IP) p.value = [r.IP0, r.IP1, r.IP2, r.IP3].join('.');
        else if (p.type === H.TYPE.LIST) p.value = r[2];
        else p.value = r.Val >>> 0;
      }
      return p.value;
    }

    async writeValue(p, v) {
      if (p.readonly) throw new Error('« ' + p.label + ' » est en lecture seule');
      await this.xfer(encodeValue(p, v));
    }

    /**
     * Écrit une liste de changements [{param, value}] puis relit chaque paramètre pour vérifier.
     * Renvoie [{ index, label, wanted, got, ok }]
     */
    async apply(changes, progress) {
      const report = [];
      let k = 0;
      for (const c of changes) {
        await this.writeValue(c.param, c.value);
        if (progress) progress(++k / (changes.length * 2), c.param);
      }
      for (const c of changes) {
        const got = await this.readValue(c.param);
        const ok = c.param.type === H.TYPE.STRING ? String(got) === String(c.value) : U.same(got, c.value);
        report.push({ index: c.param.index, label: c.param.label, wanted: c.value, got, ok });
        if (progress) progress(++k / (changes.length * 2), c.param);
      }
      return report;
    }

    /** Comme le bouton Appliquer de dmx-tools : tous les paramètres modifiables, dans l'ordre */
    async applyAllLikeDmxTools(params, progress) {
      const list = params.filter(p => !p.readonly && p.type !== H.TYPE.OTHER);
      let k = 0;
      for (const p of list) {
        await this.xfer(encodeValue(p, p.value));
        if (progress) progress(++k / list.length, p);
      }
    }

    /** L'interface web embarquée (firmware 2026) est-elle disponible ? */
    async hasWebInterface() {
      try {
        const r = await this.xfer(H.fileReq('index.html'));
        return r[0] === H.CMD.WEB_FILE && r[1] === 1;
      } catch (e) {
        return false;
      }
    }

    /** Télécharge un fichier de l'interface web du node (décompressé si gzip), sans être interrompu */
    getFile(name, progress, binary) {
      return this.exclusive(() => this._getFile(name, progress, binary));
    }

    async _getFile(name, progress, binary) {
      const meta = await this._x(H.fileReq(name));
      if (meta[0] !== H.CMD.WEB_FILE || meta[1] !== 1) return null;
      const info = {
        name: U.cstr(meta, 2, 22) || name,
        mime: U.cstr(meta, 22, 42),
        size: U.u32le(meta, 42),
        chunks: U.u16le(meta, 46)
      };
      const buf = new Uint8Array(info.size);
      let off = 0;
      for (let i = 0; i < info.chunks; i++) {
        const q = new Uint8Array(H.LEN);
        q[0] = H.CMD.WEB_CHUNK; q[1] = i & 255; q[2] = (i >> 8) & 255;
        const r = await this._x(q);
        const len = r[3];
        if (!len) throw new Error('bloc ' + i + ' vide');
        if (off + len > buf.length) throw new Error('fichier plus long qu\'annoncé');
        buf.set(r.subarray(4, 4 + len), off);
        off += len;
        if (progress) progress((i + 1) / info.chunks);
      }
      let data = off === buf.length ? buf : buf.subarray(0, off);
      if (H.isGzip(data) && H.gunzip) {
        try { data = await H.gunzip(data); } catch (e) { if (!binary) throw new Error('décompression impossible'); }
      }
      info.data = data;
      return info;
    }
  }
  H.Client = Client;

  H.fileReq = function (name) {
    const b = new Uint8Array(H.LEN);
    b[0] = H.CMD.WEB_FILE;
    b.set(U.utf8(String(name)).subarray(0, 50), 1);
    return b;
  };

  /** Décompression gzip (navigateur : DecompressionStream ; Node : zlib) */
  H.gunzip = async function (u8) {
    if (typeof DecompressionStream !== 'undefined') {
      const ds = new DecompressionStream('gzip');
      const stream = new Blob([u8]).stream().pipeThrough(ds);
      return new Uint8Array(await new Response(stream).arrayBuffer());
    }
    if (typeof require !== 'undefined') return new Uint8Array(require('zlib').gunzipSync(Buffer.from(u8)));
    throw new Error('gzip non pris en charge');
  };

  /** Table lue -> texte lisible (journal / export) */
  H.describe = function (table) {
    const lines = ['Produit : ' + table.name];
    table.groups.forEach(g => {
      lines.push('[' + g.name + ']');
      table.params.filter(p => p.group === g.index).forEach(p => {
        let v = p.value;
        if (p.type === H.TYPE.LIST) v = (p.options[p.value] || '?') + ' (' + p.value + ')';
        lines.push('  #' + p.index + ' ' + p.label + ' = ' + v + '   <' + H.TYPE_NAMES[p.type] + (p.type === 0 ? ' ' + p.min + '…' + p.max : '') + (p.type === 4 ? ' : ' + p.options.join(' | ') : '') + '>');
      });
    });
    return lines.join('\n');
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = H;
  else root.ECHid = H;
})(typeof self !== 'undefined' ? self : this);
