/* Node Pocket — application : navigation, affichage, boutons de la console portable */
(function (root) {
  'use strict';
  const esc = U.esc;

  const ICON = {
    parc: '<path d="M4 6h16v5H4zM4 13h16v5H4z" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="8" cy="8.5" r="1.2" fill="currentColor"/><circle cx="8" cy="15.5" r="1.2" fill="currentColor"/>',
    univers: '<path d="M4 5h4v4H4zM10 5h4v4h-4zM16 5h4v4h-4zM4 11h4v4H4zM10 11h4v4h-4zM16 11h4v4h-4zM4 17h4v3H4zM10 17h4v3h-4z" fill="currentColor"/>',
    lot: '<path d="M5 6h14M5 12h14M5 18h9" stroke="currentColor" stroke-width="2" fill="none"/><path d="M17 15l3 3-3 3" stroke="currentColor" stroke-width="2" fill="none"/>',
    firmware: '<path d="M12 3v11m0 0l-4-4m4 4l4-4M5 17v3h14v-3" stroke="currentColor" stroke-width="2" fill="none"/>',
    usb: '<path d="M12 3v14M12 3l-2.5 3h5zM12 12l-4-2.5V7M12 14l4-2.5V9.5" stroke="currentColor" stroke-width="2" fill="none"/><circle cx="12" cy="19" r="2" fill="currentColor"/>',
    prods: '<path d="M5 4h11l3 3v13H5z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M8 4v5h7V4M8 14h8M8 17h6" stroke="currentColor" stroke-width="2" fill="none"/>',
    moniteur: '<path d="M3 17l4-6 4 3 4-8 6 11" stroke="currentColor" stroke-width="2" fill="none"/>',
    reglages: '<circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1" stroke="currentColor" stroke-width="2"/>'
  };
  const NAV = [
    ['parc', 'Parc'], ['univers', 'Univers'], ['lot', 'Lot'], ['firmware', 'Firmware'],
    ['usb', 'USB'], ['prods', 'Sauvegardes'], ['moniteur', 'Moniteur'], ['reglages', 'Réglages']
  ];

  const App = { page: 'parc', params: {}, stack: [], Pages: {}, sel: new Set(), lastRender: 0 };
  root.App = App;
  const Pages = App.Pages;
  App.icon = (k, cls) => '<svg class="ic ' + (cls || '') + '" viewBox="0 0 24 24" aria-hidden="true">' + (ICON[k] || '') + '</svg>';

  // ------------------------------------------------------------ navigation
  App.go = function (page, params, opts) {
    opts = opts || {};
    if (!opts.replace && (page !== App.page || JSON.stringify(params || {}) !== JSON.stringify(App.params))) {
      App.stack.push({ page: App.page, params: App.params, scroll: App.scrollY() });
      if (App.stack.length > 30) App.stack.shift();
    }
    if (Pages[App.page] && Pages[App.page].leave) Pages[App.page].leave();
    App.page = page;
    App.params = params || {};
    if (Pages[page] && Pages[page].enter) { try { Pages[page].enter(App.params); } catch (e) { console.error(e); } }
    App.render(true);
  };
  App.back = function () {
    if (UI.closeTop()) return true;
    if (Bridge.demo && Bridge.pageVisible && Bridge.pageVisible()) { Bridge.pageShow(Bridge.pageVisible(), false); return true; }
    if (root.UsbGui && UsbGui.visible && UsbGui.frame) { UsbGui.frame.show(false); return true; }
    const cur = Pages[App.page];
    if (cur && cur.back && cur.back()) return true;
    const prev = App.stack.pop();
    if (!prev) {
      if (App.page !== 'parc') { App.go('parc', {}, { replace: true }); return true; }
      return false;
    }
    if (Pages[App.page] && Pages[App.page].leave) Pages[App.page].leave();
    App.page = prev.page;
    App.params = prev.params;
    if (Pages[App.page] && Pages[App.page].enter) { try { Pages[App.page].enter(App.params); } catch (e) { console.error(e); } }
    App.render(true);
    const c = document.querySelector('.content');
    if (c) c.scrollTop = prev.scroll || 0;
    return true;
  };
  App.scrollY = () => { const c = document.querySelector('.content'); return c ? c.scrollTop : 0; };

  // ------------------------------------------------------------ affichage
  function statusChips() {
    const nodes = Store.nodes();
    const on = nodes.filter(n => RT.isOnline(n)).length;
    let usb = '';
    if (USB.state === 'ready' && USB.info) {
      const n = USB.nodeId && Store.node(USB.nodeId);
      usb = '<button type="button" class="chip on" data-act="nav" data-arg="usb">' + App.icon('usb', 'sm') + esc(n ? Store.label(n) : (USB.info.product || 'Node USB')) + '</button>';
    } else if (USB.state === 'reading' || USB.state === 'opening' || USB.state === 'perm') {
      usb = '<button type="button" class="chip busy" data-act="nav" data-arg="usb">' + App.icon('usb', 'sm') + 'USB…</button>';
    } else if (USB.dfuDev) {
      usb = '<button type="button" class="chip warn" data-act="nav" data-arg="firmware">' + App.icon('usb', 'sm') + 'DFU</button>';
    } else if (USB.state === 'error') {
      usb = '<button type="button" class="chip err" data-act="nav" data-arg="usb">' + App.icon('usb', 'sm') + 'USB</button>';
    }
    const net = Disco.status === 'error' ? '<span class="chip err" title="' + esc(Disco.detail) + '">Réseau</span>'
      : '<span class="chip ' + (on ? 'on' : '') + '" title="' + esc(Disco.detail) + '">' + UI.dot(on ? 'ok' : '') + on + ' / ' + nodes.length + ' en ligne</span>';
    return net + usb;
  }

  App.shell = function (content) {
    const nav = NAV.map(([k, l]) => '<button type="button" class="nv' + (App.page === k || (k === 'parc' && App.page === 'fiche') ? ' on' : '') + '" data-act="nav" data-arg="' + k + '">' + App.icon(k) + '<span>' + l + '</span>' +
      (k === 'firmware' && App.fwOld() ? '<b class="cnt">' + App.fwOld() + '</b>' : '') +
      (k === 'univers' && App.planErrors() ? '<b class="cnt">!</b>' : '') + '</button>').join('');
    return '<nav class="rail">' + nav + '</nav><div class="main"><header class="top"><div class="brand">Node<b>Pocket</b>' + (Bridge.demo ? '<span class="demo">démo</span>' : '') + '</div><div class="chips">' + statusChips() + '</div></header>' +
      '<div class="content" id="content">' + content + '</div></div>';
  };

  App.render = function (resetScroll) {
    const P = Pages[App.page] || Pages.parc;
    const appEl = document.getElementById('app');
    const scroll = resetScroll ? 0 : App.scrollY();
    const active = document.activeElement;
    const fid = active && (active.dataset.fid || active.id);
    let html;
    try { html = P.render(App.params); } catch (e) { console.error(e); html = '<div class="empty err">Erreur d\'affichage : ' + esc(e.message) + '</div>'; }
    appEl.innerHTML = App.shell(html);
    appEl.className = 'pg-' + App.page;
    const c = document.querySelector('.content');
    if (c) c.scrollTop = scroll;
    if (P.mount) { try { P.mount(c, App.params); } catch (e) { console.error(e); } }
    if (fid) {
      const el = appEl.querySelector('[data-fid="' + CSS.escape(fid) + '"]') || document.getElementById(fid);
      if (el) UI.focus(el, true); else UI.focusFirst();
    } else if (UI.padMode && !UI.isOpen()) UI.focusFirst();
    App.lastRender = Date.now();
  };

  /** Rafraîchit la page si elle suit l'état en direct (pas pendant une saisie) */
  let liveTimer = null;
  App.live = function () {
    if (liveTimer) return;
    liveTimer = setTimeout(() => {
      liveTimer = null;
      const P = Pages[App.page];
      if (!P || !P.live) { App.refreshChips(); return; }
      // pas de rafraîchissement pendant une saisie (frappe récente dans un champ)
      const a = document.activeElement;
      const editing = a && /^(INPUT|TEXTAREA)$/.test(a.tagName) && a.closest('#app') && (Date.now() - (App.lastTyping || 0) < 5000 || (a.value !== a.defaultValue && a.type !== 'search'));
      if (editing) { App.refreshChips(); App.live(); return; }
      App.render();
    }, 350);
  };
  App.refreshChips = function () {
    const c = document.querySelector('.top .chips');
    if (c) c.innerHTML = statusChips();
  };

  App.fwOld = function () {
    const st = Model.firmwareStatus(Store.nodes(), Store.state.fwPinned);
    return Object.values(st.byNode).filter(x => x.status === 'old').length;
  };
  App.planErrors = function () {
    const entries = Store.nodes().map(n => ({ id: n.id, name: Store.label(n), ip: n.ip, canon: Store.wanted(n), ports: Store.ports(n) }));
    return Model.universePlan(entries, {}).issues.filter(i => i.level === 'err').length;
  };

  // ------------------------------------------------------------ actions (clics)
  App.acts = {
    nav: (el) => { App.stack = []; App.go(el.dataset.arg, {}, { replace: true }); },
    back: () => App.back(),
    node: (el) => App.go('fiche', { id: el.dataset.arg })
  };
  document.addEventListener('click', e => {
    const el = e.target.closest('[data-act]');
    if (!el || el.disabled) return;
    const name = el.dataset.act;
    const P = Pages[App.page];
    const fn = (P && P.acts && P.acts[name]) || App.acts[name];
    if (fn) {
      e.preventDefault();
      Promise.resolve(fn(el, e)).catch(err => { console.error(err); UI.toast(err.message || String(err), 'err'); });
    }
  });
  // boutons segmentés : la page reçoit un événement "seg"
  document.addEventListener('click', e => {
    const b = e.target.closest('.seg-b');
    if (!b || b.disabled) return;
    const seg = b.closest('.seg');
    seg.querySelectorAll('.seg-b').forEach(x => x.classList.toggle('on', x === b));
    seg.dispatchEvent(new CustomEvent('segchange', { bubbles: true, detail: { name: seg.dataset.seg, value: b.dataset.v } }));
  });
  document.addEventListener('input', () => { App.lastTyping = Date.now(); }, true);
  document.addEventListener('keydown', e => { if (/^(INPUT|TEXTAREA)$/.test(e.target.tagName)) App.lastTyping = Date.now(); }, true);
  document.addEventListener('focusin', e => {
    const t = e.target;
    Bridge.textInput(/^(INPUT|TEXTAREA)$/.test(t.tagName) && !/^(checkbox|radio|button)$/.test(t.type));
  });
  document.addEventListener('focusout', () => Bridge.textInput(false));

  // ------------------------------------------------------------ boutons physiques
  const KEY = { UP: 19, DOWN: 20, LEFT: 21, RIGHT: 22, CENTER: 23, A: 96, B: 97, X: 99, Y: 100, L1: 102, R1: 103, L2: 104, R2: 105, START: 108, SELECT: 109, ENTER: 66 };
  App.KEY = KEY;
  App.setPadMode = function (on) {
    if (UI.padMode === on) return;
    UI.padMode = on;
    document.body.classList.toggle('pad', on);
    if (on) UI.focusFirst();
  };
  function navStep(d) {
    const keys = NAV.map(n => n[0]);
    const cur = App.page === 'fiche' ? 'parc' : App.page;
    const i = keys.indexOf(cur);
    App.stack = [];
    App.go(keys[(i + d + keys.length) % keys.length], {}, { replace: true });
  }
  App.onKey = function (code, name, down, rep) {
    if (!down) return;
    App.setPadMode(true);
    const s = Store.settings();
    if (s.swapAB) { if (code === KEY.A) code = KEY.B; else if (code === KEY.B) code = KEY.A; }
    if (Bridge.demo && Bridge.pageVisible && Bridge.pageVisible()) { if (code === KEY.B) App.back(); return; }
    if (root.UsbGui && UsbGui.visible) { if (code === KEY.B) App.back(); return; }
    const P = Pages[App.page];
    const el = document.activeElement;
    const adjustable = el && ((el.tagName === 'INPUT' && el.type === 'number') || el.tagName === 'SELECT' || el.classList.contains('seg-b'));
    switch (code) {
      case KEY.UP: UI.move('up'); break;
      case KEY.DOWN: UI.move('down'); break;
      case KEY.LEFT: if (!(adjustable && UI.adjust(-1))) UI.move('left'); break;
      case KEY.RIGHT: if (!(adjustable && UI.adjust(1))) UI.move('right'); break;
      case KEY.A: case KEY.CENTER: case KEY.ENTER: if (!rep) UI.activate(); break;
      case KEY.B: if (!rep) App.back(); break;
      case KEY.X: if (!rep && P && P.padX) P.padX(el); else if (!rep) UI.toast('X : pas d\'action ici'); break;
      case KEY.Y: if (!rep && P && P.padY) P.padY(el); break;
      case KEY.START: if (!rep && P && P.padStart) P.padStart(el); break;
      case KEY.SELECT: if (!rep) App.help(); break;
      case KEY.L1: if (!rep && !UI.isOpen()) { if (P && P.padTab) P.padTab(-1); else navStep(-1); } break;
      case KEY.R1: if (!rep && !UI.isOpen()) { if (P && P.padTab) P.padTab(1); else navStep(1); } break;
      case KEY.L2: { const c = UI.isOpen() ? UI.top().el.querySelector('.dlg-b') : document.querySelector('.content'); if (c) c.scrollBy({ top: -c.clientHeight * 0.7, behavior: 'smooth' }); break; }
      case KEY.R2: { const c = UI.isOpen() ? UI.top().el.querySelector('.dlg-b') : document.querySelector('.content'); if (c) c.scrollBy({ top: c.clientHeight * 0.7, behavior: 'smooth' }); break; }
      default: break;
    }
  };
  App.help = function () {
    const P = Pages[App.page];
    const extra = (P && P.padHelp) || {};
    const rows = [
      ['Croix', 'se déplacer ; ← → change un nombre ou un choix'],
      ['A', 'valider / ouvrir'], ['B', 'retour / fermer'],
      ['X', extra.X || 'menu de l\'élément'], ['Y', extra.Y || 'lire / actualiser'],
      ['Start', extra.START || 'action principale'], ['L1 / R1', extra.L1 || 'page précédente / suivante'],
      ['L2 / R2', 'faire défiler'], ['Select', 'cette aide']
    ];
    UI.alert('Boutons de la console', '<table class="keys">' + rows.map(r => '<tr><th>' + esc(r[0]) + '</th><td>' + esc(r[1]) + '</td></tr>').join('') + '</table>' +
      (Store.settings().swapAB ? '<p class="muted">A et B sont inversés (Réglages).</p>' : ''));
  };

  // ------------------------------------------------------------ démarrage
  App.applyDisplay = function () {
    const s = Store.settings();
    document.documentElement.style.fontSize = (16 * (s.zoom || 100) / 100) + 'px';
    Bridge.keepScreenOn(s.keepScreenOn);
    Bridge.immersive(s.immersive);
    Bridge.orientation(s.orientation);
  };

  App.boot = function () {
    Store.load();
    App.applyDisplay();
    Bridge.on('udp', (u8, ip, port) => Disco.onUdp(u8, ip, port));
    Bridge.on('netStatus', (st, d) => {
      if (st === 'ready') { Disco.status = 'ready'; Disco.detail = d; }
      else if (st === 'error') { Disco.status = 'error'; Disco.detail = d; UI.toast(d, 'err'); }
      else if (st === 'sacn-error') UI.toast(d, 'err');
      App.refreshChips();
    });
    Bridge.on('usb', (t, d) => { USB.onEvent(t, d); });
    Bridge.on('page', (sid, t, d) => { const p = RemotePage.all[sid]; if (p) p.onEvent(t, d); });
    Bridge.on('key', App.onKey);
    Bridge.on('axes', a => {
      // joystick gauche = croix
      const now = Date.now();
      if (now - (App._ax || 0) < 180) return;
      const x = a.X || a.HAT_X || 0, y = a.Y || a.HAT_Y || 0;
      if (Math.abs(x) < 0.6 && Math.abs(y) < 0.6) return;
      App._ax = now;
      if (Math.abs(x) > Math.abs(y)) App.onKey(x > 0 ? KEY.RIGHT : KEY.LEFT, '', true, 0);
      else App.onKey(y > 0 ? KEY.DOWN : KEY.UP, '', true, 0);
    });
    Bridge.on('back', () => App.back());
    Bridge.on('flush', () => Store.flush());
    RT.listeners.push(() => App.live());
    if (Bridge.hasGamepad()) App.setPadMode(true);
    window.addEventListener('pointerdown', () => { if (UI.padMode && !Bridge.hasGamepad()) App.setPadMode(false); }, true);
    document.addEventListener('visibilitychange', () => { if (document.hidden) Store.flush(); });
    App.render(true);
    Disco.start();
    Probe.start();
    // node déjà branché au lancement
    setTimeout(() => {
      const s = USB.scan();
      if (s.ec) USB.connect(s.ec);
      if (Bridge.launchUsb()) App.go('usb');
      RT.changed('usb');
    }, 300);
    // première ouverture : aide
    if (!Store.nodes().length && !Store.state.welcomed) {
      Store.state.welcomed = true;
      Store.save();
      setTimeout(() => Pages.parc.welcome && Pages.parc.welcome(), 400);
    }
  };

  document.addEventListener('DOMContentLoaded', () => App.boot());
})(typeof self !== 'undefined' ? self : this);
