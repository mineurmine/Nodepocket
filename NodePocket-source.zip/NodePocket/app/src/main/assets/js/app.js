/* Node Pocket — application : navigation, affichage, boutons de la console portable. Développé par 3DP. */
(function (root) {
  'use strict';
  const esc = U.esc;

  const ICON = {
    parc: '<path d="M4 6h16v5H4zM4 13h16v5H4z" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="8" cy="8.5" r="1.2" fill="currentColor"/><circle cx="8" cy="15.5" r="1.2" fill="currentColor"/>',
    univers: '<path d="M4 5h4v4H4zM10 5h4v4h-4zM16 5h4v4h-4zM4 11h4v4H4zM10 11h4v4h-4zM16 11h4v4h-4zM4 17h4v3H4zM10 17h4v3h-4z" fill="currentColor"/>',
    lot: '<path d="M5 6h14M5 12h14M5 18h9" stroke="currentColor" stroke-width="2" fill="none"/><path d="M17 15l3 3-3 3" stroke="currentColor" stroke-width="2" fill="none"/>',
    firmware: '<path d="M12 3v11m0 0l-4-4m4 4l4-4M5 17v3h14v-3" stroke="currentColor" stroke-width="2" fill="none"/>',
    usb: '<path d="M12 3v14M12 3l-2.5 3h5zM12 12l-4-2.5V7M12 14l4-2.5V9.5" stroke="currentColor" stroke-width="2" fill="none"/><circle cx="12" cy="19" r="2" fill="currentColor"/>',
    prods: '<path d="M5 4h11l3 3v13H5z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M8 4v5h7V4M8 14h8M8 17h6" stroke="currentColor" stroke-width="2" fill="none"/>',
    moniteur: '<path d="M3 17l4-6 4 3 4-8 6 11" stroke="currentColor" stroke-width="2" fill="none"/>',
    reglages: '<circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1" stroke="currentColor" stroke-width="2"/>'
  };
  ICON.accueil = ICON.parc;
  const NAV = [
    ['parc', 'Parc'], ['univers', 'Univers'], ['lot', 'Lot'], ['firmware', 'Firmware'],
    ['usb', 'USB'], ['prods', 'Sauvegardes'], ['moniteur', 'Moniteur'], ['reglages', 'Réglages']
  ];
  // mode simple (techniciens) : la liste des nodes et les réglages de l'appli
  const NAV_SIMPLE = [['accueil', 'Nodes'], ['reglages', 'Réglages']];

  const App = { page: 'parc', params: {}, stack: [], Pages: {}, sel: new Set(), lastRender: 0 };
  root.App = App;
  const Pages = App.Pages;
  App.icon = (k, cls) => '<svg class="ic ' + (cls || '') + '" viewBox="0 0 24 24" aria-hidden="true">' + (ICON[k] || '') + '</svg>';
  App.SIGNATURE = 'Développé par 3DP';
  App.simple = () => !!(Store.state && Store.settings().simple);
  App.home = () => (App.simple() ? 'accueil' : 'parc');
  App.nav = () => (App.simple() ? NAV_SIMPLE : NAV);

  // ------------------------------------------------------------ navigation
  App.go = function (page, params, opts) {
    opts = opts || {};
    if (!opts.replace && (page !== App.page || JSON.stringify(params || {}) !== JSON.stringify(App.params))) {
      App.stack.push({ page: App.page, params: App.params, scroll: App.scrollY() });
      if (App.stack.length > 30) App.stack.shift();
    }
    if (Pages[App.page] && Pages[App.page].leave) Pages[App.page].leave();
    App.page = page;
    App.params = params || {};
    if (Pages[page] && Pages[page].enter) { try { Pages[page].enter(App.params); } catch (e) { console.error(e); } }
    App.render(true);
  };
  App.back = function () {
    if (UI.closeTop()) return true;
    if (Bridge.demo && Bridge.pageVisible && Bridge.pageVisible()) { Bridge.pageShow(Bridge.pageVisible(), false); return true; }
    if (root.UsbGui && UsbGui.visible && UsbGui.frame) { UsbGui.frame.show(false); return true; }
    const cur = Pages[App.page];
    if (cur && cur.back && cur.back()) return true;
    const prev = App.stack.pop();
    if (!prev) {
      if (App.page !== App.home()) { App.go(App.home(), {}, { replace: true }); return true; }
      return false;
    }
    if (Pages[App.page] && Pages[App.page].leave) Pages[App.page].leave();
    App.page = prev.page;
    App.params = prev.params;
    if (Pages[App.page] && Pages[App.page].enter) { try { Pages[App.page].enter(App.params); } catch (e) { console.error(e); } }
    App.render(true);
    const c = document.querySelector('.content');
    if (c) c.scrollTop = prev.scroll || 0;
    return true;
  };
  App.scrollY = () => { const c = document.querySelector('.content'); return c ? c.scrollTop : 0; };

  // ------------------------------------------------------------ affichage
  function statusChips() {
    const nodes = Store.nodes();
    const on = nodes.filter(n => RT.isOnline(n)).length;
    let usb = '';
    if (USB.state === 'ready' && USB.info) {
      const n = USB.nodeId && Store.node(USB.nodeId);
      usb = '<button type="button" class="chip on" data-act="nav" data-arg="usb">' + App.icon('usb', 'sm') + esc(n ? Store.label(n) : (USB.info.product || 'Node USB')) + '</button>';
    } else if (USB.state === 'reading' || USB.state === 'opening' || USB.state === 'perm') {
      usb = '<button type="button" class="chip busy" data-act="nav" data-arg="usb">' + App.icon('usb', 'sm') + 'USB…</button>';
    } else if (USB.dfuDev) {
      usb = '<button type="button" class="chip warn" data-act="nav" data-arg="firmware">' + App.icon('usb', 'sm') + 'DFU</button>';
    } else if (USB.state === 'error') {
      usb = '<button type="button" class="chip err" data-act="nav" data-arg="usb">' + App.icon('usb', 'sm') + 'USB</button>';
    }
    const net = Disco.status === 'error' ? '<span class="chip err" title="' + esc(Disco.detail) + '">Réseau</span>'
      : '<span class="chip ' + (on ? 'on' : '') + '" title="' + esc(Disco.detail) + '">' + UI.dot(on ? 'ok' : '') + on + ' / ' + nodes.length + ' en ligne</span>';
    return net + usb;
  }

  App.shell = function (content) {
    const simple = App.simple();
    const nav = App.nav().map(([k, l]) => '<button type="button" class="nv' + (App.page === k || (k === 'parc' && App.page === 'fiche') || (k === 'accueil' && App.page === 'tech') ? ' on' : '') + '" data-act="nav" data-arg="' + k + '" data-fid="nav_' + k + '">' + App.icon(k) + '<span>' + l + '</span>' +
      (!simple && k === 'firmware' && App.fwOld() ? '<b class="cnt">' + App.fwOld() + '</b>' : '') +
      (!simple && k === 'univers' && App.planErrors() ? '<b class="cnt">!</b>' : '') + '</button>').join('');
    return '<nav class="rail">' + nav + '<div class="sig" title="' + App.SIGNATURE + '">3DP</div></nav><div class="main"><header class="top"><div class="brand">Node<b>Pocket</b>' + (simple ? '<span class="demo smp">simple</span>' : '') + (Bridge.demo ? '<span class="demo">démo</span>' : '') + '</div><div class="chips">' + statusChips() + '</div></header>' +
      '<div class="content" id="content">' + content + '</div></div>';
  };

  // ------------------------------------------------------------ mise à jour sur place
  /*
   * Les rafraîchissements en direct ne reconstruisent plus la page : seuls les textes, voyants
   * et attributs qui changent sont modifiés. Le défilement, le champ en cours de saisie,
   * les blocs dépliés et la sélection restent où ils sont.
   */
  function sameNode(a, b) {
    if (a.nodeType !== b.nodeType) return false;
    if (a.nodeType !== 1) return true;
    if (a.tagName !== b.tagName) return false;
    const ka = a.getAttribute('data-fid') || a.id || '', kb = b.getAttribute('data-fid') || b.id || '';
    if (ka !== kb) return false;
    if (a.tagName === 'INPUT' && (a.getAttribute('type') || '') !== (b.getAttribute('type') || '')) return false;
    return true;
  }
  function syncAttrs(a, b) {
    const keepOpen = a.tagName === 'DETAILS';
    const isActive = a === document.activeElement;
    for (const at of Array.from(a.attributes)) {
      if (b.hasAttribute(at.name)) continue;
      if (keepOpen && at.name === 'open') continue;
      if (isActive && at.name === 'tabindex') continue;
      if (at.name === 'class' && a.classList.contains('kfocus')) { a.className = 'kfocus'; continue; }
      a.removeAttribute(at.name);
    }
    for (const at of Array.from(b.attributes)) {
      if (keepOpen && at.name === 'open') continue;
      let v = at.value;
      if (at.name === 'class' && a.classList.contains('kfocus')) v += ' kfocus';
      if (a.getAttribute(at.name) !== v) a.setAttribute(at.name, v);
    }
  }
  function morphChildren(a, b) {
    const an = Array.from(a.childNodes), bn = Array.from(b.childNodes);
    for (let i = 0; i < bn.length; i++) {
      const x = an[i], y = bn[i];
      if (!x) a.appendChild(y);
      else if (!sameNode(x, y)) a.replaceChild(y, x);
      else morphNode(x, y);
    }
    for (let i = bn.length; i < an.length; i++) if (an[i].parentNode === a) a.removeChild(an[i]);
  }
  function morphNode(a, b) {
    if (a.nodeType !== 1) { if (a.nodeValue !== b.nodeValue) a.nodeValue = b.nodeValue; return; }
    const focused = a === document.activeElement;
    const tag = a.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') {
      const before = tag === 'TEXTAREA' ? a.defaultValue : (a.getAttribute('value') || '');
      syncAttrs(a, b);
      const nv = tag === 'TEXTAREA' ? b.value : (b.getAttribute('value') || '');
      // champ en cours d'édition : on ne touche pas à ce que la personne tape
      if (a.value !== nv && (!focused || a.value === before)) a.value = nv;
      if (a.type === 'checkbox' || a.type === 'radio') { if (!focused) a.checked = b.hasAttribute('checked'); }
      if (tag === 'TEXTAREA' && a.defaultValue !== b.defaultValue) a.defaultValue = b.defaultValue;
      return;
    }
    syncAttrs(a, b);
    if (a.hasAttribute('data-keep')) return; // contenu dessiné par la page elle-même (moniteur)
    if (tag === 'SELECT') {
      const si = Array.from(b.options).findIndex(o => o.hasAttribute('selected'));
      morphChildren(a, b);
      if (!focused) a.selectedIndex = si >= 0 ? si : 0;
      return;
    }
    morphChildren(a, b);
  }
  App.morph = morphChildren;

  App.render = function (resetScroll) {
    const P = Pages[App.page] || Pages[App.home()];
    const appEl = document.getElementById('app');
    const active = document.activeElement;
    const fid = active && active !== document.body && (active.dataset.fid || active.id);
    let html;
    try { html = P.render(App.params); } catch (e) { console.error(e); html = '<div class="empty err">Erreur d\'affichage : ' + esc(e.message) + '</div>'; }
    const shell = App.shell(html);
    const full = resetScroll || App._shown !== App.page || !appEl.querySelector('.content');
    const cls = 'pg-' + App.page + (App.simple() ? ' simple' : '');
    if (!full && shell === App._lastShell) { App.lastRender = Date.now(); return; }
    App._lastShell = shell;
    if (full) {
      appEl.innerHTML = shell;
      appEl.className = cls;
      App._shown = App.page;
      const c = document.querySelector('.content');
      if (c) c.scrollTop = 0;
      if (P.mount) { try { P.mount(c, App.params); } catch (e) { console.error(e); } }
      const el = fid && (appEl.querySelector('[data-fid="' + CSS.escape(fid) + '"]') || document.getElementById(fid));
      if (el && UI.padMode) UI.focus(el, true);
      else if (UI.padMode && !UI.isOpen()) UI.focusFirst();
    } else {
      const tpl = document.createElement('div');
      tpl.innerHTML = shell;
      morphChildren(appEl, tpl);
      if (appEl.className !== cls) appEl.className = cls;
      // l'élément sélectionné a disparu : on reprend son remplaçant, sans faire défiler
      if (active && active !== document.body && !document.contains(active) && fid) {
        const el = appEl.querySelector('[data-fid="' + CSS.escape(fid) + '"]') || document.getElementById(fid);
        if (el) UI.focus(el, true); else if (UI.padMode && !UI.isOpen()) UI.focusFirst();
      } else if (UI.padMode && !UI.isOpen() && (!document.activeElement || document.activeElement === document.body)) UI.focusFirst();
    }
    App.lastRender = Date.now();
  };

  /** Appui long sur un élément (menu) : écouteur posé une fois sur la zone */
  App.longPress = function (zone, sel, fn) {
    let t = null, fired = false, x0 = 0, y0 = 0;
    zone.addEventListener('pointerdown', e => {
      const c = e.target.closest(sel);
      if (!c) return;
      fired = false; x0 = e.clientX; y0 = e.clientY;
      clearTimeout(t);
      t = setTimeout(() => { fired = true; fn(c); }, 550);
    });
    zone.addEventListener('pointermove', e => { if (Math.abs(e.clientX - x0) + Math.abs(e.clientY - y0) > 12) clearTimeout(t); });
    ['pointerup', 'pointercancel'].forEach(ev => zone.addEventListener(ev, () => clearTimeout(t)));
    zone.addEventListener('click', e => { if (fired && e.target.closest(sel)) { e.stopPropagation(); e.preventDefault(); fired = false; } }, true);
  };

  /** Rafraîchit la page si elle suit l'état en direct (pas pendant une saisie) */
  let liveTimer = null;
  App.live = function () {
    if (liveTimer) return;
    liveTimer = setTimeout(() => {
      liveTimer = null;
      const P = Pages[App.page];
      if (!P || !P.live) { App.refreshChips(); return; }
      // pas de rafraîchissement pendant une saisie (frappe récente dans un champ)
      const a = document.activeElement;
      const editing = a && /^(INPUT|TEXTAREA)$/.test(a.tagName) && a.closest('#app') && (Date.now() - (App.lastTyping || 0) < 5000 || (a.value !== a.defaultValue && a.type !== 'search'));
      if (editing) { App.refreshChips(); App.live(); return; }
      App.render();
    }, 350);
  };
  App.refreshChips = function () {
    const c = document.querySelector('.top .chips');
    if (c) c.innerHTML = statusChips();
  };

  App.fwOld = function () {
    const st = Model.firmwareStatus(Store.nodes(), Store.state.fwPinned);
    return Object.values(st.byNode).filter(x => x.status === 'old').length;
  };
  App.planErrors = function () {
    const entries = Store.nodes().map(n => ({ id: n.id, name: Store.label(n), ip: n.ip, canon: Store.wanted(n), ports: Store.ports(n) }));
    return Model.universePlan(entries, {}).issues.filter(i => i.level === 'err').length;
  };

  // ------------------------------------------------------------ actions (clics)
  App.acts = {
    nav: (el) => {
      let to = el.dataset.arg;
      // mode simple : les pages du mode complet ne sont pas proposées
      if (App.simple() && !NAV_SIMPLE.some(x => x[0] === to)) {
        if (to === 'usb' && USB.nodeId) { App.go('tech', { id: USB.nodeId }); return; }
        to = 'accueil';
      }
      App.stack = [];
      App.go(to, {}, { replace: true });
    },
    back: () => App.back(),
    node: (el) => App.go('fiche', { id: el.dataset.arg })
  };
  document.addEventListener('click', e => {
    const el = e.target.closest('[data-act]');
    if (!el || el.disabled) return;
    const name = el.dataset.act;
    const P = Pages[App.page];
    const fn = (P && P.acts && P.acts[name]) || App.acts[name];
    if (fn) {
      e.preventDefault();
      Promise.resolve(fn(el, e)).catch(err => { console.error(err); UI.toast(err.message || String(err), 'err'); });
    }
  });
  // boutons segmentés : la page reçoit un événement "seg"
  document.addEventListener('click', e => {
    const b = e.target.closest('.seg-b');
    if (!b || b.disabled) return;
    const seg = b.closest('.seg');
    seg.querySelectorAll('.seg-b').forEach(x => x.classList.toggle('on', x === b));
    seg.dispatchEvent(new CustomEvent('segchange', { bubbles: true, detail: { name: seg.dataset.seg, value: b.dataset.v } }));
  });
  document.addEventListener('input', () => { App.lastTyping = Date.now(); }, true);
  document.addEventListener('keydown', e => { if (/^(INPUT|TEXTAREA)$/.test(e.target.tagName)) App.lastTyping = Date.now(); }, true);
  document.addEventListener('focusin', e => {
    const t = e.target;
    Bridge.textInput(/^(INPUT|TEXTAREA)$/.test(t.tagName) && !/^(checkbox|radio|button)$/.test(t.type));
  });
  document.addEventListener('focusout', () => Bridge.textInput(false));

  // ------------------------------------------------------------ boutons physiques
  const KEY = { UP: 19, DOWN: 20, LEFT: 21, RIGHT: 22, CENTER: 23, A: 96, B: 97, X: 99, Y: 100, L1: 102, R1: 103, L2: 104, R2: 105, START: 108, SELECT: 109, ENTER: 66 };
  App.KEY = KEY;
  App.setPadMode = function (on) {
    if (UI.padMode === on) return;
    UI.padMode = on;
    document.body.classList.toggle('pad', on);
    if (on) UI.focusFirst();
  };
  function navStep(d) {
    const keys = App.nav().map(n => n[0]);
    const cur = App.page === 'fiche' ? 'parc' : App.page === 'tech' ? 'accueil' : App.page;
    const i = keys.indexOf(cur);
    App.stack = [];
    App.go(keys[(i + d + keys.length) % keys.length], {}, { replace: true });
  }
  App.onKey = function (code, name, down, rep) {
    if (!down) return;
    App.setPadMode(true);
    const s = Store.settings();
    if (s.swapAB) { if (code === KEY.A) code = KEY.B; else if (code === KEY.B) code = KEY.A; }
    if (Bridge.demo && Bridge.pageVisible && Bridge.pageVisible()) { if (code === KEY.B) App.back(); return; }
    if (root.UsbGui && UsbGui.visible) { if (code === KEY.B) App.back(); return; }
    const P = Pages[App.page];
    const el = document.activeElement;
    const adjustable = el && ((el.tagName === 'INPUT' && el.type === 'number') || el.tagName === 'SELECT' || el.classList.contains('seg-b'));
    switch (code) {
      case KEY.UP: UI.move('up'); break;
      case KEY.DOWN: UI.move('down'); break;
      case KEY.LEFT: if (!(adjustable && UI.adjust(-1))) UI.move('left'); break;
      case KEY.RIGHT: if (!(adjustable && UI.adjust(1))) UI.move('right'); break;
      case KEY.A: case KEY.CENTER: case KEY.ENTER: if (!rep) UI.activate(); break;
      case KEY.B: if (!rep) App.back(); break;
      case KEY.X: if (!rep && P && P.padX) P.padX(el); else if (!rep) UI.toast('X : pas d\'action ici'); break;
      case KEY.Y: if (!rep && P && P.padY) P.padY(el); break;
      case KEY.START: if (!rep && P && P.padStart) P.padStart(el); break;
      case KEY.SELECT: if (!rep) App.help(); break;
      case KEY.L1: if (!rep && !UI.isOpen()) { if (P && P.padTab) P.padTab(-1); else navStep(-1); } break;
      case KEY.R1: if (!rep && !UI.isOpen()) { if (P && P.padTab) P.padTab(1); else navStep(1); } break;
      case KEY.L2: { const c = UI.isOpen() ? UI.top().el.querySelector('.dlg-b') : document.querySelector('.content'); if (c) c.scrollBy({ top: -c.clientHeight * 0.7, behavior: 'smooth' }); break; }
      case KEY.R2: { const c = UI.isOpen() ? UI.top().el.querySelector('.dlg-b') : document.querySelector('.content'); if (c) c.scrollBy({ top: c.clientHeight * 0.7, behavior: 'smooth' }); break; }
      default: break;
    }
  };
  App.help = function () {
    const P = Pages[App.page];
    const extra = (P && P.padHelp) || {};
    const rows = [
      ['Croix', 'se déplacer ; ← → change un nombre ou un choix'],
      ['A', 'valider / ouvrir'], ['B', 'retour / fermer'],
      ['X', extra.X || 'menu de l\'élément'], ['Y', extra.Y || 'lire / actualiser'],
      ['Start', extra.START || 'action principale'], ['L1 / R1', extra.L1 || 'page précédente / suivante'],
      ['L2 / R2', 'faire défiler'], ['Select', 'cette aide']
    ];
    UI.alert('Boutons de la console', '<table class="keys">' + rows.map(r => '<tr><th>' + esc(r[0]) + '</th><td>' + esc(r[1]) + '</td></tr>').join('') + '</table>' +
      (Store.settings().swapAB ? '<p class="muted">A et B sont inversés (Réglages).</p>' : ''));
  };

  // ------------------------------------------------------------ démarrage
  App.applyDisplay = function () {
    const s = Store.settings();
    document.documentElement.style.fontSize = (16 * (s.zoom || 100) / 100) + 'px';
    Bridge.keepScreenOn(s.keepScreenOn);
    Bridge.immersive(s.immersive);
    Bridge.orientation(s.orientation);
  };

  App.boot = function () {
    Store.load();
    App.page = App.home();
    App.applyDisplay();
    Bridge.on('udp', (u8, ip, port) => Disco.onUdp(u8, ip, port));
    Bridge.on('netStatus', (st, d) => {
      if (st === 'ready') { Disco.status = 'ready'; Disco.detail = d; }
      else if (st === 'error') { Disco.status = 'error'; Disco.detail = d; UI.toast(d, 'err'); }
      else if (st === 'sacn-error') UI.toast(d, 'err');
      App.refreshChips();
    });
    Bridge.on('usb', (t, d) => { USB.onEvent(t, d); });
    Bridge.on('page', (sid, t, d) => { const p = RemotePage.all[sid]; if (p) p.onEvent(t, d); });
    Bridge.on('key', App.onKey);
    Bridge.on('axes', a => {
      // joystick gauche = croix
      const now = Date.now();
      if (now - (App._ax || 0) < 180) return;
      const x = a.X || a.HAT_X || 0, y = a.Y || a.HAT_Y || 0;
      if (Math.abs(x) < 0.6 && Math.abs(y) < 0.6) return;
      App._ax = now;
      if (Math.abs(x) > Math.abs(y)) App.onKey(x > 0 ? KEY.RIGHT : KEY.LEFT, '', true, 0);
      else App.onKey(y > 0 ? KEY.DOWN : KEY.UP, '', true, 0);
    });
    Bridge.on('back', () => App.back());
    Bridge.on('flush', () => Store.flush());
    RT.listeners.push(() => App.live());
    if (Bridge.hasGamepad()) App.setPadMode(true);
    window.addEventListener('pointerdown', () => { if (UI.padMode && !Bridge.hasGamepad()) App.setPadMode(false); }, true);
    document.addEventListener('visibilitychange', () => { if (document.hidden) Store.flush(); });
    App.render(true);
    Disco.start();
    Probe.start();
    // node déjà branché au lancement
    setTimeout(() => {
      const s = USB.scan();
      if (s.ec) USB.connect(s.ec);
      if (Bridge.launchUsb()) App.go('usb');
      RT.changed('usb');
    }, 300);
    // première ouverture : aide
    if (!Store.nodes().length && !Store.state.welcomed) {
      Store.state.welcomed = true;
      Store.save();
      setTimeout(() => Pages.parc.welcome && Pages.parc.welcome(), 400);
    }
    if (App.simple() && Pages.accueil && Pages.accueil.enter) { try { Pages.accueil.enter({}); } catch (e) { console.error(e); }
    }
  };

  document.addEventListener('DOMContentLoaded', () => App.boot());
})(typeof self !== 'undefined' ? self : this);
