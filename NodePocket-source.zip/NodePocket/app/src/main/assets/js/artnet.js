/* Node Pocket — Art-Net 4 (ArtPoll, ArtPollReply, ArtAddress, ArtIpProg, ArtDmx) et sACN E1.31 (lecture) */
(function (root) {
  'use strict';
  const U = root.U || (typeof require !== 'undefined' ? require('./util.js') : null);

  const A = {};
  A.PORT = 6454;
  A.SACN_PORT = 5568;
  A.OP = {
    POLL: 0x2000, POLL_REPLY: 0x2100, DIAG: 0x2300, COMMAND: 0x2400, DMX: 0x5000, NZS: 0x5100, SYNC: 0x5200,
    ADDRESS: 0x6000, INPUT: 0x7000, TOD_REQUEST: 0x8000, TOD_DATA: 0x8100, TOD_CONTROL: 0x8200, RDM: 0x8300,
    IP_PROG: 0xF800, IP_PROG_REPLY: 0xF900
  };
  /** Commandes ArtAddress (Art-Net 4) */
  A.AC = {
    NONE: 0x00, CANCEL_MERGE: 0x01, LED_NORMAL: 0x02, LED_MUTE: 0x03, LED_LOCATE: 0x04, RESET_RX_FLAGS: 0x05,
    FAIL_HOLD: 0x08, FAIL_ZERO: 0x09, FAIL_FULL: 0x0a,
    MERGE_LTP: 0x10, DIRECTION_TX: 0x20, DIRECTION_RX: 0x30, MERGE_HTP: 0x50,
    ARTNET_SEL: 0x60, ACN_SEL: 0x70, CLEAR_OP: 0x90, STYLE_DELTA: 0xa0, STYLE_CONST: 0xb0,
    RDM_ENABLE: 0xc0, RDM_DISABLE: 0xd0
  };
  const ID = [65, 114, 116, 45, 78, 101, 116, 0]; // "Art-Net\0"

  function header(op, len) {
    const b = new Uint8Array(len);
    b.set(ID, 0);
    b[8] = op & 255;
    b[9] = (op >> 8) & 255;
    return b;
  }
  function putStr(b, off, len, s) {
    const bytes = U.utf8(String(s || ''));
    for (let i = 0; i < len - 1 && i < bytes.length; i++) b[off + i] = bytes[i] < 128 ? bytes[i] : 63;
  }

  A.isArtNet = function (b) {
    if (!b || b.length < 10) return false;
    for (let i = 0; i < 8; i++) if (b[i] !== ID[i]) return false;
    return true;
  };
  A.opcode = b => (A.isArtNet(b) ? U.u16le(b, 8) : -1);

  /** ArtPoll classique (14 octets, comme la plupart des consoles) */
  A.buildPoll = function (opts) {
    opts = opts || {};
    const b = header(A.OP.POLL, 14);
    b[10] = 0; b[11] = 14;
    b[12] = opts.flags || 0;
    b[13] = opts.priority || 0x10;
    return b;
  };

  const PROTO = ['DMX512', 'MIDI', 'Avab', 'Colortran', 'ADB', 'Art-Net', 'DALI'];

  /** Décode un ArtPollReply (207 à 239 octets selon la version du node) */
  A.parsePollReply = function (b, srcIp) {
    if (A.opcode(b) !== A.OP.POLL_REPLY || b.length < 197) return null;
    const g = i => (i < b.length ? b[i] : 0);
    const r = {};
    r.ip = [g(10), g(11), g(12), g(13)].join('.');
    r.srcIp = srcIp || r.ip;
    r.port = g(14) | (g(15) << 8);
    r.versInfo = (g(16) << 8) | g(17);
    r.netSwitch = g(18) & 0x7f;
    r.subSwitch = g(19) & 0x0f;
    r.oem = (g(20) << 8) | g(21);
    r.ubea = g(22);
    r.status1 = g(23);
    r.estaMan = g(24) | (g(25) << 8);
    r.estaCode = String.fromCharCode(g(24) || 32, g(25) || 32).trim();
    r.shortName = U.cstr(b, 26, 44);
    r.longName = U.cstr(b, 44, 108);
    r.nodeReport = U.cstr(b, 108, 172);
    r.numPorts = Math.min(4, (g(172) << 8) | g(173));
    r.portTypes = [g(174), g(175), g(176), g(177)];
    r.goodInput = [g(178), g(179), g(180), g(181)];
    r.goodOutputA = [g(182), g(183), g(184), g(185)];
    r.swIn = [g(186), g(187), g(188), g(189)];
    r.swOut = [g(190), g(191), g(192), g(193)];
    r.acnPriority = g(194);
    r.swMacro = g(195);
    r.swRemote = g(196);
    r.style = g(200);
    r.mac = b.length >= 207 ? [201, 202, 203, 204, 205, 206].map(i => g(i).toString(16).padStart(2, '0')).join(':') : '';
    r.bindIp = b.length >= 211 ? [g(207), g(208), g(209), g(210)].join('.') : r.ip;
    r.bindIndex = b.length >= 212 ? g(211) : 0;
    r.status2 = b.length >= 213 ? g(212) : 0;
    r.goodOutputB = b.length >= 217 ? [g(213), g(214), g(215), g(216)] : [0, 0, 0, 0];
    r.status3 = b.length >= 218 ? g(217) : 0;
    r.refreshRate = b.length >= 228 ? ((g(226) << 8) | g(227)) : 0;

    const led = (r.status1 >> 6) & 3;
    r.indicator = ['inconnu', 'identification', 'éteint', 'normal'][led];
    r.bootRom = !!(r.status1 & 0x04);
    r.rdmCapable = !!(r.status1 & 0x02);
    r.webConfig = !!(r.status2 & 0x01);
    r.dhcp = !!(r.status2 & 0x02);
    r.dhcpCapable = !!(r.status2 & 0x04);
    r.port15bit = !!(r.status2 & 0x08);
    r.canSwitchSacn = !!(r.status2 & 0x10);
    r.canSwitchDirection = !!(r.status3 & 0x08);

    r.ports = [];
    for (let i = 0; i < r.numPorts; i++) {
      const t = r.portTypes[i];
      const gi = r.goodInput[i], go = r.goodOutputA[i];
      const canOut = !!(t & 0x80), canIn = !!(t & 0x40);
      r.ports.push({
        index: i,
        canOut, canIn,
        protocol: PROTO[t & 0x3f] || ('#' + (t & 0x3f)),
        univOut: (r.netSwitch << 8) | (r.subSwitch << 4) | (r.swOut[i] & 0x0f),
        univIn: (r.netSwitch << 8) | (r.subSwitch << 4) | (r.swIn[i] & 0x0f),
        outData: !!(go & 0x80),
        outMerging: !!(go & 0x08),
        outLtp: !!(go & 0x02),
        outSacn: !!(go & 0x01),
        inData: !!(gi & 0x80),
        inDisabled: !!(gi & 0x08),
        inErrors: !!(gi & 0x04),
        inSacn: !!(gi & 0x01),
        rdmOff: !!(r.goodOutputB[i] & 0x80),
        continuous: !!(r.goodOutputB[i] & 0x40)
      });
    }
    return r;
  };

  /**
   * Rassemble les ArtPollReply d'un même node (un node peut répondre une fois par port : BindIndex).
   * replies : liste de réponses décodées venant de la même IP.
   */
  A.mergeReplies = function (replies) {
    if (!replies || !replies.length) return null;
    const sorted = replies.slice().sort((a, b) => (a.bindIndex || 0) - (b.bindIndex || 0));
    const seen = {};
    const uniq = sorted.filter(r => {
      const k = r.bindIndex || 0;
      if (seen[k]) return false;
      seen[k] = 1;
      return true;
    });
    const base = Object.assign({}, uniq[0]);
    base.ports = [];
    base.binds = uniq.map(r => r.bindIndex || 0);
    uniq.forEach(r => r.ports.forEach(p => base.ports.push(Object.assign({}, p, { index: base.ports.length, slot: p.index, bindIndex: r.bindIndex || 0 }))));
    base.numPorts = base.ports.length;
    base.anyOutData = base.ports.some(p => p.outData);
    base.anyInData = base.ports.some(p => p.inData);
    // Protocole global déduit des ports (bit 0 de GoodOutput / GoodInput)
    const usedSacn = base.ports.filter(p => (p.canOut && p.outSacn) || (p.canIn && !p.canOut && p.inSacn)).length;
    base.protocolGuess = base.ports.length ? (usedSacn === base.ports.length ? 'sacn' : (usedSacn === 0 ? 'artnet' : 'mixte')) : '';
    return base;
  };

  /**
   * ArtAddress : programme noms, univers, commande. Champs omis = inchangés.
   * o = { bindIndex, shortName, longName, net, subnet, swIn:[4], swOut:[4], acnPriority, command }
   * swIn/swOut : nombre 0-15 (bas de l'adresse) ou null = inchangé.
   */
  A.buildAddress = function (o) {
    o = o || {};
    const b = header(A.OP.ADDRESS, 107);
    b[10] = 0; b[11] = 14;
    b[12] = o.net == null ? 0x7f : (0x80 | (o.net & 0x7f));
    b[13] = o.bindIndex || 0;
    if (o.shortName) putStr(b, 14, 18, o.shortName);
    if (o.longName) putStr(b, 32, 64, o.longName);
    for (let i = 0; i < 4; i++) {
      const vi = o.swIn && o.swIn[i] != null ? o.swIn[i] : null;
      const vo = o.swOut && o.swOut[i] != null ? o.swOut[i] : null;
      b[96 + i] = vi == null ? 0x7f : (0x80 | (vi & 0x0f));
      b[100 + i] = vo == null ? 0x7f : (0x80 | (vo & 0x0f));
    }
    b[104] = o.subnet == null ? 0x7f : (0x80 | (o.subnet & 0x0f));
    b[105] = o.acnPriority == null ? 255 : U.clamp(o.acnPriority, 0, 200);
    b[106] = o.command || 0;
    return b;
  };

  /**
   * Prépare les paquets ArtAddress pour donner des univers (adresses 15 bits) aux ports.
   * Art-Net impose le même Net/SubNet pour les ports d'un même BindIndex.
   * ports : [{ index, bindIndex, univOut, univIn }] — valeurs null = inchangées.
   * Renvoie { packets:[Uint8Array], error }
   */
  A.planUniverses = function (ports, extra) {
    const byBind = {};
    ports.forEach(p => {
      const k = p.bindIndex || 0;
      (byBind[k] = byBind[k] || []).push(p);
    });
    const packets = [];
    for (const k of Object.keys(byBind)) {
      const list = byBind[k];
      const addrs = [];
      list.forEach(p => {
        if (p.univOut != null) addrs.push(p.univOut);
        if (p.univIn != null) addrs.push(p.univIn);
      });
      if (!addrs.length) continue;
      const net = (addrs[0] >> 8) & 0x7f, sub = (addrs[0] >> 4) & 0x0f;
      if (addrs.some(a => ((a >> 8) & 0x7f) !== net || ((a >> 4) & 0x0f) !== sub)) {
        return { packets: [], error: 'En Art-Net standard, les ports d\'un même node doivent rester dans le même bloc de 16 univers (' + (net * 256 + sub * 16) + '–' + (net * 256 + sub * 16 + 15) + ').' };
      }
      const swIn = [null, null, null, null], swOut = [null, null, null, null];
      list.forEach(p => {
        const s = (p.slot != null ? p.slot : p.index) % 4;
        if (p.univOut != null) swOut[s] = p.univOut & 0x0f;
        if (p.univIn != null) swIn[s] = p.univIn & 0x0f;
      });
      packets.push(A.buildAddress(Object.assign({ bindIndex: +k, net, subnet: sub, swIn, swOut }, extra || {})));
    }
    return { packets, error: null };
  };

  /** ArtIpProg : o = { ip, mask, gateway, dhcp:true, reset:true } (unicast vers le node) */
  A.buildIpProg = function (o) {
    o = o || {};
    const b = header(A.OP.IP_PROG, 34);
    b[10] = 0; b[11] = 14;
    let cmd = 0;
    if (o.dhcp) cmd |= 0x80 | 0x40;
    else if (o.reset) cmd |= 0x80 | 0x08;
    else {
      if (o.ip) { cmd |= 0x80 | 0x04; b.set(U.ipBytes(o.ip), 16); }
      if (o.mask) { cmd |= 0x80 | 0x02; b.set(U.ipBytes(o.mask), 20); }
      if (o.gateway) { cmd |= 0x80 | 0x10; b.set(U.ipBytes(o.gateway), 26); }
    }
    b[14] = cmd;
    return b;
  };
  /** Simple lecture (commande 0) : le node renvoie sa config IP */
  A.buildIpQuery = function () {
    const b = header(A.OP.IP_PROG, 34);
    b[10] = 0; b[11] = 14;
    return b;
  };

  A.parseIpProgReply = function (b) {
    if (A.opcode(b) !== A.OP.IP_PROG_REPLY || b.length < 26) return null;
    return {
      ip: [b[16], b[17], b[18], b[19]].join('.'),
      mask: [b[20], b[21], b[22], b[23]].join('.'),
      dhcp: !!(b[26] & 0x40),
      gateway: b.length >= 32 ? [b[28], b[29], b[30], b[31]].join('.') : ''
    };
  };

  /** ArtDmx : portAddr = adresse 15 bits (univers Art-Net à partir de 0) */
  A.buildDmx = function (portAddr, data, seq) {
    let len = Math.max(2, Math.min(512, data.length));
    if (len & 1) len++;
    const b = header(A.OP.DMX, 18 + len);
    b[10] = 0; b[11] = 14;
    b[12] = seq & 255;
    b[13] = 0;
    b[14] = portAddr & 255;
    b[15] = (portAddr >> 8) & 0x7f;
    b[16] = (len >> 8) & 255;
    b[17] = len & 255;
    b.set(data.subarray ? data.subarray(0, len) : data.slice(0, len), 18);
    return b;
  };

  A.parseDmx = function (b) {
    if (A.opcode(b) !== A.OP.DMX || b.length < 18) return null;
    const len = Math.min(512, U.u16be(b, 16), b.length - 18);
    return { seq: b[12], physical: b[13], universe: b[14] | ((b[15] & 0x7f) << 8), data: b.subarray(18, 18 + len) };
  };

  /** sACN (E1.31) : paquet de données DMX */
  A.parseSacn = function (b) {
    if (!b || b.length < 126) return null;
    // Identifiant ACN "ASC-E1.17\0\0\0" à l'octet 4
    const acn = [0x41, 0x53, 0x43, 0x2d, 0x45, 0x31, 0x2e, 0x31, 0x37, 0, 0, 0];
    for (let i = 0; i < 12; i++) if (b[4 + i] !== acn[i]) return null;
    const rootVector = U.u32le([b[21], b[20], b[19], b[18]], 0);
    if (rootVector !== 0x00000004) return null;
    const framingVector = U.u32le([b[43], b[42], b[41], b[40]], 0);
    if (framingVector !== 0x00000002) return null;
    const cid = U.hex(b.subarray(22, 38));
    const sourceName = U.cstr(b, 44, 108);
    const priority = b[108];
    const seq = b[111];
    const options = b[112];
    const universe = U.u16be(b, 113);
    const count = U.u16be(b, 123); // nombre de valeurs (start code compris)
    const startCode = b[125];
    const len = Math.max(0, Math.min(512, count - 1, b.length - 126));
    return { universe, priority, seq, options, cid, sourceName, startCode, preview: !!(options & 0x80), terminated: !!(options & 0x40), data: b.subarray(126, 126 + len) };
  };

  /** Adresse multicast sACN d'un univers (1 à 63999) */
  A.sacnGroup = u => '239.255.' + ((u >> 8) & 255) + '.' + (u & 255);

  /** Texte d'un univers Art-Net 15 bits : "0:0:3 (3)" */
  A.fmtPortAddr = pa => ((pa >> 8) & 0x7f) + ':' + ((pa >> 4) & 0x0f) + ':' + (pa & 0x0f) + ' (' + pa + ')';

  if (typeof module !== 'undefined' && module.exports) module.exports = A;
  else root.ArtNet = A;
})(typeof self !== 'undefined' ? self : this);
