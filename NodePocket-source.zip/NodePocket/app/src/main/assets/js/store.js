/* Node Pocket — données de l'appli : parc, productions, réglages, journal (sauvegarde automatique). Développé par 3DP. */
(function (root) {
  'use strict';

  const DEFAULT_SETTINGS = {
    simple: false,             // mode simple (techniciens) : IP, protocole, univers par port
    autoPoll: true,            // découverte Art-Net automatique
    pollEvery: 6,              // secondes
    broadcasts: '',            // adresses de diffusion en plus (séparées par des virgules)
    subnetIp: '2.0.0.0',       // réseau de la régie (vérifications)
    subnetMask: '255.0.0.0',
    expected: '',              // univers utilisés par la console (numérotation MA)
    defaultUser: 'admin',
    defaultPass: '',
    usbAllParams: false,       // USB : renvoyer tous les paramètres comme dmx-tools
    artnetWrite: true,         // autoriser ArtAddress / ArtIpProg quand rien d'autre n'est possible
    webApply: '',              // motif du bouton Appliquer des pages (vide = automatique)
    webTimeout: 12,            // secondes pour charger une page de node
    probeEvery: 20,            // secondes entre deux tests de présence (port 80)
    swapAB: false,
    immersive: false,
    orientation: 'auto',
    keepScreenOn: true,
    zoom: 100,
    numbering: 'both'          // affichage des univers : 'net', 'ma', 'both'
  };

  const Store = {
    state: null,
    dirty: false,
    listeners: []
  };

  function fresh() {
    return { v: 1, v2: true, nodes: [], prods: [], fwPinned: {}, settings: Object.assign({}, DEFAULT_SETTINGS), journal: [], created: Date.now() };
  }

  Store.load = function () {
    let s = null;
    try {
      const raw = Bridge.loadState();
      if (raw) s = JSON.parse(raw);
    } catch (e) {
      console.error('état illisible', e);
    }
    Store.state = Store.migrate(s || fresh());
    return Store.state;
  };

  Store.migrate = function (s) {
    if (!s || typeof s !== 'object') s = fresh();
    s.v = 1;
    s.nodes = Array.isArray(s.nodes) ? s.nodes : [];
    s.prods = Array.isArray(s.prods) ? s.prods : [];
    s.fwPinned = s.fwPinned || {};
    s.settings = Object.assign({}, DEFAULT_SETTINGS, s.settings || {});
    s.journal = Array.isArray(s.journal) ? s.journal.slice(-400) : [];
    s.nodes.forEach(n => {
      n.id = n.id || U.uid('n');
      n.plan = n.plan || {};
      n.plan.ports = n.plan.ports || [];
      n.tags = Array.isArray(n.tags) ? n.tags : [];
      n.history = Array.isArray(n.history) ? n.history.slice(-12) : [];
      n.login = n.login || {};
      if (n.sacnBase == null) n.sacnBase = 'auto';
      // nodes enregistrés avant la gestion des marques : tous Electroconcept
      if (!n.brand) n.brand = s.v2 ? 'auto' : 'electroconcept';
    });
    s.v2 = true;
    return s;
  };

  let timer = null;
  Store.save = function (now) {
    Store.dirty = true;
    clearTimeout(timer);
    const run = () => {
      if (!Store.dirty) return;
      Store.dirty = false;
      try {
        Bridge.saveState(JSON.stringify(Store.state));
      } catch (e) {
        console.error(e);
        UI.toast('Sauvegarde impossible : ' + e.message, 'err');
      }
    };
    if (now) run(); else timer = setTimeout(run, 400);
  };
  Store.flush = () => Store.save(true);

  // ------------------------------------------------------------ nodes
  Store.nodes = () => Store.state.nodes;
  Store.node = id => Store.state.nodes.find(n => n.id === id) || null;
  Store.byIp = ip => Store.state.nodes.find(n => n.ip === ip) || null;
  Store.bySerial = serial => (serial ? Store.state.nodes.find(n => n.serial && String(n.serial).trim() === String(serial).trim()) : null);
  Store.byMac = mac => (mac ? Store.state.nodes.find(n => n.mac && n.mac.toLowerCase() === mac.toLowerCase()) : null);

  Store.addNode = function (o) {
    const n = Object.assign({
      id: U.uid('n'), name: '', ip: '', model: 4, serial: '', mac: '', notes: '', tags: [], login: {}, sacnBase: 'auto', brand: 'auto',
      plan: { ports: [] }, last: null, history: [], created: Date.now()
    }, o || {});
    n.plan = n.plan || { ports: [] };
    if (!n.name) n.name = n.plan.shortName || ('Node ' + (Store.state.nodes.length + 1));
    Store.state.nodes.push(n);
    Store.save();
    return n;
  };

  Store.removeNode = function (id) {
    Store.state.nodes = Store.state.nodes.filter(n => n.id !== id);
    Store.save();
  };

  /**
   * Marque du node : choix manuel, sinon reconnue (USB, code OEM Art-Net, noms, code ESTA),
   * sinon la dernière reconnue (mémorisée pour quand le node est éteint).
   */
  Store.brand = function (n) {
    const usb = n.usbSeen || (root.USB && USB.nodeId === n.id) ? { vid: 0x1fc9, pid: 0x0052 } : null;
    const det = Brands.detect({ brand: n.brand, poll: root.RT ? RT.poll[n.id] : null, product: n.product, title: n.last && n.last.title, usb });
    if (det.how === 'inconnu' && n.detBrand && Brands.BY[n.detBrand]) return { id: n.detBrand, how: 'mémorisé', model: n.detModel || '' };
    if (det.how !== 'manuel' && det.how !== 'inconnu' && (n.detBrand !== det.id || (det.model && n.detModel !== det.model))) {
      n.detBrand = det.id;
      if (det.model) n.detModel = det.model;
      Store.save();
    }
    if (det.how === 'manuel' && !det.model && n.detBrand === det.id) det.model = n.detModel || '';
    return det;
  };
  Store.brandInfo = n => Brands.get(Store.brand(n).id);

  /** Nom affiché : nom donné dans l'appli, sinon nom court lu */
  Store.label = n => n.name || (n.last && n.last.canon && n.last.canon.shortName) || n.ip || 'Node';
  /** Nombre de ports connu */
  Store.ports = n => Math.max(n.model || 0, (n.last && n.last.ports) || 0, (n.plan.ports || []).length, 0) || 1;

  /** Config voulue complète : le prévu par-dessus le lu */
  Store.wanted = function (n) {
    // base : la dernière lecture ; à défaut, ce que le node annonce en Art-Net
    const poll = !(n.last && n.last.canon) && root.RT && RT.poll[n.id] ? Model.fromPoll(RT.poll[n.id]) : null;
    if (poll) {
      if (poll.ipMode === 'static' && !poll.ip) poll.ip = poll.ipNow || n.ip;
      delete poll.ipNow;
    }
    const base = n.last && n.last.canon ? U.clone(n.last.canon) : (poll || { ports: [] });
    const flat = Model.flat(n.plan || {});
    Object.keys(flat).forEach(k => Model.setPath(base, k, flat[k]));
    base.ports = base.ports || [];
    for (let i = 0; i < Store.ports(n); i++) base.ports[i] = base.ports[i] || {};
    return base;
  };
  /** Écarts entre le prévu et le lu */
  Store.pending = function (n) {
    if (!n.last || !n.last.canon) return Model.diff(n.plan, { ports: [] }).filter(d => d.want !== undefined);
    return Model.diff(n.plan, n.last.canon);
  };

  /** Enregistre une lecture */
  Store.recordRead = function (n, rec) {
    const prev = n.last;
    n.last = rec;
    if (rec.canon) {
      if (rec.canon.serial && !n.serial) n.serial = rec.canon.serial;
      if (rec.ports) n.model = n.model && n.model >= rec.ports ? n.model : rec.ports;
      if (rec.product) n.product = rec.product;
      if (rec.canon.firmware) n.firmware = rec.canon.firmware;
      // historique : seulement si quelque chose a changé
      if (!prev || !prev.canon || Model.diff(rec.canon, prev.canon).length) {
        n.history.push({ at: rec.at, via: rec.via, canon: U.clone(rec.canon) });
        n.history = n.history.slice(-12);
      }
    }
    Store.save();
  };

  // ------------------------------------------------------------ journal
  Store.log = function (node, what, ok, detail) {
    Store.state.journal.push({ at: Date.now(), node: node ? Store.label(node) : '', id: node ? node.id : '', what, ok: ok !== false, detail: detail || '' });
    if (Store.state.journal.length > 400) Store.state.journal.splice(0, Store.state.journal.length - 400);
    Store.save();
  };

  Store.settings = () => Store.state.settings;
  Store.DEFAULT_SETTINGS = DEFAULT_SETTINGS;

  // ------------------------------------------------------------ export / import
  Store.exportAll = function () {
    return JSON.stringify({ app: 'Node Pocket', format: 1, at: Date.now(), state: Store.state }, null, 1);
  };
  /** mode : 'replace' | 'merge' ; renvoie un résumé */
  Store.importAll = function (txt, mode) {
    const o = JSON.parse(txt);
    const st = o && o.state ? o.state : o;
    if (!st || !Array.isArray(st.nodes)) throw new Error('ce fichier n\'est pas une sauvegarde Node Pocket');
    const inc = Store.migrate(U.clone(st));
    if (mode === 'replace') {
      Store.state = inc;
      Store.save(true);
      return inc.nodes.length + ' nodes, ' + inc.prods.length + ' productions';
    }
    let added = 0, updated = 0;
    inc.nodes.forEach(n => {
      const ex = Store.node(n.id) || Store.bySerial(n.serial) || (n.ip && Store.byIp(n.ip));
      if (ex) { Object.assign(ex, n, { id: ex.id }); updated++; } else { Store.state.nodes.push(n); added++; }
    });
    inc.prods.forEach(p => { if (!Store.state.prods.find(x => x.id === p.id)) Store.state.prods.push(p); });
    Store.save(true);
    return added + ' nodes ajoutés, ' + updated + ' mis à jour';
  };

  /** Tableau CSV du parc (pour la feuille de patch) */
  Store.csv = function () {
    const rows = [['Nom', 'IP', 'Adressage', 'Modèle', 'Protocole', 'Port', 'Sens', 'Univers', 'Univers MA', 'N° série', 'Firmware', 'Notes']];
    Store.state.nodes.forEach(n => {
      const c = Store.wanted(n);
      const np = Store.ports(n);
      for (let i = 0; i < np; i++) {
        const pu = Model.portUniverse(c, c.ports[i]);
        rows.push([Store.label(n), c.ip || n.ip || '', c.ipMode === 'dhcp' ? 'DHCP' : 'fixe', np + ' univers', c.protocol === 'sacn' ? 'sACN' : 'Art-Net', 'DMX ' + (i + 1),
          pu ? (pu.dir === 'in' ? 'entrée' : 'sortie') : '', pu ? pu.univ : '', pu ? pu.ma : '', n.serial || '', n.firmware || '', n.notes || '']);
      }
    });
    return rows.map(r => r.map(x => {
      const s = String(x == null ? '' : x);
      return /[;"\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }).join(';')).join('\n');
  };

  root.Store = Store;
})(typeof self !== 'undefined' ? self : this);
