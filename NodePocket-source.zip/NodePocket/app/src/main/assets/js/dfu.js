/*
 * Node Pocket — mise à jour de firmware par USB DFU (norme USB DFU 1.1 et variante DfuSe ST)
 *
 * Le node passe en mode DFU via son réglage « DFU » (dmx-tools fait pareil), puis réapparaît
 * sur l'USB comme un périphérique de classe DFU (0xFE / 0x01). Ce module envoie le fichier.
 * Les transferts passent par io.control(...) (côté Android : UsbDeviceConnection.controlTransfer).
 */
(function (root) {
  'use strict';
  const U = root.U || (typeof require !== 'undefined' ? require('./util.js') : null);

  const D = {};
  D.REQ = { DETACH: 0, DNLOAD: 1, UPLOAD: 2, GETSTATUS: 3, CLRSTATUS: 4, GETSTATE: 5, ABORT: 6 };
  D.STATE = ['appIDLE', 'appDETACH', 'dfuIDLE', 'dfuDNLOAD-SYNC', 'dfuDNBUSY', 'dfuDNLOAD-IDLE', 'dfuMANIFEST-SYNC', 'dfuMANIFEST', 'dfuMANIFEST-WAIT-RESET', 'dfuUPLOAD-IDLE', 'dfuERROR'];
  D.S = { APP_IDLE: 0, APP_DETACH: 1, IDLE: 2, DNLOAD_SYNC: 3, DNBUSY: 4, DNLOAD_IDLE: 5, MANIFEST_SYNC: 6, MANIFEST: 7, MANIFEST_WAIT_RESET: 8, UPLOAD_IDLE: 9, ERROR: 10 };
  D.STATUS = ['OK', 'errTARGET', 'errFILE', 'errWRITE', 'errERASE', 'errCHECK_ERASED', 'errPROG', 'errVERIFY', 'errADDRESS', 'errNOTDONE', 'errFIRMWARE', 'errVENDOR', 'errUSBR', 'errPOR', 'errUNKNOWN', 'errSTALLEDPKT'];
  D.STATUS_FR = {
    errTARGET: 'fichier pas fait pour ce produit', errFILE: 'fichier refusé', errWRITE: 'écriture impossible', errERASE: 'effacement impossible',
    errCHECK_ERASED: 'effacement non vérifié', errPROG: 'programmation impossible', errVERIFY: 'vérification échouée', errADDRESS: 'adresse hors mémoire',
    errNOTDONE: 'fichier incomplet', errFIRMWARE: 'firmware corrompu', errVENDOR: 'erreur du fabricant', errUSBR: 'reset USB inattendu',
    errPOR: 'redémarrage inattendu', errUNKNOWN: 'erreur inconnue', errSTALLEDPKT: 'requête refusée'
  };
  const OUT = 0x21, IN = 0xA1;

  // ---------------------------------------------------------------- descripteurs
  /**
   * Parcourt les descripteurs bruts USB et renvoie les interfaces DFU :
   * [{ iface, alt, protocol, iInterface, func:{ attributes, canDnload, canUpload, manifestTolerant, willDetach, detachTimeout, transferSize, version } }]
   */
  D.findInterfaces = function (raw) {
    const out = [];
    let cur = null;
    for (let i = 0; i + 1 < raw.length;) {
      const len = raw[i], type = raw[i + 1];
      if (len < 2) break;
      if (type === 0x04 && len >= 9) {
        cur = null;
        if (raw[i + 5] === 0xFE && raw[i + 6] === 0x01) {
          cur = { iface: raw[i + 2], alt: raw[i + 3], protocol: raw[i + 7], iInterface: raw[i + 8], func: null };
          out.push(cur);
        }
      } else if (type === 0x21 && cur && len >= 7) {
        const a = raw[i + 2];
        cur.func = {
          attributes: a,
          canDnload: !!(a & 1), canUpload: !!(a & 2), manifestTolerant: !!(a & 4), willDetach: !!(a & 8),
          detachTimeout: U.u16le(raw, i + 3),
          transferSize: U.u16le(raw, i + 5),
          version: len >= 9 ? U.u16le(raw, i + 7) : 0x0100
        };
      }
      i += len;
    }
    // descripteur fonctionnel partagé : le recopier sur les autres alternatives
    const f = out.find(x => x.func);
    out.forEach(x => { if (!x.func && f) x.func = f.func; });
    return out;
  };

  /** Plan mémoire DfuSe : "@Internal Flash  /0x08000000/04*016Kg,01*064Kg,07*128Kg" */
  D.parseDfuseLayout = function (s) {
    const m = /@([^/]*)\/\s*(0x[0-9a-f]+)\s*\/(.*)/i.exec(String(s || ''));
    if (!m) return null;
    let addr = parseInt(m[2], 16);
    const segs = [];
    m[3].split(',').forEach(part => {
      const x = /(\d+)\*(\d+)\s*([KMB ]?)([a-g])/i.exec(part.trim());
      if (!x) return;
      const count = +x[1];
      const mult = x[3].toUpperCase() === 'K' ? 1024 : x[3].toUpperCase() === 'M' ? 1048576 : 1;
      const size = +x[2] * mult;
      const t = x[4].toLowerCase().charCodeAt(0) - 96; // a=1 … g=7
      for (let i = 0; i < count; i++) {
        segs.push({ start: addr, size, readable: !!(t & 1), erasable: !!(t & 2), writable: !!(t & 4) });
        addr += size;
      }
    });
    return { name: m[1].trim(), segs };
  };

  // ---------------------------------------------------------------- fichiers
  /** Suffixe DFU (16 derniers octets) ou null */
  D.parseSuffix = function (b) {
    if (b.length < 16) return null;
    const n = b.length;
    if (b[n - 8] !== 0x55 || b[n - 7] !== 0x46 || b[n - 6] !== 0x44) return null; // "UFD"
    const len = b[n - 5];
    const crc = U.u32le(b, n - 4);
    return {
      bcdDevice: U.u16le(b, n - 16), pid: U.u16le(b, n - 14), vid: U.u16le(b, n - 12), bcdDFU: U.u16le(b, n - 10),
      length: len, crc, crcOk: U.crc32(b, 0, n - 4, true) === crc
    };
  };

  /** Fichier Intel HEX -> éléments { addr, data } */
  D.parseIntelHex = function (text) {
    const lines = String(text).split(/\r?\n/);
    let base = 0;
    const bytes = new Map();
    for (const raw of lines) {
      const l = raw.trim();
      if (!l) continue;
      if (l[0] !== ':') throw new Error('ligne HEX invalide');
      const b = U.fromHex(l.slice(1));
      const n = b[0], addr = (b[1] << 8) | b[2], type = b[3];
      let sum = 0;
      for (let i = 0; i < b.length; i++) sum = (sum + b[i]) & 255;
      if (sum !== 0) throw new Error('somme de contrôle HEX fausse');
      if (type === 0) for (let i = 0; i < n; i++) bytes.set(base + addr + i, b[4 + i]);
      else if (type === 1) break;
      else if (type === 2) base = ((b[4] << 8) | b[5]) << 4;
      else if (type === 4) base = (((b[4] << 8) | b[5]) << 16) >>> 0;
    }
    const addrs = Array.from(bytes.keys()).sort((a, b) => a - b);
    const els = [];
    let cur = null;
    for (const a of addrs) {
      if (!cur || a !== cur.addr + cur.bytes.length) { cur = { addr: a, bytes: [] }; els.push(cur); }
      cur.bytes.push(bytes.get(a));
    }
    return els.map(e => ({ addr: e.addr >>> 0, data: Uint8Array.from(e.bytes) }));
  };

  /**
   * Analyse un fichier de firmware.
   * Renvoie { kind:'dfuse'|'dfu'|'bin'|'hex', suffix, payload (dfu/bin), images:[{alt, name, elements}], size }
   */
  D.parseFile = function (b, name) {
    name = String(name || '').toLowerCase();
    if (/\.hex$/.test(name) || (b[0] === 0x3a && /^:[0-9A-F]{8}/i.test(String.fromCharCode.apply(null, b.subarray(0, 9))))) {
      const els = D.parseIntelHex(U.utf8dec(b));
      return { kind: 'hex', suffix: null, images: [{ alt: 0, name: '', elements: els }], size: els.reduce((s, e) => s + e.data.length, 0) };
    }
    const suffix = D.parseSuffix(b);
    const body = suffix ? b.subarray(0, b.length - suffix.length) : b;
    if (body.length >= 11 && String.fromCharCode.apply(null, body.subarray(0, 5)) === 'DfuSe') {
      const nTargets = body[10];
      let o = 11;
      const images = [];
      for (let t = 0; t < nTargets; t++) {
        if (String.fromCharCode.apply(null, body.subarray(o, o + 6)) !== 'Target') throw new Error('fichier DfuSe abîmé (cible ' + t + ')');
        const alt = body[o + 6];
        const named = U.u32le(body, o + 7);
        const tname = named ? U.cstr(body, o + 11, o + 266) : '';
        const nEl = U.u32le(body, o + 270);
        o += 274;
        const elements = [];
        for (let e = 0; e < nEl; e++) {
          const addr = U.u32le(body, o), size = U.u32le(body, o + 4);
          o += 8;
          if (o + size > body.length) throw new Error('fichier DfuSe tronqué');
          elements.push({ addr, data: body.subarray(o, o + size) });
          o += size;
        }
        images.push({ alt, name: tname, elements });
      }
      return { kind: 'dfuse', suffix, images, size: images.reduce((s, im) => s + im.elements.reduce((x, e) => x + e.data.length, 0), 0) };
    }
    return { kind: suffix ? 'dfu' : 'bin', suffix, payload: body, size: body.length };
  };

  // ---------------------------------------------------------------- transferts
  class Device {
    /**
     * io.control(type, request, value, index, dataOrLength, timeoutMs) -> Promise<Uint8Array|number>
     *   (OUT : renvoie le nombre d'octets, IN : renvoie les octets lus)
     * info = { iface, transferSize, manifestTolerant, willDetach, dfuse:bool, layout }
     */
    constructor(io, info) {
      this.io = io;
      this.info = Object.assign({ iface: 0, transferSize: 1024 }, info || {});
      this.log = this.info.log || null;
      this.aborted = false;
    }
    _log(s) { if (this.log) this.log(s); }

    async getStatus() {
      const r = await this.io.control(IN, D.REQ.GETSTATUS, 0, this.info.iface, 6, 3000);
      if (!r || r.length < 6) throw new Error('GETSTATUS sans réponse');
      return { status: r[0], statusName: D.STATUS[r[0]] || ('#' + r[0]), poll: r[1] | (r[2] << 8) | (r[3] << 16), state: r[4], stateName: D.STATE[r[4]] || ('#' + r[4]) };
    }
    async getState() {
      const r = await this.io.control(IN, D.REQ.GETSTATE, 0, this.info.iface, 1, 3000);
      return r[0];
    }
    clearStatus() { return this.io.control(OUT, D.REQ.CLRSTATUS, 0, this.info.iface, new Uint8Array(0), 3000); }
    abort() { return this.io.control(OUT, D.REQ.ABORT, 0, this.info.iface, new Uint8Array(0), 3000); }
    dnload(block, data) { return this.io.control(OUT, D.REQ.DNLOAD, block, this.info.iface, data, 5000); }
    detach(ms) { return this.io.control(OUT, D.REQ.DETACH, ms || 1000, this.info.iface, new Uint8Array(0), 3000); }

    /** Attend la fin d'une opération (en respectant bwPollTimeout) */
    async waitWhile(states, maxMs) {
      const t0 = Date.now();
      for (;;) {
        const s = await this.getStatus();
        if (s.status !== 0) {
          const err = new Error('le node a refusé : ' + (D.STATUS_FR[s.statusName] || s.statusName));
          err.dfuStatus = s;
          throw err;
        }
        if (states.indexOf(s.state) < 0) return s;
        if (Date.now() - t0 > (maxMs || 60000)) throw new Error('le node ne répond plus (état ' + s.stateName + ')');
        await U.sleep(Math.max(1, Math.min(s.poll, 5000)));
      }
    }

    /** Met le périphérique dans l'état dfuIDLE */
    async ready() {
      let s = await this.getStatus();
      if (s.state === D.S.ERROR) { await this.clearStatus(); s = await this.getStatus(); }
      if (s.state === D.S.APP_IDLE || s.state === D.S.APP_DETACH) throw new Error('le node n\'est pas en mode DFU');
      if (s.state !== D.S.IDLE) { await this.abort(); s = await this.getStatus(); }
      if (s.state === D.S.ERROR) { await this.clearStatus(); s = await this.getStatus(); }
      if (s.state !== D.S.IDLE) throw new Error('le node n\'est pas prêt (état ' + s.stateName + ')');
      return s;
    }

    /** Fin de téléchargement : bloc vide puis manifestation (le node redémarre souvent tout seul) */
    async manifest() {
      try {
        await this.dnload(this.lastBlock + 1 || 0, new Uint8Array(0));
        const s = await this.waitWhile([D.S.MANIFEST_SYNC, D.S.MANIFEST], 30000);
        return s.stateName;
      } catch (e) {
        // un node qui redémarre coupe l'USB : c'est le comportement normal en fin de mise à jour
        if (/USB|déconnect|disconnect|réponse|timeout|délai|I\/O|-1/i.test(e.message) && !e.dfuStatus) return 'redémarrage';
        throw e;
      }
    }

    /** DFU 1.1 : envoie le fichier bloc par bloc */
    async download(payload, progress) {
      await this.ready();
      const size = this.info.transferSize;
      let block = 0;
      for (let off = 0; off < payload.length; off += size) {
        if (this.aborted) throw new Error('annulé');
        const chunk = payload.subarray(off, Math.min(payload.length, off + size));
        await this.dnload(block, chunk);
        await this.waitWhile([D.S.DNBUSY, D.S.DNLOAD_SYNC], 30000);
        this.lastBlock = block;
        block = (block + 1) & 0xffff;
        if (progress) progress(Math.min(1, (off + chunk.length) / payload.length), 'écriture');
      }
      this.lastBlock = block - 1;
      if (progress) progress(1, 'finalisation');
      return this.manifest();
    }

    // ---- DfuSe (STM32)
    async dfuseCommand(cmd, addr) {
      const b = addr == null ? new Uint8Array([cmd]) : new Uint8Array([cmd, addr & 255, (addr >>> 8) & 255, (addr >>> 16) & 255, (addr >>> 24) & 255]);
      await this.dnload(0, b);
      await this.waitWhile([D.S.DNBUSY, D.S.DNLOAD_SYNC], 30000);
    }

    async downloadDfuse(elements, progress) {
      await this.ready();
      const layout = this.info.layout;
      const total = elements.reduce((s, e) => s + e.data.length, 0);
      // effacement des pages concernées
      const pages = [];
      elements.forEach(e => {
        if (!layout) return;
        layout.segs.forEach(sg => {
          if (sg.erasable && sg.start < e.addr + e.data.length && sg.start + sg.size > e.addr && pages.indexOf(sg.start) < 0) pages.push(sg.start);
        });
      });
      if (layout) {
        const bad = elements.find(e => !layout.segs.some(sg => e.addr >= sg.start && e.addr < sg.start + sg.size));
        if (bad) throw new Error('adresse 0x' + bad.addr.toString(16) + ' hors de la mémoire du node');
      }
      for (let i = 0; i < pages.length; i++) {
        await this.dfuseCommand(0x41, pages[i]);
        if (progress) progress(0.3 * (i + 1) / pages.length, 'effacement');
      }
      let done = 0;
      const size = this.info.transferSize;
      for (const e of elements) {
        for (let off = 0; off < e.data.length; off += size) {
          if (this.aborted) throw new Error('annulé');
          const chunk = e.data.subarray(off, Math.min(e.data.length, off + size));
          await this.dfuseCommand(0x21, e.addr + off);
          await this.abort(); // revient en dfuIDLE avant le bloc de données
          await this.dnload(2, chunk);
          await this.waitWhile([D.S.DNBUSY, D.S.DNLOAD_SYNC], 30000);
          done += chunk.length;
          if (progress) progress(0.3 + 0.7 * done / total, 'écriture');
        }
      }
      // démarrage du nouveau firmware à l'adresse du premier élément
      await this.dfuseCommand(0x21, elements[0].addr);
      await this.abort();
      this.lastBlock = 1; // DfuSe : la sortie se fait avec un bloc vide n° 2
      return this.manifest();
    }
  }
  D.Device = Device;

  /** Vérifications avant mise à jour ; renvoie [{level, msg}] */
  D.check = function (file, dev) {
    const out = [];
    if (!file || !file.size) { out.push({ level: 'err', msg: 'Fichier vide' }); return out; }
    if (file.suffix) {
      if (!file.suffix.crcOk) out.push({ level: 'err', msg: 'Fichier abîmé (CRC du suffixe DFU faux)' });
      if (dev && file.suffix.vid !== 0xffff && dev.vid != null && file.suffix.vid !== dev.vid) out.push({ level: 'warn', msg: 'Fichier prévu pour un autre fabricant USB (VID ' + file.suffix.vid.toString(16) + ')' });
      if (dev && file.suffix.pid !== 0xffff && dev.pid != null && file.suffix.pid !== dev.pid) out.push({ level: 'warn', msg: 'Fichier prévu pour un autre produit USB (PID ' + file.suffix.pid.toString(16) + ')' });
    } else if (file.kind === 'bin') out.push({ level: 'info', msg: 'Fichier .bin brut : pas de signature à vérifier' });
    if (dev && dev.dfuse && file.kind === 'bin') out.push({ level: 'err', msg: 'Ce node attend un fichier .dfu ou .hex (avec adresses), pas un .bin brut' });
    if (dev && !dev.dfuse && (file.kind === 'dfuse' || file.kind === 'hex')) out.push({ level: 'warn', msg: 'Fichier avec adresses mémoire envoyé à un node DFU standard : seules les données sont transmises' });
    if (dev && dev.func && !dev.func.canDnload) out.push({ level: 'err', msg: 'Ce périphérique DFU n\'accepte pas d\'écriture' });
    if (file.size > 4 * 1024 * 1024) out.push({ level: 'warn', msg: 'Fichier très gros (' + Math.round(file.size / 1024) + ' Ko)' });
    return out;
  };

  /** Données à envoyer à un périphérique DFU standard */
  D.flatPayload = function (file) {
    if (file.payload) return file.payload;
    const els = file.images[0].elements;
    if (els.length === 1) return els[0].data;
    const start = els[0].addr, end = els[els.length - 1].addr + els[els.length - 1].data.length;
    const out = new Uint8Array(end - start).fill(0xff);
    els.forEach(e => out.set(e.data, e.addr - start));
    return out;
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = D;
  else root.DFU = D;
})(typeof self !== 'undefined' ? self : this);
