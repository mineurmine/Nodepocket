/*
 * Node Pocket — moteur : découverte Art-Net, présence, session USB, pages web des nodes,
 * lecture / écriture des réglages par le meilleur chemin disponible, mise à jour DFU.
 */
(function (root) {
  'use strict';
  const A = root.ArtNet, H = root.ECHid, M = root.Model;

  // ================================================================ état en direct (non sauvegardé)
  const RT = { online: {}, poll: {}, probe: {}, busy: {}, listeners: [] };
  root.RT = RT;
  RT.changed = function (what) {
    RT.listeners.forEach(fn => { try { fn(what); } catch (e) { console.error(e); } });
  };
  RT.isOnline = function (n) {
    const o = RT.online[n.id];
    if (!o) return false;
    const s = Store.settings();
    const maxAge = o.via === 'artnet' ? Math.max(15000, s.pollEvery * 3000 + 2000) : Math.max(45000, s.probeEvery * 2500);
    return Date.now() - o.at < maxAge;
  };
  RT.status = function (n) {
    if (USB.nodeId === n.id && USB.state === 'ready') return 'usb';
    if (RT.busy[n.id]) return 'busy';
    return RT.isOnline(n) ? 'on' : (RT.online[n.id] ? 'lost' : 'off');
  };
  function markOnline(n, via, extra) {
    const was = RT.isOnline(n);
    RT.online[n.id] = Object.assign({ at: Date.now(), via }, extra || {});
    if (!was) RT.changed('online');
  }

  // ================================================================ découverte Art-Net
  const Disco = { status: 'off', detail: '', live: {}, window: null, ipProg: [], lastPoll: 0, timer: null };
  root.Disco = Disco;

  Disco.targets = function () {
    const s = Store.settings();
    const set = new Set();
    Bridge.netInfo().forEach(i => { if (i.broadcast) set.add(i.broadcast); });
    String(s.broadcasts || '').split(/[,;\s]+/).filter(U.isIp).forEach(ip => set.add(ip));
    if (U.isIp(s.subnetIp) && U.isMask(s.subnetMask)) set.add(U.broadcast(s.subnetIp, s.subnetMask));
    set.add('255.255.255.255');
    return Array.from(set);
  };

  Disco.start = function () {
    Bridge.udpStart();
    clearInterval(Disco.timer);
    Disco.timer = setInterval(() => {
      const s = Store.settings();
      if (s.autoPoll && Date.now() - Disco.lastPoll > s.pollEvery * 1000 && !document.hidden) Disco.poll();
    }, 1000);
    setTimeout(() => Disco.poll(), 600);
  };

  /** Envoie un ArtPoll (diffusion + chaque node en IP fixe) ; résout avec la liste des réponses */
  Disco.poll = function (unicastOnly) {
    Disco.lastPoll = Date.now();
    const pkt = A.buildPoll();
    if (!Disco.window) Disco.window = { replies: {}, waiters: [] };
    const w = Disco.window;
    if (!unicastOnly) Disco.targets().forEach(ip => Bridge.udpSend(ip, A.PORT, pkt));
    Store.nodes().forEach(n => { if (U.isIp(n.ip)) Bridge.udpSend(n.ip, A.PORT, pkt); });
    return new Promise(resolve => {
      w.waiters.push(resolve);
      if (!w.timer) w.timer = setTimeout(() => Disco.close(w), 1600);
    });
  };
  /** Interroge un seul node */
  Disco.pollOne = function (ip, waitMs) {
    const pkt = A.buildPoll();
    return new Promise(resolve => {
      const got = [];
      const fn = (r) => { if (r.srcIp === ip || r.ip === ip) got.push(r); };
      Disco.extra.push(fn);
      Bridge.udpSend(ip, A.PORT, pkt);
      setTimeout(() => {
        Disco.extra.splice(Disco.extra.indexOf(fn), 1);
        resolve(got.length ? A.mergeReplies(got) : null);
      }, waitMs || 1200);
    });
  };
  Disco.extra = [];

  Disco.close = function (w) {
    if (Disco.window === w) Disco.window = null;
    const list = [];
    Object.keys(w.replies).forEach(ip => {
      const m = A.mergeReplies(w.replies[ip]);
      if (!m) return;
      m.at = Date.now();
      Disco.live[ip] = m;
      list.push(m);
      Disco.match(m);
    });
    w.waiters.forEach(fn => fn(list));
    RT.changed('poll');
  };

  Disco.match = function (m) {
    const n = Store.byMac(m.mac) || Store.nodes().find(x => x.ip === m.ip) || null;
    if (!n) return null;
    RT.poll[n.id] = m;
    markOnline(n, 'artnet', { ip: m.ip });
    let dirty = false;
    if (m.mac && !n.mac && n.ip === m.ip) { n.mac = m.mac; dirty = true; }
    if (dirty) Store.save();
    return n;
  };

  /** Réponses Art-Net qui ne correspondent à aucun node du parc */
  Disco.unknown = function () {
    const out = [];
    const now = Date.now();
    Object.keys(Disco.live).forEach(ip => {
      const m = Disco.live[ip];
      if (now - m.at > 60000) return;
      const known = Store.byMac(m.mac) || Store.nodes().find(x => x.ip === m.ip);
      if (!known) out.push(m);
    });
    return out;
  };

  Disco.onUdp = function (u8, ip) {
    const op = A.opcode(u8);
    if (op === A.OP.POLL_REPLY) {
      const r = A.parsePollReply(u8, ip);
      if (!r) return;
      Disco.extra.forEach(fn => fn(r));
      if (Disco.window) {
        (Disco.window.replies[r.ip] = Disco.window.replies[r.ip] || []).push(r);
      } else {
        // réponse spontanée (après ArtAddress par exemple)
        const m = A.mergeReplies([r]);
        m.at = Date.now();
        if (!Disco.live[r.ip] || (Disco.live[r.ip].binds || [0]).length <= 1) {
          Disco.live[r.ip] = m;
          Disco.match(m);
          RT.changed('poll');
        }
      }
    } else if (op === A.OP.IP_PROG_REPLY) {
      const r = A.parseIpProgReply(u8);
      Disco.ipProg.forEach(fn => fn(r, ip));
    }
  };

  // ================================================================ présence (port 80)
  const Probe = { timer: null, running: false };
  root.Probe = Probe;
  Probe.start = function () {
    clearInterval(Probe.timer);
    Probe.timer = setInterval(() => Probe.tick(), 2000);
    setTimeout(() => Probe.tick(true), 1500);
  };
  Probe.tick = async function (force) {
    if (Probe.running || document.hidden) return;
    const s = Store.settings();
    const now = Date.now();
    const due = Store.nodes().filter(n => U.isIp(n.ip) && !RT.busy[n.id] && (force || !RT.probe[n.id] || now - RT.probe[n.id].at > s.probeEvery * 1000) &&
      !(RT.online[n.id] && RT.online[n.id].via === 'artnet' && now - RT.online[n.id].at < 8000));
    if (!due.length) return;
    Probe.running = true;
    try {
      await U.pool(due, 4, async n => {
        const r = await Bridge.tcpProbe(n.ip, 80, 1200).catch(() => ({ open: false }));
        RT.probe[n.id] = { at: Date.now(), open: r.open, ms: r.ms };
        if (r.open) markOnline(n, 'tcp', { ms: r.ms, ip: n.ip });
      });
    } finally {
      Probe.running = false;
      RT.changed('probe');
    }
  };
  Probe.one = async function (n) {
    const r = await Bridge.tcpProbe(n.ip, 80, 1500).catch(() => ({ open: false }));
    RT.probe[n.id] = { at: Date.now(), open: r.open, ms: r.ms };
    if (r.open) markOnline(n, 'tcp', { ms: r.ms, ip: n.ip });
    RT.changed('probe');
    return r.open;
  };

  // ================================================================ pages (réseau : WebView ; USB : iframe locale)
  /** Page d'un node chargée par le réseau (WebView Android, iframe en démo) */
  class RemotePage {
    constructor(sid) {
      this.sid = sid;
      this.waiters = [];
      RemotePage.all[sid] = this;
      this.events = [];
    }
    onEvent(type, d) {
      this.events.push({ type, d, at: Date.now() });
      if (this.events.length > 40) this.events.shift();
      if (type === 'started') this.navigating = true;
      if (type === 'finished') this.navigating = false;
      if (type === 'hidden') this.visible = false;
      this.waiters.slice().forEach(w => w(type, d));
    }
    waitFor(types, timeout) {
      return new Promise((resolve, reject) => {
        const w = (type, d) => {
          if (types.indexOf(type) < 0) return;
          done();
          if (type === 'error') reject(new Error('page injoignable : ' + (d && d.message || '')));
          else if (type === 'auth') reject(new Error('identifiants HTTP refusés'));
          else resolve(type);
        };
        const t = setTimeout(() => { done(); reject(new Error('la page ne répond pas (délai dépassé)')); }, timeout);
        const done = () => { clearTimeout(t); const i = this.waiters.indexOf(w); if (i >= 0) this.waiters.splice(i, 1); };
        this.waiters.push(w);
      });
    }
    /**
     * Après un clic : attend un éventuel rechargement de la page (début dans les "startWait" ms),
     * puis sa fin. Tient compte des événements déjà arrivés.
     */
    async settle(since, startWait, loadTimeout) {
      const find = (type, after) => this.events.find(e => e.type === type && e.at >= after);
      const t0 = Date.now();
      let st = find('started', since);
      while (!st && Date.now() - t0 < startWait) { await U.sleep(60); st = find('started', since); }
      if (!st) return 'none';
      while (Date.now() - t0 < startWait + loadTimeout) {
        if (find('finished', st.at) || find('error', st.at)) return 'loaded';
        await U.sleep(60);
      }
      return 'timeout';
    }
    async open(url, user, pass, timeout) {
      const p = this.waitFor(['finished', 'error', 'auth'], timeout);
      Bridge.pageOpen(this.sid, url, user, pass);
      await p;
    }
    eval(js) { return Bridge.pageEval(this.sid, js); }
    show(on, title) { this.visible = !!on; Bridge.pageShow(this.sid, on, title); }
    close() { Bridge.pageClose(this.sid); delete RemotePage.all[this.sid]; }
  }
  RemotePage.all = {};
  root.RemotePage = RemotePage;

  /** Interface web embarquée du node, chargée par USB (fichiers HID) dans une iframe locale */
  class LocalFrame {
    constructor() {
      this.wrap = document.createElement('div');
      this.wrap.className = 'guihost';
      this.wrap.innerHTML = '<div class="simbar"><span>Interface du node (USB)</span><button type="button" class="gclose">Fermer</button></div><iframe></iframe>';
      document.body.appendChild(this.wrap);
      this.el = this.wrap.querySelector('iframe');
      this.wrap.querySelector('.gclose').onclick = () => this.show(false);
      this.waiters = [];
      this.el.addEventListener('load', () => { this.waiters.slice().forEach(w => w('finished')); });
    }
    waitFor(types, timeout) {
      return new Promise((resolve, reject) => {
        const w = type => { if (types.indexOf(type) >= 0) { done(); resolve(type); } };
        const t = setTimeout(() => { done(); reject(new Error('l\'interface du node ne se charge pas')); }, timeout);
        const done = () => { clearTimeout(t); const i = this.waiters.indexOf(w); if (i >= 0) this.waiters.splice(i, 1); };
        this.waiters.push(w);
      });
    }
    async load(html, timeout) {
      const p = this.waitFor(['finished'], timeout || 15000);
      this.el.srcdoc = html;
      await p;
    }
    async settle() { await U.sleep(900); return 'none'; }
    eval(js) {
      try {
        const v = this.el.contentWindow.eval(js);
        return Promise.resolve(v === undefined ? null : v);
      } catch (e) { return Promise.reject(e); }
    }
    show(on) {
      this.wrap.classList.toggle('show', !!on);
      if (on) UsbGui.visible = true; else UsbGui.visible = false;
      RT.changed('gui');
    }
    close() { this.wrap.remove(); }
  }

  /** Lecture / écriture dans une page de node (réseau ou USB) avec le script injecté */
  class PageDriver {
    constructor(page, node) { this.page = page; this.node = node; this.log = () => {}; }
    async inject() {
      for (let i = 0; i < 3; i++) {
        try {
          const r = await this.page.eval(Scraper.SCRIPT);
          if (r === 'ok') return;
        } catch (e) { /* page en cours de chargement */ }
        await U.sleep(300);
      }
      throw new Error('script de lecture refusé par la page');
    }
    async scanOnce() {
      await this.inject();
      const s = await this.page.eval('window.__NP.scan()');
      return typeof s === 'string' ? JSON.parse(s) : s;
    }
    /** Attend que la page ait fini de remplir ses champs */
    async scan(timeout) {
      const t0 = Date.now();
      let prev = null, stable = 0, last = null;
      while (Date.now() - t0 < (timeout || 8000)) {
        try {
          last = await this.scanOnce();
          if (last.isLogin) return last;
          const sig = JSON.stringify(last.fields.map(f => [f.key, f.value]));
          if (last.fields.length && sig === prev) { if (++stable >= 1) return last; } else stable = 0;
          prev = sig;
        } catch (e) { last = null; }
        await U.sleep(450);
      }
      if (last && last.fields.length) return last;
      throw new Error('aucun réglage trouvé dans la page' + (last && last.title ? ' « ' + last.title + ' »' : ''));
    }
    async login(user, pass) {
      this.log('Page de login : connexion…');
      const at = Date.now();
      await this.page.eval('window.__NP.login(' + JSON.stringify(user || '') + ',' + JSON.stringify(pass || '') + ')');
      await this.page.settle(at, 2500, 8000);
      await U.sleep(300);
      const s = await this.scan(6000);
      if (s.isLogin) throw new Error('identifiant ou mot de passe refusé par le node');
      return s;
    }
    async set(changes) {
      const r = await this.page.eval('window.__NP.set(' + JSON.stringify(JSON.stringify(changes)) + ')');
      return typeof r === 'string' ? JSON.parse(r) : r;
    }
    async click(pattern, exclude) {
      const r = await this.page.eval('window.__NP.click(' + JSON.stringify(pattern) + ',' + JSON.stringify(exclude || '') + ')');
      return (typeof r === 'string' ? JSON.parse(r) : r).clicked;
    }
  }
  root.PageDriver = PageDriver;

  // ================================================================ session USB
  const USB = { dev: null, h: null, client: null, info: null, state: 'none', error: '', nodeId: null, dfuDev: null, waiters: [] };
  root.USB = USB;

  USB.isEc = d => d && d.vid === H.VID && (d.interfaces || []).some(i => i.cls === 3);
  USB.isDfu = d => d && (d.interfaces || []).some(i => i.cls === 254 && i.sub === 1);
  USB.set = function (state, error) {
    USB.state = state;
    USB.error = error || '';
    RT.changed('usb');
  };

  USB.scan = function () {
    const list = Bridge.usbList();
    const ec = list.find(USB.isEc);
    const dfu = list.find(USB.isDfu);
    USB.dfuDev = dfu || null;
    return { list, ec, dfu };
  };

  USB.onEvent = function (type, d) {
    if (type === 'attached') {
      const s = USB.scan();
      RT.changed('usb');
      if (s.ec && (!USB.dev || USB.dev.name !== s.ec.name)) USB.connect(s.ec);
      if (s.dfu) USB.waiters.slice().forEach(w => w('dfu', s.dfu));
    } else if (type === 'detached') {
      if (USB.dev && d && d.name === USB.dev.name) {
        USB.close('detached');
        UI.toast('Node USB débranché');
      }
      USB.scan();
      RT.changed('usb');
      USB.waiters.slice().forEach(w => w('detached', d));
    } else if (type === 'permission') {
      USB.waiters.slice().forEach(w => w('permission', d));
      if (d && d.granted) {
        const s = USB.scan();
        if (s.ec && s.ec.name === d.name && USB.state === 'perm') USB.connect(s.ec);
      } else if (USB.state === 'perm') USB.set('error', 'Autorisation USB refusée');
    }
  };

  USB.waitEvent = function (types, timeout, filter) {
    return new Promise((resolve, reject) => {
      const w = (type, d) => {
        if (types.indexOf(type) < 0 || (filter && !filter(type, d))) return;
        done(); resolve({ type, d });
      };
      const t = setTimeout(() => { done(); reject(new Error('délai dépassé')); }, timeout);
      const done = () => { clearTimeout(t); const i = USB.waiters.indexOf(w); if (i >= 0) USB.waiters.splice(i, 1); };
      USB.waiters.push(w);
    });
  };

  USB.close = function (why) {
    if (USB.h != null) { try { Bridge.usbClose(USB.h); } catch (e) { /* déjà fermé */ } }
    USB.h = null; USB.client = null; USB.dev = null; USB.info = null; USB.nodeId = null;
    if (UsbGui.frame) { UsbGui.frame.close(); UsbGui.frame = null; UsbGui.loaded = false; }
    USB.set(why === 'detached' ? 'none' : 'none');
  };

  /** Ouvre le node branché et lit tous ses réglages */
  USB.connect = async function (dev) {
    if (USB.busy) return;
    USB.busy = true;
    try {
      USB.close();
      USB.dev = dev;
      if (!dev.permission) {
        USB.set('perm');
        Bridge.usbPermission(dev.name);
        const ev = await USB.waitEvent(['permission'], 60000, (t, d) => d && d.name === dev.name).catch(() => null);
        if (!ev || !ev.d.granted) { USB.set('error', 'Autorisation USB refusée'); return; }
      }
      USB.set('opening');
      USB.h = Bridge.hidOpen(dev.name);
      const h = USB.h;
      USB.client = new H.Client({ xfer: u8 => Bridge.hidXfer(h, u8, 900), flush: () => Bridge.hidFlush(h) }, { retries: 2 });
      await USB.read();
    } catch (e) {
      USB.set('error', e.message);
    } finally {
      USB.busy = false;
    }
  };

  /** (Re)lit la table du node USB ; renvoie le résultat de lecture */
  USB.read = async function (progress) {
    if (!USB.client) throw new Error('aucun node USB');
    USB.set('reading');
    const table = await USB.client.readAll(progress);
    const web = await USB.client.hasWebInterface();
    const info = { product: table.name, table, web, at: Date.now(), via: 'usb' };
    if (table.params.length) {
      const node = USB.nodeId ? Store.node(USB.nodeId) : null;
      info.mapped = M.mapTable(table, { sacnBase: node ? node.sacnBase : 'auto' });
      info.kind = 'table';
    } else if (web) {
      info.kind = 'gui';
      const sc = await UsbGui.scan();
      info.scan = sc;
      info.guiTable = Scraper.toTable(sc);
      info.mapped = M.mapTable(info.guiTable);
    } else {
      info.kind = 'empty';
    }
    USB.info = info;
    const canon = info.mapped ? info.mapped.canon : {};
    info.serial = canon.serial || (USB.dev && USB.dev.serial) || '';
    // association au parc : par numéro de série
    const n = (info.serial && Store.bySerial(info.serial)) || (USB.nodeId && Store.node(USB.nodeId)) || null;
    USB.nodeId = n ? n.id : null;
    if (n) USB.record(n);
    USB.set('ready');
    return info;
  };

  /** Enregistre la lecture USB dans la fiche du node associé */
  USB.record = function (n) {
    const info = USB.info;
    if (!info || !info.mapped) return;
    Store.recordRead(n, {
      at: info.at, via: 'usb', canon: U.clone(info.mapped.canon), ports: info.mapped.ports, product: info.product,
      family: info.mapped.family, kind: info.kind, sacnBase: info.mapped.sacnBase,
      raw: compactTable(info.kind === 'gui' ? info.guiTable : info.table)
    });
  };

  USB.associate = function (n) {
    USB.nodeId = n.id;
    if (USB.info && USB.info.serial && n.serial !== USB.info.serial) n.serial = USB.info.serial;
    USB.record(n);
    Store.log(n, 'Associé au node USB ' + (USB.info ? USB.info.product : ''), true);
    RT.changed('usb');
  };

  function compactTable(t) {
    if (!t) return null;
    return {
      name: t.name, groups: t.groups.map(g => ({ index: g.index, name: g.name })),
      params: t.params.map(p => ({ index: p.index, key: p.key, group: p.group, type: p.type, label: p.label, options: p.options, value: p.value, min: p.min, max: p.max, readonly: p.readonly, maxLen: p.maxLen }))
    };
  }
  root.compactTable = compactTable;

  // ---------------------------------------------------------------- interface web du node par USB
  const UsbGui = { frame: null, loaded: false, visible: false };
  root.UsbGui = UsbGui;

  /** Fonctions attendues par l'interface web embarquée (les mêmes que dmx-tools) */
  function installShims() {
    const dev = () => ({ productName: USB.info ? USB.info.product : 'Node', vendorId: H.VID, productId: H.PID, opened: true });
    root.sendHIDReportAndWaitForResponse = (device, data) => {
      if (!USB.client) return Promise.reject(new Error('node USB débranché'));
      const req = new Uint8Array(64);
      req.set(Array.from(data).slice(0, 64));
      return USB.client.raw(req);
    };
    root.getDevice = dev;
    try { Object.defineProperty(root, 'device', { get: dev, configurable: true }); } catch (e) { root.device = dev(); }
    root.downloadWebFileBinary = (device, name, progress) => {
      if (!USB.client) return Promise.resolve(null);
      return USB.client.getFile(name, progress, true).then(f => (f ? f.data : null)).catch(() => null);
    };
    root.pauseAutoUpdates = () => {};
    root.resumeAutoUpdates = () => {};
    root.openTable = () => {};
    root.resizeIframeFromContent = () => {};
    try { Object.defineProperty(root, 'MaxGroupe', { get: () => (USB.info && USB.info.table ? USB.info.table.groups.length : 0), configurable: true }); } catch (e) { root.MaxGroupe = 0; }
  }

  const mimeOf = n => ({ css: 'text/css', js: 'application/javascript', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', svg: 'image/svg+xml', ico: 'image/x-icon', webp: 'image/webp' }[(n.split('.').pop() || '').toLowerCase()] || 'application/octet-stream');

  /** Télécharge index.html et ses ressources par USB, comme dmx-tools */
  UsbGui.build = async function (progress) {
    const c = USB.client;
    const idx = await c.getFile('index.html', progress);
    if (!idx) throw new Error('ce node n\'a pas d\'interface web embarquée');
    let html = U.utf8dec(idx.data);
    const get = async name => { const f = await c.getFile(name, null, true).catch(() => null); return f ? f.data : null; };
    const css = Array.from(html.matchAll(/<link[^>]+rel=["']?stylesheet["']?[^>]*href=["']([^"']+)["'][^>]*>/gi));
    for (const m of css) {
      if (/^(https?:|data:)/.test(m[1])) continue;
      const d = await get(m[1]);
      if (d) html = html.replace(m[0], '<style>/* ' + m[1] + ' */\n' + U.utf8dec(d) + '</style>');
    }
    const js = Array.from(html.matchAll(/<script([^>]*)\ssrc=["']([^"']+)["']([^>]*)><\/script>/gi));
    for (const m of js) {
      if (/^(https?:|data:)/.test(m[2])) continue;
      const d = await get(m[2]);
      if (d) html = html.replace(m[0], '<script' + m[1] + m[3] + '>/* ' + m[2] + ' */\n' + U.utf8dec(d).replace(/<\/script/gi, '<\\/script') + '</script>');
    }
    const imgs = Array.from(html.matchAll(/<img([^>]*)\ssrc=["']([^"']+)["']/gi));
    for (const m of imgs) {
      if (/^(https?:|data:)/.test(m[2])) continue;
      const d = await get(m[2]);
      if (d) html = html.replace(m[0], '<img' + m[1] + ' src="data:' + mimeOf(m[2]) + ';base64,' + U.toB64(d) + '"');
    }
    return html;
  };

  UsbGui.ensure = async function (progress) {
    if (!USB.client) throw new Error('aucun node USB');
    installShims();
    if (UsbGui.frame && UsbGui.loaded) return UsbGui.frame;
    if (!UsbGui.frame) UsbGui.frame = new LocalFrame();
    const html = await UsbGui.build(progress);
    await UsbGui.frame.load(html);
    UsbGui.loaded = true;
    return UsbGui.frame;
  };
  UsbGui.driver = async function () {
    const f = await UsbGui.ensure();
    return new PageDriver(f, null);
  };
  UsbGui.scan = async function () {
    const d = await UsbGui.driver();
    return d.scan(10000);
  };
  UsbGui.show = async function () {
    const f = await UsbGui.ensure();
    f.show(true);
  };

  // ================================================================ lecture / écriture des réglages
  const Ops = {};
  root.Ops = Ops;

  Ops.VIA = { usb: 'USB', web: 'page web', artnet: 'Art-Net' };

  /** Chemins possibles pour un node, du meilleur au moins bon */
  Ops.routes = function (n) {
    const r = [];
    if (USB.state === 'ready' && USB.nodeId === n.id) r.push('usb');
    if (U.isIp(n.ip) && (RT.isOnline(n) || !RT.online[n.id])) r.push('web');
    if (RT.poll[n.id] || U.isIp(n.ip)) r.push('artnet');
    return r;
  };
  Ops.pick = function (n, pref) {
    if (pref && pref !== 'auto') return pref;
    const r = Ops.routes(n);
    return r[0] || 'web';
  };

  Ops.pageFor = function (n) {
    const sid = 'node_' + n.id;
    return RemotePage.all[sid] || new RemotePage(sid);
  };
  /** Libère la page d'un node après une opération (une WebView par node coûte de la mémoire) */
  Ops.release = function (n) {
    const p = RemotePage.all['node_' + n.id];
    if (p && !p.visible) p.close();
  };
  Ops.creds = function (n) {
    const s = Store.settings();
    return { user: (n.login && n.login.user) || s.defaultUser || 'admin', pass: (n.login && n.login.pass != null && n.login.pass !== '' ? n.login.pass : (Store.wanted(n).pass || s.defaultPass || '')) };
  };

  /** Ouvre la page du node, se connecte si besoin, lit les champs */
  Ops.webScan = async function (n, log) {
    const s = Store.settings();
    const page = Ops.pageFor(n);
    const drv = new PageDriver(page, n);
    drv.log = log || (() => {});
    const cr = Ops.creds(n);
    drv.log('Ouverture de http://' + n.ip + '/ …');
    await page.open('http://' + n.ip + '/', cr.user, cr.pass, s.webTimeout * 1000);
    let scan = await drv.scan(8000);
    if (scan.isLogin) scan = await drv.login(cr.user, cr.pass);
    markOnline(n, 'tcp', { ip: n.ip });
    return { page, drv, scan };
  };

  function buildRecord(n, via, table, mapped, extra) {
    return Object.assign({ at: Date.now(), via, canon: U.clone(mapped.canon), ports: mapped.ports, product: table.name || n.product || '', family: mapped.family, sacnBase: mapped.sacnBase, raw: compactTable(table) }, extra || {});
  }

  /** Lit un node ; renvoie { via, canon, mapped, table } */
  Ops.read = async function (n, via, log) {
    log = log || (() => {});
    via = Ops.pick(n, via);
    RT.busy[n.id] = 'lecture';
    RT.changed('busy');
    try {
      if (via === 'usb') {
        if (USB.nodeId !== n.id) throw new Error('ce node n\'est pas branché en USB');
        log('Lecture USB…');
        const info = await USB.read();
        Store.log(n, 'Lecture USB', true);
        return { via, canon: info.mapped ? info.mapped.canon : {}, mapped: info.mapped, table: info.table };
      }
      if (via === 'web') {
        const { scan, drv } = await Ops.webScan(n, log);
        void drv;
        const table = Scraper.toTable(scan);
        const mapped = M.mapTable(table, { sacnBase: n.sacnBase });
        if (!Object.keys(mapped.refs).length) throw new Error('la page ne ressemble pas à une page de node (aucun réglage reconnu)');
        Store.recordRead(n, buildRecord(n, 'web', table, mapped, { url: scan.url, scanText: Scraper.describe(scan) }));
        Store.log(n, 'Lecture par la page web', true, Object.keys(mapped.refs).length + ' réglages reconnus');
        return { via, canon: mapped.canon, mapped, table };
      }
      // Art-Net : lecture partielle, gardée à part
      log('Interrogation Art-Net…');
      const m = await Disco.pollOne(n.ip, 1500);
      if (!m) throw new Error('aucune réponse Art-Net de ' + n.ip);
      RT.poll[n.id] = m;
      markOnline(n, 'artnet', { ip: m.ip });
      if (m.mac && !n.mac) { n.mac = m.mac; Store.save(); }
      return { via: 'artnet', canon: M.fromPoll(m), partial: true };
    } catch (e) {
      Store.log(n, 'Lecture (' + Ops.VIA[via] + ')', false, e.message);
      throw e;
    } finally {
      if (via === 'web') Ops.release(n);
      delete RT.busy[n.id];
      RT.changed('busy');
    }
  };

  /** Sépare les changements d'adresse IP (à faire en dernier) */
  function splitIp(target) {
    const t = U.clone(target || {});
    const ip = {};
    ['ip', 'mask', 'gateway', 'ipMode'].forEach(k => { if (t[k] !== undefined) { ip[k] = t[k]; delete t[k]; } });
    return { main: t, ip };
  }

  /** Vérifie le résultat : liste des écarts restants entre "target" et la config relue */
  function verify(target, canon) {
    return M.diff(target, canon);
  }

  /**
   * Écrit "target" (config partielle) dans le node. Renvoie un compte rendu :
   * { ok, via, changes:[{path,label,from,to}], errors:[], missing:[], remaining:[diff], notes:[] }
   */
  Ops.apply = async function (n, target, via, log) {
    log = log || (() => {});
    via = Ops.pick(n, via);
    const s = Store.settings();
    const rep = { ok: false, via, changes: [], errors: [], missing: [], remaining: [], notes: [] };
    const problems = M.validate(Object.assign(Store.wanted(n), target)).filter(p => p.level === 'err');
    if (problems.length) { rep.errors = problems.map(p => p.msg); return rep; }
    RT.busy[n.id] = 'écriture';
    RT.changed('busy');
    try {
      if (via === 'usb') await applyUsb(n, target, rep, log, s);
      else if (via === 'web') await applyWeb(n, target, rep, log, s);
      else await applyArtnet(n, target, rep, log, s);
      rep.ok = !rep.errors.length && !rep.remaining.length;
      Store.log(n, 'Écriture (' + Ops.VIA[via] + ')', rep.ok, rep.ok ? rep.changes.length + ' réglage(s)' : (rep.errors.concat(rep.remaining.map(r => r.label + ' : voulu ' + r.want + ', lu ' + r.have))).join(' ; '));
    } catch (e) {
      rep.errors.push(e.message);
      Store.log(n, 'Écriture (' + Ops.VIA[via] + ')', false, e.message);
    } finally {
      if (via === 'web') Ops.release(n);
      delete RT.busy[n.id];
      RT.changed('busy');
    }
    return rep;
  };

  function describeChanges(changes, mapped) {
    return changes.map(c => {
      const p = c.param;
      const fmt = v => (p.type === 4 ? (p.options[v] != null ? p.options[v] : v) : v);
      return { path: c.path, label: M.pathLabel(c.path), from: fmt(p.value), to: fmt(c.value) };
    });
  }

  async function applyUsb(n, target, rep, log, s) {
    if (USB.nodeId !== n.id || USB.state !== 'ready') throw new Error('ce node n\'est pas branché en USB');
    if (USB.info.kind === 'gui') return applyPage(n, target, rep, log, await UsbGui.driver(), true);
    const mapped = USB.info.mapped;
    const ch = M.changesFor(mapped, target);
    rep.errors.push(...ch.errors);
    rep.missing = ch.missing;
    if (ch.errors.length) return;
    rep.changes = describeChanges(ch.changes, mapped);
    if (!ch.changes.length) { log('Rien à changer : le node est déjà comme prévu.'); }
    else if (s.usbAllParams) {
      log('Envoi de tous les paramètres (comme dmx-tools)…');
      ch.changes.forEach(c => { c.param.value = c.value; });
      await USB.client.applyAllLikeDmxTools(mapped.byIndex ? Object.values(mapped.byIndex) : USB.info.table.params);
    } else {
      log('Envoi de ' + U.plural(ch.changes.length, 'réglage') + ' par USB…');
      const r = await USB.client.apply(ch.changes.map(c => ({ param: c.param, value: c.value })));
      r.filter(x => !x.ok).forEach(x => log('  ' + x.label + ' : relu ' + x.got + ' au lieu de ' + x.wanted, 'warn'));
    }
    log('Relecture complète…');
    const info = await USB.read();
    rep.remaining = verify(target, info.mapped.canon);
    if (!rep.remaining.length) log('Vérifié : le node a bien pris les réglages.', 'ok');
  }

  async function applyWeb(n, target, rep, log, s) {
    const { drv } = await Ops.webScan(n, log);
    return applyPage(n, target, rep, log, drv, false);
  }

  /** Écriture par une page (réseau ou interface USB) : remplir, Appliquer, relire */
  async function applyPage(n, target, rep, log, drvIn, viaUsbGui) {
    let drv = drvIn;
    const s = Store.settings();
    drv.log = log;
    const parts = viaUsbGui ? { main: target, ip: {} } : splitIp(target);
    const steps = [parts.main];
    if (Object.keys(parts.ip).length) steps.push(parts.ip);
    let canon = null;
    for (let k = 0; k < steps.length; k++) {
      const step = steps[k];
      const isIpStep = k > 0;
      let scan = await drv.scan(8000);
      if (scan.isLogin) { const cr = Ops.creds(n); scan = await drv.login(cr.user, cr.pass); }
      const table = Scraper.toTable(scan);
      const mapped = M.mapTable(table, { sacnBase: n.sacnBase });
      const ch = M.changesFor(mapped, step);
      rep.errors.push(...ch.errors);
      rep.missing.push(...ch.missing);
      if (ch.errors.length) return;
      if (!ch.changes.length) { if (!isIpStep) canon = mapped.canon; continue; }
      rep.changes.push(...describeChanges(ch.changes, mapped));
      log('Remplissage de ' + U.plural(ch.changes.length, 'champ') + '…');
      const res = await drv.set(ch.changes.map(c => ({ key: c.param.key, value: c.value })));
      if (res.missing && res.missing.length) throw new Error('champs introuvables dans la page : ' + res.missing.join(', '));
      const clickAt = Date.now();
      const clicked = await drv.click(s.webApply || Scraper.APPLY, Scraper.APPLY_EXCLUDE);
      if (!clicked) throw new Error('bouton « Appliquer » introuvable dans la page');
      log('Clic sur « ' + clicked + ' »…');
      if (isIpStep) {
        // le node change d'adresse : on vérifie à la nouvelle adresse
        await U.sleep(1500);
        const newIp = step.ipMode === 'dhcp' ? null : (step.ip || n.ip);
        if (newIp && newIp !== n.ip) {
          log('Nouvelle adresse : ' + newIp + ' (vérification…)');
          const old = n.ip;
          n.ip = newIp;
          Store.save();
          await U.sleep(2500);
          try {
            const r2 = await Ops.webScan(n, log);
            const m2 = M.mapTable(Scraper.toTable(r2.scan), { sacnBase: n.sacnBase });
            Store.recordRead(n, buildRecord(n, 'web', Scraper.toTable(r2.scan), m2));
            rep.remaining.push(...verify(step, m2.canon));
          } catch (e) {
            rep.notes.push('Adresse changée (' + old + ' → ' + newIp + ') : vérification impossible pour l\'instant (' + e.message + ')');
          }
        } else if (step.ipMode === 'dhcp') {
          rep.notes.push('Le node est passé en DHCP : son adresse va changer, retrouve-le par la recherche Art-Net.');
        }
        continue;
      }
      const ev = await drv.page.settle(clickAt, 1800, s.webTimeout * 1000);
      if (ev === 'none') await U.sleep(300);
      await U.sleep(300);
      let after;
      try {
        after = await drv.scan(8000);
      } catch (e) {
        if (viaUsbGui) throw e;
        // certains nodes redémarrent après Appliquer : on rouvre la page
        log('La page ne répond plus (le node redémarre ?), nouvelle tentative…', 'warn');
        await U.sleep(3500);
        const again = await Ops.webScan(n, log);
        drv = again.drv;
        drv.log = log;
        after = again.scan;
      }
      if (after.alerts && after.alerts.length) log('Message du node : ' + after.alerts.join(' / '));
      if (after.isLogin) { const cr = Ops.creds(n); await drv.login(cr.user, cr.pass); }
      const at = Scraper.toTable(after.isLogin ? await drv.scan(6000) : after);
      const m2 = M.mapTable(at, { sacnBase: n.sacnBase });
      canon = m2.canon;
      if (viaUsbGui) { USB.info.scan = after; USB.info.guiTable = at; USB.info.mapped = m2; USB.info.at = Date.now(); USB.record(n); }
      else Store.recordRead(n, buildRecord(n, 'web', at, m2, { url: after.url }));
      rep.remaining.push(...verify(step, canon));
    }
    if (!rep.remaining.length && !rep.errors.length) log('Vérifié : la page affiche bien les nouveaux réglages.', 'ok');
  }

  async function applyArtnet(n, target, rep, log, s) {
    if (!s.artnetWrite) throw new Error('écriture Art-Net désactivée dans les réglages');
    const before = RT.poll[n.id] || await Disco.pollOne(n.ip, 1500);
    if (!before) throw new Error('le node ne répond pas en Art-Net');
    const flat = M.flat(target);
    const supported = ['shortName', 'longName', 'protocol', 'ip', 'mask', 'ipMode'];
    const packets = [];
    const ports = [];
    let command = 0;
    Object.keys(flat).forEach(path => {
      const m = /^ports\.(\d+)\.(\w+)$/.exec(path);
      if (m) {
        const p = before.ports[+m[1]];
        if (!p) { rep.missing.push(path); return; }
        if (m[2] === 'univOut' || m[2] === 'univIn') {
          if ((target.protocol || M.fromPoll(before).protocol) === 'sacn') { rep.missing.push(path); return; }
          let e = ports.find(x => x.index === p.index);
          if (!e) { e = { index: p.index, slot: p.slot, bindIndex: p.bindIndex }; ports.push(e); }
          e[m[2]] = flat[path];
        } else if (m[2] === 'dir') {
          packets.push(A.buildAddress({ bindIndex: p.bindIndex || 0, command: (flat[path] === 'in' ? A.AC.DIRECTION_RX : A.AC.DIRECTION_TX) + ((p.slot != null ? p.slot : p.index) & 3) }));
        } else rep.missing.push(path);
      } else if (supported.indexOf(path) < 0) rep.missing.push(path);
    });
    if (ports.length) {
      const plan = A.planUniverses(ports);
      if (plan.error) { rep.errors.push(plan.error); return; }
      packets.push(...plan.packets);
    }
    if (flat.protocol) command = flat.protocol === 'sacn' ? A.AC.ACN_SEL : A.AC.ARTNET_SEL;
    if (flat.shortName || flat.longName || command) packets.unshift(A.buildAddress({ shortName: flat.shortName, longName: flat.longName, command }));
    const ipTarget = {};
    if (flat.ipMode === 'dhcp') ipTarget.dhcp = true;
    else { if (flat.ip) ipTarget.ip = flat.ip; if (flat.mask) ipTarget.mask = flat.mask; }
    rep.changes = Object.keys(flat).filter(p => rep.missing.indexOf(p) < 0).map(p => ({ path: p, label: M.pathLabel(p), from: '', to: flat[p] }));
    if (!packets.length && !Object.keys(ipTarget).length) return;
    log('Envoi de ' + U.plural(packets.length, 'paquet') + ' ArtAddress…');
    for (const pk of packets) { Bridge.udpSend(n.ip, A.PORT, pk); await U.sleep(60); }
    await U.sleep(500);
    let after = await Disco.pollOne(n.ip, 1500);
    if (after) {
      RT.poll[n.id] = after;
      const c = M.fromPoll(after);
      const subset = {};
      Object.keys(flat).forEach(k => { if (!/^(ip|mask|ipMode)$/.test(k) && rep.missing.indexOf(k) < 0) M.setPath(subset, k, flat[k]); });
      rep.remaining = verify(subset, c);
      if (rep.remaining.length) rep.notes.push('Le node ne semble pas gérer la configuration Art-Net standard (ArtAddress) : passe par la page web ou l\'USB.');
    } else rep.errors.push('plus de réponse Art-Net après l\'envoi');
    if (Object.keys(ipTarget).length) {
      log('Envoi ArtIpProg…');
      const got = new Promise(resolve => {
        const fn = (r, ip) => { if (ip === n.ip) { done(); resolve(r); } };
        const t = setTimeout(() => { done(); resolve(null); }, 2000);
        const done = () => { clearTimeout(t); const i = Disco.ipProg.indexOf(fn); if (i >= 0) Disco.ipProg.splice(i, 1); };
        Disco.ipProg.push(fn);
      });
      Bridge.udpSend(n.ip, A.PORT, A.buildIpProg(ipTarget));
      const r = await got;
      if (!r) rep.notes.push('Pas de réponse ArtIpProg : le node ne gère sans doute pas le changement d\'adresse par Art-Net.');
      else {
        if (ipTarget.ip && r.ip !== ipTarget.ip) rep.remaining.push({ path: 'ip', label: 'Adresse IP', want: ipTarget.ip, have: r.ip });
        if (ipTarget.mask && r.mask !== ipTarget.mask) rep.remaining.push({ path: 'mask', label: 'Masque', want: ipTarget.mask, have: r.mask });
        if (ipTarget.ip && r.ip === ipTarget.ip) { n.ip = r.ip; Store.save(); }
      }
    }
    void after;
  }

  /** Actions : 'identify' | 'reset' | 'dfu' */
  Ops.action = async function (n, act, via, log) {
    log = log || (() => {});
    if (act === 'identify') {
      if (!U.isIp(n.ip)) throw new Error('adresse IP inconnue');
      Bridge.udpSend(n.ip, A.PORT, A.buildAddress({ command: A.AC.LED_LOCATE }));
      setTimeout(() => Bridge.udpSend(n.ip, A.PORT, A.buildAddress({ command: A.AC.LED_NORMAL })), 10000);
      Store.log(n, 'Identification (Art-Net)', true);
      return 'Demande d\'identification envoyée (si le node la gère, sa LED clignote 10 s).';
    }
    via = Ops.pick(n, via);
    if (via === 'usb') {
      if (USB.nodeId !== n.id) throw new Error('ce node n\'est pas branché en USB');
      return USB.action(act, log, n);
    }
    if (via === 'web') {
      const { drv } = await Ops.webScan(n, log);
      const scan = await drv.scan(6000);
      const table = Scraper.toTable(scan);
      const mapped = M.mapTable(table);
      if (mapped.actions[act] != null) {
        const p = table.params[mapped.actions[act]];
        await drv.set([{ key: p.key, value: M.actionValue(p, true) }]);
        const clicked = await drv.click(Store.settings().webApply || Scraper.APPLY, Scraper.APPLY_EXCLUDE);
        if (!clicked) throw new Error('bouton « Appliquer » introuvable');
      } else {
        const clicked = await drv.click(act === 'reset' ? '(reset|usine|factory)' : '^\\s*dfu\\s*$');
        if (!clicked) throw new Error(act === 'dfu' ? 'cette page ne propose pas le mode DFU' : 'cette page ne propose pas de remise à zéro');
      }
      Ops.release(n);
      Store.log(n, act === 'reset' ? 'Reset usine (page web)' : 'Passage en DFU (page web)', true);
      return act === 'reset' ? 'Reset usine envoyé.' : 'Le node redémarre en mode DFU.';
    }
    throw new Error('action impossible en Art-Net');
  };

  USB.action = async function (act, log, n) {
    const info = USB.info;
    if (!info) throw new Error('aucun node USB');
    if (info.kind === 'table') {
      const idx = info.mapped.actions[act];
      if (idx == null) throw new Error(act === 'dfu' ? 'ce firmware ne propose pas le mode DFU par USB' : 'ce firmware ne propose pas de remise à zéro');
      const p = info.table.params.find(x => x.index === idx);
      try {
        await USB.client.writeValue(p, M.actionValue(p, true));
      } catch (e) {
        // le node redémarre aussitôt : pas de réponse, c'est normal
        if (!/timeout|répond|fermé|USB|débranché/i.test(e.message)) throw e;
        if (log) log('Le node a coupé l\'USB pour redémarrer (normal).');
      }
    } else if (info.kind === 'gui') {
      const drv = await UsbGui.driver();
      const clicked = await drv.click(act === 'reset' ? '(reset|usine|factory)' : '^\\s*dfu\\s*$');
      if (!clicked) throw new Error(act === 'dfu' ? 'l\'interface du node ne propose pas le mode DFU' : 'l\'interface du node ne propose pas de remise à zéro');
    } else throw new Error('ce node ne propose aucun réglage par USB');
    if (n) Store.log(n, act === 'reset' ? 'Reset usine (USB)' : 'Passage en DFU (USB)', true);
    if (act === 'reset') { await U.sleep(800); await USB.read().catch(() => null); }
    return act === 'reset' ? 'Le node est revenu aux réglages d\'usine.' : 'Le node redémarre en mode DFU.';
  };

  // ================================================================ mise à jour du firmware (DFU)
  const Fw = {};
  root.Fw = Fw;

  /** Attend qu'un périphérique DFU apparaisse */
  Fw.waitDfu = async function (timeoutMs, ctl) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      if (ctl && ctl.cancelled) throw new Error('annulé');
      const s = USB.scan();
      if (s.dfu) return s.dfu;
      await U.sleep(400);
    }
    return null;
  };

  /** Ouvre le périphérique DFU et lit ses caractéristiques */
  Fw.openDfu = async function (dev) {
    if (!dev.permission) {
      Bridge.usbPermission(dev.name);
      const ev = await USB.waitEvent(['permission'], 60000, (t, d) => d && d.name === dev.name).catch(() => null);
      if (!ev || !ev.d.granted) throw new Error('autorisation USB refusée');
    }
    const iface = dev.interfaces.find(i => i.cls === 254 && i.sub === 1);
    const h = Bridge.usbOpenRaw(dev.name, iface.id);
    const raw = Bridge.usbRawDescriptors(h);
    const found = DFU.findInterfaces(raw);
    const fi = found.find(x => x.iface === iface.id && x.alt === (iface.alt || 0)) || found[0] || { func: null };
    const func = fi.func || { transferSize: 1024, canDnload: true, manifestTolerant: false, version: 0x0110 };
    const dfuse = func.version === 0x011a;
    const layout = dfuse ? DFU.parseDfuseLayout(iface.label || '') : null;
    return { h, dev, iface: iface.id, func, dfuse, layout, raw, vid: dev.vid, pid: dev.pid };
  };

  /**
   * Mise à jour complète d'un node branché en USB.
   * file = { name, bytes } ; ctl = fenêtre de progression
   */
  Fw.update = async function (n, file, ctl) {
    const parsed = DFU.parseFile(file.bytes, file.name);
    ctl.log('Fichier : ' + file.name + ' (' + Math.round(parsed.size / 1024) + ' Ko, ' + parsed.kind + ')');
    const oldFw = (USB.info && USB.info.mapped && USB.info.mapped.canon.firmware) || n.firmware || '';
    // 1. passage en DFU
    let dfuDev = USB.scan().dfu;
    if (!dfuDev) {
      if (USB.state !== 'ready' || USB.nodeId !== n.id) throw new Error('branche d\'abord ce node en USB (il doit être reconnu dans l\'onglet USB)');
      ctl.set(0.05, 'Passage du node en mode DFU…');
      await USB.action('dfu', ctl.log, n);
      ctl.log('Attente du mode DFU…');
      dfuDev = await Fw.waitDfu(20000, ctl);
      if (!dfuDev) {
        const list = Bridge.usbList();
        ctl.log('Périphériques USB vus : ' + (list.map(d => d.vid.toString(16) + ':' + d.pid.toString(16) + ' ' + (d.product || '') + ' [' + (d.interfaces || []).map(i => i.cls + '/' + i.sub).join(',') + ']').join(' ; ') || 'aucun'), 'warn');
        throw new Error('le node n\'est pas apparu en mode DFU standard (voir l\'inspecteur USB)');
      }
    }
    ctl.set(0.1, 'Ouverture du mode DFU…');
    const d = await Fw.openDfu(dfuDev);
    ctl.log('Mode DFU : ' + dfuDev.vid.toString(16).padStart(4, '0') + ':' + dfuDev.pid.toString(16).padStart(4, '0') + ', blocs de ' + d.func.transferSize + ' octets' + (d.dfuse ? ', DfuSe' : ''));
    const checks = DFU.check(parsed, d);
    checks.forEach(c => ctl.log(c.msg, c.level === 'err' ? 'err' : 'warn'));
    if (checks.some(c => c.level === 'err')) { Bridge.usbClose(d.h); throw new Error('fichier refusé avant envoi'); }
    const io = { control: (type, req, value, index, dataOrLen, timeout) => Bridge.usbControl(d.h, type, req, value, index, (type & 0x80) ? null : dataOrLen, (type & 0x80) ? dataOrLen : 0, timeout || 5000) };
    const dev = new DFU.Device(io, { iface: d.iface, transferSize: d.func.transferSize || 1024, layout: d.layout, log: m => ctl.log(m) });
    ctl.cancelHook = () => { dev.aborted = true; };
    const prog = (f, what) => ctl.set(0.12 + 0.78 * f, (what === 'effacement' ? 'Effacement' : what === 'finalisation' ? 'Finalisation' : 'Envoi du firmware') + ' — ' + Math.round(f * 100) + ' %');
    let end;
    try {
      end = d.dfuse ? await dev.downloadDfuse(parsed.kind === 'dfuse' || parsed.kind === 'hex' ? parsed.images[0].elements : [{ addr: d.layout ? d.layout.segs[0].start : 0x08000000, data: DFU.flatPayload(parsed) }], prog)
        : await dev.download(DFU.flatPayload(parsed), prog);
    } finally {
      try { Bridge.usbClose(d.h); } catch (e) { /* débranché */ }
    }
    ctl.log('Fin de l\'envoi (' + end + ')');
    // 3. retour du node
    ctl.set(0.92, 'Redémarrage du node…');
    const t0 = Date.now();
    while (Date.now() - t0 < 30000) {
      if (USB.state === 'ready' && USB.info) break;
      const s = USB.scan();
      if (s.ec && USB.state !== 'reading' && USB.state !== 'opening' && !USB.busy && (!USB.dev || USB.dev.name !== s.ec.name)) USB.connect(s.ec);
      await U.sleep(500);
    }
    if (USB.state !== 'ready' || !USB.info) return { ok: false, oldFw, newFw: '', msg: 'Le node n\'est pas revenu sur l\'USB : débranche-le et rebranche-le pour vérifier.' };
    if (!USB.nodeId) USB.associate(n);
    const newFw = (USB.info.mapped && USB.info.mapped.canon.firmware) || '';
    n.firmware = newFw || n.firmware;
    Store.save();
    const cmp = U.compareFirmware(newFw, oldFw);
    const ok = !!newFw && cmp !== 0;
    Store.log(n, 'Mise à jour firmware', ok, oldFw + ' → ' + newFw);
    return { ok, oldFw, newFw, msg: ok ? 'Firmware mis à jour : ' + U.fmtFirmware(oldFw) + ' → ' + U.fmtFirmware(newFw) : 'Le node indique toujours ' + (newFw || '?') + '.' };
  };
})(typeof self !== 'undefined' ? self : this);
