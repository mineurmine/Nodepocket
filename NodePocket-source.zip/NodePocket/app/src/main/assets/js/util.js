/* Node Pocket — utilitaires communs (navigateur et Node.js pour les tests) */
(function (root) {
  'use strict';

  const U = {};

  // ---------------------------------------------------------------- octets
  U.hex = function (u8, sep) {
    if (!u8) return '';
    const a = [];
    for (let i = 0; i < u8.length; i++) a.push((u8[i] & 255).toString(16).padStart(2, '0'));
    return a.join(sep === undefined ? '' : sep);
  };

  U.fromHex = function (s) {
    s = String(s || '').replace(/[^0-9a-fA-F]/g, '');
    const out = new Uint8Array(s.length >> 1);
    for (let i = 0; i < out.length; i++) out[i] = parseInt(s.substr(i * 2, 2), 16);
    return out;
  };

  U.toB64 = function (u8) {
    if (typeof Buffer !== 'undefined' && typeof window === 'undefined') return Buffer.from(u8).toString('base64');
    let s = '';
    const CH = 0x8000;
    for (let i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
    return btoa(s);
  };

  U.fromB64 = function (b64) {
    if (!b64) return new Uint8Array(0);
    if (typeof Buffer !== 'undefined' && typeof window === 'undefined') return new Uint8Array(Buffer.from(b64, 'base64'));
    const s = atob(b64);
    const out = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
    return out;
  };

  /** Chaîne ASCII/Latin-1 terminée par NUL (comme dmx-tools : un octet = un caractère) */
  U.cstr = function (u8, start, end) {
    let s = '';
    end = Math.min(end === undefined ? u8.length : end, u8.length);
    for (let i = start; i < end; i++) {
      if (u8[i] === 0) break;
      s += String.fromCharCode(u8[i]);
    }
    return s;
  };

  U.utf8 = function (str) {
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(str);
    return new Uint8Array(Buffer.from(str, 'utf8'));
  };

  U.utf8dec = function (u8) {
    if (typeof TextDecoder !== 'undefined') return new TextDecoder('utf-8').decode(u8);
    return Buffer.from(u8).toString('utf8');
  };

  U.u16le = (b, o) => (b[o] | (b[o + 1] << 8)) >>> 0;
  U.u32le = (b, o) => (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0;
  U.u16be = (b, o) => ((b[o] << 8) | b[o + 1]) >>> 0;

  U.concat = function (arrs) {
    let n = 0;
    arrs.forEach(a => { n += a.length; });
    const out = new Uint8Array(n);
    let o = 0;
    arrs.forEach(a => { out.set(a, o); o += a.length; });
    return out;
  };

  /** CRC32 (polynôme 0xEDB88320) ; dfuSuffix=true : sans inversion finale, comme le suffixe DFU */
  let CRC_T = null;
  U.crc32 = function (u8, start, end, dfuSuffix) {
    if (!CRC_T) {
      CRC_T = new Uint32Array(256);
      for (let n = 0; n < 256; n++) {
        let c = n;
        for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
        CRC_T[n] = c >>> 0;
      }
    }
    let c = 0xFFFFFFFF;
    for (let i = start || 0; i < (end === undefined ? u8.length : end); i++) c = CRC_T[(c ^ u8[i]) & 255] ^ (c >>> 8);
    return (dfuSuffix ? c : (c ^ 0xFFFFFFFF)) >>> 0;
  };

  // ---------------------------------------------------------------- IP
  U.isIp = function (s) {
    const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(String(s || '').trim());
    return !!m && m.slice(1).every(x => +x <= 255);
  };
  U.ipToInt = function (s) {
    const p = String(s).trim().split('.').map(Number);
    return (((p[0] << 24) >>> 0) + (p[1] << 16) + (p[2] << 8) + p[3]) >>> 0;
  };
  U.intToIp = n => [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');
  U.ipBytes = s => U.isIp(s) ? String(s).trim().split('.').map(Number) : [0, 0, 0, 0];
  U.sameSubnet = function (a, b, mask) {
    if (!U.isIp(a) || !U.isIp(b) || !U.isIp(mask)) return false;
    const m = U.ipToInt(mask);
    return ((U.ipToInt(a) & m) >>> 0) === ((U.ipToInt(b) & m) >>> 0);
  };
  U.broadcast = function (ip, mask) {
    if (!U.isIp(ip) || !U.isIp(mask)) return '255.255.255.255';
    const m = U.ipToInt(mask);
    return U.intToIp(((U.ipToInt(ip) & m) | (~m >>> 0)) >>> 0);
  };
  U.isMask = function (s) {
    if (!U.isIp(s)) return false;
    const n = U.ipToInt(s);
    const inv = (~n) >>> 0;
    return ((inv + 1) & inv) === 0 && n !== 0;
  };
  U.nextIp = function (ip, step) {
    return U.intToIp((U.ipToInt(ip) + (step == null ? 1 : Number(step))) >>> 0);
  };
  U.ipCompare = function (a, b) {
    const va = U.isIp(a) ? U.ipToInt(a) : 0xFFFFFFFF;
    const vb = U.isIp(b) ? U.ipToInt(b) : 0xFFFFFFFF;
    return va - vb;
  };

  // ---------------------------------------------------------------- firmware
  const MONTHS = { jan: 1, feb: 2, fev: 2, fév: 2, mar: 3, apr: 4, avr: 4, may: 5, mai: 5, jun: 6, jui: 7, jul: 7, aug: 8, aou: 8, aoû: 8, sep: 9, oct: 10, nov: 11, dec: 12, déc: 12 };

  /**
   * Lit une version de firmware sous toutes les formes rencontrées :
   * "Oct 10 2024" (__DATE__), "10/10/2024", "2024-10-10", "20241010", "V1.2.3", "1.4"…
   * Renvoie { raw, date:'AAAA-MM-JJ'|null, nums:[…]|null, key } ; key permet de trier.
   */
  U.parseFirmware = function (raw) {
    const s = String(raw == null ? '' : raw).trim();
    const out = { raw: s, date: null, time: null, nums: null, key: '' };
    if (!s) return out;
    let m;
    const low = s.toLowerCase();
    const tm = /(\d{1,2}):(\d{2})(?::(\d{2}))?/.exec(s);
    if (tm) out.time = tm[1].padStart(2, '0') + ':' + tm[2] + ':' + (tm[3] || '00');
    const setDate = (y, mo, d) => {
      y = +y; mo = +mo; d = +d;
      if (y < 100) y += 2000;
      if (mo >= 1 && mo <= 12 && d >= 1 && d <= 31 && y >= 2000 && y <= 2100) {
        out.date = y + '-' + String(mo).padStart(2, '0') + '-' + String(d).padStart(2, '0');
        return true;
      }
      return false;
    };
    const looksVersion = /^\s*v(er(sion)?)?\.?\s*\d/i.test(s);
    if (looksVersion) { /* "V1.2.10" : jamais une date */ }
    else if ((m = /([a-zéû]{3})[a-zéû]*\.?\s+(\d{1,2})\s*,?\s+(\d{4})/i.exec(low)) && MONTHS[m[1]]) setDate(m[3], MONTHS[m[1]], m[2]);
    else if ((m = /(\d{1,2})\s+([a-zéû]{3})[a-zéû]*\.?\s+(\d{4})/i.exec(low)) && MONTHS[m[2]]) setDate(m[3], MONTHS[m[2]], m[1]);
    else if ((m = /(\d{4})([-/.])(\d{1,2})\2(\d{1,2})/.exec(s))) setDate(m[1], m[3], m[4]);
    else if ((m = /(\d{1,2})([-/.])(\d{1,2})\2(\d{4}|\d{2})\b/.exec(s)) && !(m[2] === '.' && m[4].length === 2)) setDate(m[4], m[3], m[1]);
    else if ((m = /\b(20\d{2})(\d{2})(\d{2})\b/.exec(s))) setDate(m[1], m[2], m[3]);
    if (!out.date) {
      m = /v?\s*(\d+(?:\.\d+)+|\d+)/i.exec(s);
      if (m) out.nums = m[1].split('.').map(Number);
    }
    if (out.date) out.key = 'd' + out.date + (out.time ? 'T' + out.time : '');
    else if (out.nums) out.key = 'v' + out.nums.map(n => String(n).padStart(6, '0')).join('.');
    else out.key = 's' + low;
    return out;
  };

  /** <0 si a plus ancien que b, 0 si égal, >0 si plus récent ; null si non comparables */
  U.compareFirmware = function (a, b) {
    const A = typeof a === 'object' && a ? a : U.parseFirmware(a);
    const B = typeof b === 'object' && b ? b : U.parseFirmware(b);
    if (!A.raw || !B.raw) return null;
    if (A.date && B.date) {
      if (A.date !== B.date) return A.date < B.date ? -1 : 1;
      if (A.time && B.time && A.time !== B.time) return A.time < B.time ? -1 : 1;
      return 0;
    }
    if (A.nums && B.nums) {
      const n = Math.max(A.nums.length, B.nums.length);
      for (let i = 0; i < n; i++) {
        const x = A.nums[i] || 0, y = B.nums[i] || 0;
        if (x !== y) return x < y ? -1 : 1;
      }
      return 0;
    }
    if (A.date || B.date || A.nums || B.nums) return null;
    return A.raw === B.raw ? 0 : null;
  };

  U.fmtFirmware = function (raw) {
    const p = U.parseFirmware(raw);
    if (p.date) {
      const [y, m, d] = p.date.split('-');
      return d + '/' + m + '/' + y;
    }
    return p.raw || '—';
  };

  // ---------------------------------------------------------------- divers
  U.sleep = ms => new Promise(r => setTimeout(r, ms));
  U.clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  U.clone = o => (o === undefined ? undefined : JSON.parse(JSON.stringify(o)));
  U.uid = function (p) {
    return (p || 'n') + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  };
  U.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  };
  /** minuscules, sans accents, espaces normalisés, sans ":" ni "( 0 to 255)" final */
  U.norm = function (s) {
    return String(s == null ? '' : s)
      .normalize('NFD').replace(/[̀-ͯ]/g, '')
      .toLowerCase()
      .replace(/\(\s*-?\d+\s*(?:to|a|à|-)\s*-?\d+\s*\)/g, ' ')
      .replace(/[:*]+\s*$/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  };
  U.plural = (n, one, many) => n + ' ' + (n > 1 ? (many || one + 's') : one);
  U.timeAgo = function (ts, now) {
    if (!ts) return 'jamais';
    const s = Math.round(((now || Date.now()) - ts) / 1000);
    if (s < 10) return 'à l\'instant';
    if (s < 60) return 'il y a ' + s + ' s';
    const m = Math.round(s / 60);
    if (m < 60) return 'il y a ' + m + ' min';
    const h = Math.round(m / 60);
    if (h < 24) return 'il y a ' + h + ' h';
    const d = new Date(ts);
    return 'le ' + String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + d.getFullYear();
  };
  U.fmtDate = function (ts) {
    const d = new Date(ts);
    const p = n => String(n).padStart(2, '0');
    return p(d.getDate()) + '/' + p(d.getMonth() + 1) + '/' + d.getFullYear() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  };
  /** Compare deux valeurs canoniques (nombres et chaînes numériques égales, IP normalisées) */
  U.same = function (a, b) {
    if (a === b) return true;
    if (a == null || b == null) return false;
    if (typeof a === 'number' || typeof b === 'number') return Number(a) === Number(b);
    return String(a).trim() === String(b).trim();
  };
  /** Exécute des promesses avec un nombre limité en parallèle */
  U.pool = async function (items, limit, fn) {
    const out = new Array(items.length);
    let i = 0;
    const workers = Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, async () => {
      while (i < items.length) {
        const k = i++;
        try { out[k] = await fn(items[k], k); } catch (e) { out[k] = { error: e && e.message ? e.message : String(e) }; }
      }
    });
    await Promise.all(workers);
    return out;
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = U;
  else root.U = U;
})(typeof self !== 'undefined' ? self : this);
