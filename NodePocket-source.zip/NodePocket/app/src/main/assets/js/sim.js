/*
 * Node Pocket — nodes simulés (mode démo dans un navigateur, et tests automatiques).
 *
 * Deux familles :
 *  - « classique » : comme les nodes PoE actuels — table de paramètres en USB (protocole dmx-tools)
 *    et page web à onglets IP Setting / DMX n Setting / Device Setting / Infos ;
 *  - « 2026 » : interface web embarquée (onglets Console / RDM / DMX / Réseau / Système),
 *    servie en HTTP et en USB (fichiers HID), sans table de paramètres.
 * Le contenu exact des vraies pages n'est pas public : ces simulations servent à tester l'appli.
 */
(function (root) {
  'use strict';
  const U = root.U || (typeof require !== 'undefined' ? require('./util.js') : null);
  const A = root.ArtNet || (typeof require !== 'undefined' ? require('./artnet.js') : null);

  const T = { NUMBER: 0, STRING: 1, IP: 2, LIST: 4, RO: 5 };

  function defaults(model) {
    const ports = [];
    for (let i = 0; i < model; i++) ports.push({ dir: 'out', univOut: i, univIn: i, prio: 100, castIp: '2.255.255.255', sacnMode: 'multicast' });
    return {
      ipMode: 'dhcp', ip: '2.0.0.15', mask: '255.0.0.0', dhcpIp: '192.168.1.' + (40 + Math.floor(Math.random() * 50)),
      protocol: 'artnet', maxUniv: model, outMode: 'sync', fps: 44, loginPage: false, login: 'admin', pass: '',
      longName: 'Electroconcept Node ' + model, shortName: 'Node' + model, ports
    };
  }

  class SimNode {
    constructor(o) {
      o = o || {};
      this.model = o.model || 4;
      this.family = o.family || 'classic';
      this.serial = o.serial || ('EC' + Math.floor(100000 + Math.random() * 899999));
      this.mac = o.mac || '02:ec:' + [0, 0, 0, 0].map(() => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(':');
      this.fw = o.fw || 'Oct 10 2024';
      this.product = o.product || (this.family === '2026' ? 'Node ' + this.model + ' univers 2026' : 'NODE ' + this.model + ' ARTNET PoE');
      this.hasDfu = o.hasDfu !== false;
      this.artAddress = o.artAddress !== false;
      this.ipProg = o.ipProg !== false;
      this.online = o.online !== false;
      this.receiving = o.receiving !== false;
      this.mode = 'app'; // app | dfu | off
      this.identify = 0;
      this.sessions = {};
      this.s = Object.assign(defaults(this.model), o.state || {});
      if (o.state && o.state.ports) this.s.ports = o.state.ports.map((p, i) => Object.assign(defaults(this.model).ports[i] || {}, p));
      this.log = [];
    }

    get ipNow() { return this.s.ipMode === 'dhcp' ? this.s.dhcpIp : this.s.ip; }

    factoryReset() {
      const keepDhcp = this.s.dhcpIp;
      this.s = defaults(this.model);
      this.s.dhcpIp = keepDhcp;
    }

    // ------------------------------------------------------------ table de paramètres (famille classique)
    groups() {
      if (this.family === '2026') return [];
      const g = ['IP Setting'];
      for (let i = 0; i < this.model; i++) g.push('DMX ' + (i + 1) + ' Setting');
      g.push('Device Setting', 'Infos');
      return g;
    }

    params() {
      if (this._params) return this._params;
      if (this.family === '2026') return (this._params = []);
      const s = () => this.s;
      const P = [];
      const add = (group, type, name, get, set, min, max, maxLen) => P.push({ group, type, name, get, set, min: min || 0, max: max || 0, maxLen: maxLen || 0 });
      const yesNo = b => (b ? 1 : 0);
      add(0, T.LIST, 'DHCP or STATIC\rDHCP\rSTATIC\r', () => (s().ipMode === 'dhcp' ? 0 : 1), v => { s().ipMode = v === 0 ? 'dhcp' : 'static'; });
      add(0, T.IP, 'Device IP (static)', () => s().ip, v => { s().ip = v; });
      add(0, T.IP, 'Device IP MASK (static)', () => s().mask, v => { s().mask = v; });
      add(0, T.NUMBER, 'Max Total Universe', () => s().maxUniv, v => { s().maxUniv = v; }, 1, this.model);
      add(0, T.LIST, 'DMX Protocol\rArt-Net\rsACN\r', () => (s().protocol === 'sacn' ? 1 : 0), v => { s().protocol = v === 1 ? 'sacn' : 'artnet'; });
      for (let i = 0; i < this.model; i++) {
        const port = () => s().ports[i];
        add(1 + i, T.LIST, 'DMX\rXLR Output\rXLR Input\r', () => (port().dir === 'in' ? 1 : 0), v => { port().dir = v === 1 ? 'in' : 'out'; });
        add(1 + i, T.NUMBER, 'Universe OUT', () => port().univOut, v => { port().univOut = v; }, 0, 255);
        add(1 + i, T.NUMBER, 'Universe IN', () => port().univIn, v => { port().univIn = v; }, 0, 255);
        add(1 + i, T.NUMBER, 'DMX IN -> sACN out Priority', () => port().prio, v => { port().prio = v; }, 0, 200);
        add(1 + i, T.IP, 'DMX IN -> IP Cast Out', () => port().castIp, v => { port().castIp = v; });
      }
      const gd = 1 + this.model, gi = gd + 1;
      add(gd, T.STRING, 'Long Device Name', () => s().longName, v => { s().longName = v; }, 0, 0, 63);
      add(gd, T.STRING, 'Short Device Name', () => s().shortName, v => { s().shortName = v; }, 0, 0, 17);
      add(gd, T.LIST, 'DMX OUT\rSynchronized\rFixed\r', () => (s().outMode === 'fixed' ? 1 : 0), v => { s().outMode = v === 1 ? 'fixed' : 'sync'; });
      add(gd, T.NUMBER, 'Fps Fixed DMX OUT', () => s().fps, v => { s().fps = v; }, 16, 44);
      add(gi, T.RO, 'Firmware Version', () => this.fw, null);
      add(gi, T.RO, 'IP Now', () => this.ipNow, null);
      add(gi, T.RO, 'Serial number', () => this.serial, null);
      add(gi, T.LIST, 'Login Page\rNO\rYES\r', () => yesNo(s().loginPage), v => { s().loginPage = v === 1; });
      add(gi, T.STRING, 'Login', () => s().login, v => { s().login = v; }, 0, 0, 16);
      add(gi, T.STRING, 'Pass', () => s().pass, v => { s().pass = v; }, 0, 0, 16);
      add(gi, T.LIST, 'Reset Node\rNO\rYES\r', () => 0, v => { if (v === 1) this.factoryReset(); });
      if (this.hasDfu) add(gi, T.LIST, 'DFU\rNO\rYES\r', () => 0, v => { if (v === 1) this.enterDfu(); });
      return (this._params = P);
    }

    enterDfu() {
      this.mode = 'dfu';
      this.log.push('DFU');
      if (this.onModeChange) this.onModeChange('dfu');
    }

    // ------------------------------------------------------------ USB HID (protocole dmx-tools)
    hid(req) {
      const r = new Uint8Array(64);
      const P = this.params();
      const G = this.groups();
      const putStr = (s, off, max) => { const b = U.utf8(s); for (let i = 0; i < b.length && off + i < Math.min(64, off + max); i++) r[off + i] = b[i]; };
      const cmd = req[0];
      r[0] = cmd;
      switch (cmd) {
        case 7: putStr(this.product, 1, 62); break;
        case 2: r[1] = G.length; break;
        case 3: r[1] = req[1]; putStr(G[req[1]] || '', 2, 61); break;
        case 1: r[1] = P.length; break;
        case 5: {
          const p = P[req[1]];
          if (!p) break;
          r[1] = req[1]; r[2] = p.group; r[3] = p.type;
          r[4] = p.min & 255; r[5] = p.min >> 8; r[6] = p.max & 255; r[7] = p.max >> 8;
          putStr(p.name, 8, 56);
          break;
        }
        case 4: {
          const p = P[req[1]];
          if (!p) break;
          r[1] = req[1];
          const v = p.get();
          if (p.type === T.IP) U.ipBytes(v).forEach((x, i) => { r[2 + i] = x; });
          else { const n = Number(v) >>> 0; r[2] = n & 255; r[3] = (n >> 8) & 255; r[4] = (n >> 16) & 255; r[5] = (n >> 24) & 255; }
          break;
        }
        case 9: {
          const p = P[req[1]];
          if (!p) break;
          r[1] = req[1]; r[2] = p.maxLen || 32;
          putStr(String(p.get()), 3, 61);
          break;
        }
        case 6: {
          const p = P[req[1]];
          if (!p || !p.set) break;
          r[1] = req[1];
          if (p.type === T.IP) p.set([req[2], req[3], req[4], req[5]].join('.'));
          else if (p.type === T.LIST) p.set(req[2]);
          else {
            let n = U.u32le(req, 2);
            if (p.max > p.min) n = U.clamp(n, p.min, p.max);
            p.set(n);
          }
          break;
        }
        case 10: {
          const p = P[req[1]];
          if (!p || !p.set) break;
          r[1] = req[1];
          let end = 3;
          while (end < 64 && req[end]) end++;
          let v = U.utf8dec(req.subarray(3, end));
          if (p.maxLen) v = v.slice(0, p.maxLen);
          p.set(v);
          break;
        }
        case 12: {
          if (this.family !== '2026') { r[0] = 0; break; }
          let end = 1;
          while (end < 51 && req[end]) end++;
          const name = U.utf8dec(req.subarray(1, end));
          const f = this.file(name);
          this._file = f;
          if (!f) { r[1] = 0; break; }
          r[1] = 1;
          putStr(name.slice(0, 19), 2, 19);
          putStr(f.mime, 22, 19);
          const n = f.data.length;
          r[42] = n & 255; r[43] = (n >> 8) & 255; r[44] = (n >> 16) & 255; r[45] = (n >> 24) & 255;
          const chunks = Math.ceil(n / 60);
          r[46] = chunks & 255; r[47] = chunks >> 8; r[48] = 60;
          break;
        }
        case 13: {
          const i = req[1] | (req[2] << 8);
          const f = this._file;
          r[1] = req[1]; r[2] = req[2];
          if (!f) break;
          const part = f.data.subarray(i * 60, i * 60 + 60);
          r[3] = part.length;
          r.set(part, 4);
          break;
        }
        default: r[0] = 0;
      }
      return r;
    }

    // ------------------------------------------------------------ API (interface 2026, HTTP et fichiers HID)
    apiGet() {
      const s = this.s;
      return {
        product: this.product, firmware: this.fw, serial: this.serial, ipNow: this.ipNow,
        longName: s.longName, shortName: s.shortName, loginPage: s.loginPage, login: s.login, pass: s.pass,
        ipMode: s.ipMode, ip: s.ip, mask: s.mask, protocol: s.protocol, outMode: s.outMode, fps: s.fps,
        ports: s.ports.map(p => Object.assign({}, p))
      };
    }
    apiSet(q) {
      const s = this.s;
      Object.keys(q).forEach(k => {
        const v = q[k];
        const m = /^p(\d)\.(\w+)$/.exec(k);
        if (m) {
          const p = s.ports[+m[1]];
          if (!p) return;
          p[m[2]] = /univ|prio/.test(m[2]) ? Number(v) : v;
          return;
        }
        if (k === 'action') {
          if (v === 'reset') this.factoryReset();
          if (v === 'dfu' && this.hasDfu) this.enterDfu();
          return;
        }
        if (k === 'loginPage') s.loginPage = v === true || v === '1' || v === 'true';
        else if (k === 'fps') s.fps = U.clamp(Number(v), 16, 44);
        else if (k in s) s[k] = v;
      });
      return { ok: true };
    }
    /** chemin d'API "api/get" ou "api/set?k=v&k2=v2" (50 caractères max en HID) */
    api(path) {
      const [p, qs] = String(path).replace(/^\//, '').split('?');
      if (p === 'api/get') return this.apiGet();
      if (p === 'api/set') {
        const q = {};
        (qs || '').split('&').filter(Boolean).forEach(kv => { const [k, v] = kv.split('='); q[decodeURIComponent(k)] = decodeURIComponent(v || ''); });
        return this.apiSet(q);
      }
      if (p === 'api/dmx') return { values: Array.from({ length: 512 }, (_, i) => (i * 7 + Math.floor(Date.now() / 100)) % 256) };
      if (p === 'api/rdm') return { devices: [{ uid: '454C:00000012', name: 'PAR LED', address: 1, footprint: 8, manufacturer: 'Electroconcept' }] };
      return null;
    }
    file(name) {
      name = String(name).replace(/^\//, '');
      if (name === '' || name === 'index.html') return { mime: 'text/html', data: U.utf8(SimNode.gui2026()) };
      if (/^api\//.test(name)) {
        const o = this.api(name);
        return o ? { mime: 'application/json', data: U.utf8(JSON.stringify(o)) } : null;
      }
      return null;
    }

    // ------------------------------------------------------------ HTTP (page web du node)
    /** Renvoie { status, html } ; sid = session de navigation (login) */
    http(method, path, body, sid) {
      if (!this.online || this.mode !== 'app') return { status: 0, html: '' };
      path = String(path || '/').replace(/^https?:\/\/[^/]+/, '') || '/';
      const sess = this.sessions[sid] = this.sessions[sid] || { auth: false };
      if (this.family === '2026') {
        if (path === '/' || path === '/index.html') return { status: 200, html: SimNode.gui2026() };
        if (/^\/api\//.test(path)) return { status: 200, json: this.api(path) };
        return { status: 404, html: 'Not found' };
      }
      if (method === 'POST' && path === '/login') {
        sess.auth = body && body.login === this.s.login && body.pass === this.s.pass;
        return { status: 302, location: '/' };
      }
      if (this.s.loginPage && !sess.auth) return { status: 200, html: this.loginPage() };
      if (method === 'POST' && path === '/apply') {
        const P = this.params();
        Object.keys(body || {}).forEach(k => {
          const m = /^ID(\d+)$/.exec(k);
          if (!m) return;
          const p = P[+m[1]];
          if (!p || !p.set) return;
          let v = body[k];
          if (p.type === T.LIST || p.type === T.NUMBER) v = Number(v);
          if (p.type === T.NUMBER && p.max > p.min) v = U.clamp(v, p.min, p.max);
          if (p.type === T.STRING && p.maxLen) v = String(v).slice(0, p.maxLen);
          if (p.type === T.LIST && /^(Reset Node|DFU)/.test(p.name) && v !== 1) return;
          p.set(v);
        });
        if (this.rebootOnApply) {
          // ce node redémarre après Appliquer : injoignable quelques secondes
          this.online = false;
          setTimeout(() => { this.online = true; }, this.rebootOnApply);
        }
        return { status: 302, location: '/' };
      }
      if (path === '/' || path === '/index.html') return { status: 200, html: this.classicPage() };
      return { status: 404, html: 'Not found' };
    }

    loginPage() {
      return '<!doctype html><html><head><meta charset="utf-8"><title>Login</title><style>body{font-family:sans-serif;background:#eee;padding:40px}form{background:#fff;padding:20px;max-width:300px}</style></head><body>' +
        '<form id="lf"><h3>' + U.esc(this.product) + '</h3>User <input name="login" id="login"><br>Password <input type="password" name="pass" id="pass"><br><button type="submit">Login</button></form>' +
        '<script>document.getElementById("lf").addEventListener("submit",function(e){e.preventDefault();__simPost("/login",{login:document.getElementById("login").value,pass:document.getElementById("pass").value});});<\/script></body></html>';
    }

    classicPage() {
      const P = this.params(), G = this.groups();
      let tabs = '', content = '';
      G.forEach((g, gi) => {
        tabs += '<button type="button" class="tablinks" onclick="openTable(event,\'groupe' + gi + '\')">' + U.esc(g) + '</button>';
        let rows = '';
        P.forEach((p, i) => {
          if (p.group !== gi) return;
          const parts = p.name.split('\r');
          const label = parts[0];
          let input;
          const v = p.get();
          if (p.type === T.LIST) {
            input = '<select id="ID' + i + '">' + parts.slice(1, -1).map((o, k) => '<option value="' + k + '"' + (k === v ? ' selected' : '') + '>' + U.esc(o) + '</option>').join('') + '</select>';
          } else if (p.type === T.IP) {
            input = U.ipBytes(v).map((x, k) => '<input id="ID' + i + '_IP' + k + '" size="3" maxlength="3" value="' + x + '">').join('.');
          } else if (p.type === T.NUMBER) {
            input = '<input id="ID' + i + '" type="number" min="' + p.min + '" max="' + p.max + '" value="' + v + '">';
          } else if (p.type === T.RO) {
            input = '<input id="ID' + i + '" readonly value="' + U.esc(v) + '">';
          } else {
            input = '<input id="ID' + i + '" maxlength="' + (p.maxLen || 32) + '" value="' + U.esc(v) + '"' + (/pass/i.test(label) ? ' type="password"' : '') + '>';
          }
          rows += '<tr><td>' + U.esc(label) + (p.type === T.NUMBER ? ' ( ' + p.min + ' to ' + p.max + ')' : '') + ' :</td><td>' + input + '</td></tr>';
        });
        content += '<div id="groupe' + gi + '" class="tabcontent"' + (gi ? ' style="display:none"' : '') + '><table>' + rows + '</table></div>';
      });
      return '<!doctype html><html><head><meta charset="utf-8"><title>' + U.esc(this.product) + '</title>' +
        '<style>body{font-family:Arial;background:#f2f2f2;margin:0;padding:10px}.tab button{padding:8px 12px}td{padding:4px}.bar{margin-top:10px}</style></head><body>' +
        '<h2 id="pageTitle">' + U.esc(this.s.longName) + '</h2><div class="tab">' + tabs + '</div><form id="Formulaire" onsubmit="return false">' + content + '</form>' +
        '<div class="bar"><button type="button" id="apply" onclick="applyAll()">Apply</button> <a href="#" onclick="return false">Save Parameters</a> <a href="#" onclick="return false">Load Parameters</a> <a href="#" onclick="return false">Status Page</a></div>' +
        '<script>function openTable(e,id){var t=document.getElementsByClassName("tabcontent");for(var i=0;i<t.length;i++)t[i].style.display="none";document.getElementById(id).style.display="block";}' +
        'function applyAll(){var o={};var els=document.querySelectorAll("#Formulaire input,#Formulaire select");var ips={};for(var i=0;i<els.length;i++){var el=els[i];if(el.readOnly)continue;var m=/^ID(\\d+)_IP(\\d)$/.exec(el.id);if(m){(ips[m[1]]=ips[m[1]]||[])[+m[2]]=el.value;continue;}o[el.id]=el.tagName==="SELECT"?el.selectedIndex:el.value;}for(var k in ips)o["ID"+k]=ips[k].join(".");__simPost("/apply",o);alert("Done!!");}<\/script></body></html>';
    }

    // ------------------------------------------------------------ Art-Net
    pollReplies() {
      if (!this.online || this.mode !== 'app') return [];
      const s = this.s;
      const addrs = s.ports.map(p => (p.dir === 'in' ? p.univIn : p.univOut));
      const sameBlock = addrs.every(a => (a >> 4) === (addrs[0] >> 4));
      const groups = sameBlock ? [s.ports.map((p, i) => i)] : s.ports.map((p, i) => [i]);
      return groups.map((idxs, gi) => this.buildReply(idxs, sameBlock ? 0 : gi + 1));
    }
    buildReply(idxs, bindIndex) {
      const s = this.s;
      const b = new Uint8Array(239);
      b.set([65, 114, 116, 45, 78, 101, 116, 0], 0);
      b[8] = 0x00; b[9] = 0x21;
      b.set(U.ipBytes(this.ipNow), 10);
      b[14] = 0x36; b[15] = 0x19;
      const fw = U.parseFirmware(this.fw);
      b[16] = fw.date ? +fw.date.slice(2, 4) : 1; b[17] = fw.date ? +fw.date.slice(5, 7) : 0;
      const first = s.ports[idxs[0]];
      const a0 = first.dir === 'in' ? first.univIn : first.univOut;
      b[18] = (a0 >> 8) & 0x7f; b[19] = (a0 >> 4) & 0x0f;
      b[20] = 0x00; b[21] = 0xff;
      b[23] = (this.identify > Date.now() ? 0x40 : 0xc0) | 0x20;
      b[24] = 0x45; b[25] = 0x43; // "EC"
      const putS = (off, len, str) => { const x = U.utf8(String(str || '')); for (let i = 0; i < len - 1 && i < x.length; i++) b[off + i] = x[i]; };
      putS(26, 18, s.shortName);
      putS(44, 64, s.longName);
      putS(108, 64, '#0001 [' + (this.rx = (this.rx || 0) + 1) + '] Power On Tests successful');
      b[173] = idxs.length;
      idxs.forEach((pi, k) => {
        const p = s.ports[pi];
        b[174 + k] = p.dir === 'in' ? 0x40 : 0x80;
        b[178 + k] = (p.dir === 'in' && this.receiving ? 0x80 : 0) | (s.protocol === 'sacn' ? 1 : 0);
        b[182 + k] = (p.dir === 'out' && this.receiving ? 0x80 : 0) | (s.protocol === 'sacn' ? 1 : 0);
        b[186 + k] = p.univIn & 0x0f;
        b[190 + k] = p.univOut & 0x0f;
        b[213 + k] = s.outMode === 'fixed' ? 0x40 : 0;
      });
      b[200] = 0x00;
      this.mac.split(':').forEach((h, i) => { b[201 + i] = parseInt(h, 16); });
      b.set(U.ipBytes(this.ipNow), 207);
      b[211] = bindIndex;
      b[212] = 0x01 | (s.ipMode === 'dhcp' ? 0x02 : 0) | 0x04 | 0x08 | 0x10;
      b[217] = 0x08;
      return b;
    }
    /** paquet Art-Net reçu par le node ; renvoie les paquets de réponse */
    artnet(pkt) {
      if (!this.online || this.mode !== 'app') return [];
      const op = A.opcode(pkt);
      if (op === A.OP.POLL) return this.pollReplies();
      if (op === A.OP.ADDRESS && this.artAddress) {
        const s = this.s;
        const bind = pkt[13];
        const net = pkt[12] & 0x80 ? pkt[12] & 0x7f : null;
        const sub = pkt[104] & 0x80 ? pkt[104] & 0x0f : null;
        const sn = U.cstr(pkt, 14, 32), ln = U.cstr(pkt, 32, 96);
        if (sn) s.shortName = sn.slice(0, 17);
        if (ln) s.longName = ln.slice(0, 63);
        const idxs = bind ? [bind - 1] : s.ports.map((p, i) => i);
        idxs.forEach((pi, k) => {
          const p = s.ports[pi];
          if (!p) return;
          const slot = bind ? 0 : k;
          const base = (u) => (((net != null ? net : (u >> 8) & 0x7f) << 8) | ((sub != null ? sub : (u >> 4) & 0x0f) << 4));
          if (pkt[100 + slot] & 0x80) p.univOut = base(p.univOut) | (pkt[100 + slot] & 0x0f);
          else if (net != null || sub != null) p.univOut = base(p.univOut) | (p.univOut & 0x0f);
          if (pkt[96 + slot] & 0x80) p.univIn = base(p.univIn) | (pkt[96 + slot] & 0x0f);
        });
        const c = pkt[106];
        if (c === A.AC.LED_LOCATE) this.identify = Date.now() + 8000;
        if (c === A.AC.LED_NORMAL) this.identify = 0;
        if ((c & 0xf0) === A.AC.ARTNET_SEL) s.protocol = 'artnet';
        if ((c & 0xf0) === A.AC.ACN_SEL) s.protocol = 'sacn';
        if ((c & 0xf0) === A.AC.DIRECTION_TX && s.ports[c & 3]) s.ports[c & 3].dir = 'out';
        if ((c & 0xf0) === A.AC.DIRECTION_RX && s.ports[c & 3]) s.ports[c & 3].dir = 'in';
        return this.pollReplies();
      }
      if (op === A.OP.IP_PROG && this.ipProg) {
        const cmd = pkt[14];
        const s = this.s;
        if (cmd & 0x80) {
          if (cmd & 0x40) s.ipMode = 'dhcp';
          else if (cmd & 0x08) { s.ipMode = 'static'; s.ip = '2.0.0.15'; s.mask = '255.0.0.0'; }
          else {
            if (cmd & 0x04) { s.ip = [pkt[16], pkt[17], pkt[18], pkt[19]].join('.'); s.ipMode = 'static'; }
            if (cmd & 0x02) s.mask = [pkt[20], pkt[21], pkt[22], pkt[23]].join('.');
          }
        }
        const r = new Uint8Array(34);
        r.set([65, 114, 116, 45, 78, 101, 116, 0], 0);
        r[8] = 0x00; r[9] = 0xf9; r[11] = 14;
        r.set(U.ipBytes(s.ip), 16); r.set(U.ipBytes(s.mask), 20);
        r[26] = s.ipMode === 'dhcp' ? 0x40 : 0;
        return [r];
      }
      return [];
    }
  }

  // ------------------------------------------------------------ interface web « 2026 » (simulée)
  SimNode.gui2026 = function () {
    const portSec = i => '<section class="card port" id="port' + i + '"><h3>Configuration DMX ' + (i + 1) + '</h3>' +
      '<label>Mode <select data-k="p' + i + '.dir"><option value="out">DMX OUT (émission)</option><option value="in">DMX IN (réception)</option></select></label>' +
      '<div class="an"><label>Univers OUT (Art-Net) <input type="number" min="0" max="32767" data-k="p' + i + '.univOut"></label>' +
      '<label>Univers IN (Art-Net) <input type="number" min="0" max="32767" data-k="p' + i + '.univIn"></label>' +
      '<label>IP sortie (Art-Net) <input data-k="p' + i + '.castIp"></label></div>' +
      '<div class="sa"><label>Univers OUT (sACN) <input type="number" min="1" max="63999" data-k="p' + i + '.univOutS"></label>' +
      '<label>Univers IN (sACN) <input type="number" min="1" max="63999" data-k="p' + i + '.univInS"></label>' +
      '<label>Mode sACN <select data-k="p' + i + '.sacnMode"><option value="multicast">Multicast</option><option value="unicast">Unicast</option></select></label>' +
      '<label>Priorité sACN <input type="number" min="0" max="200" data-k="p' + i + '.prio"></label></div></section>';
    return '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Node — Electroconcept</title>' +
      '<style>body{margin:0;font-family:system-ui,sans-serif;background:#14161a;color:#e8e8e8}nav{display:flex;gap:4px;padding:8px;background:#0b0c0e;position:sticky;top:0}nav button{background:#262a31;color:#ddd;border:0;padding:8px 12px;border-radius:6px}nav button.on{background:#e8771e;color:#000}' +
      '.tab{display:none;padding:12px}.tab.on{display:block}.card{background:#1d2026;border-radius:8px;padding:10px;margin-bottom:10px}label{display:block;margin:6px 0}input,select{margin-left:6px;background:#0d0f12;color:#fff;border:1px solid #333;padding:4px}' +
      '.warn{color:#f5a623}#msg{padding:6px 12px;color:#8fd18f}</style></head><body>' +
      '<nav><button data-t="console">Console</button><button data-t="rdm">RDM</button><button data-t="dmx" class="on">DMX</button><button data-t="net">Réseau</button><button data-t="sys">Système</button><span id="hip" style="margin-left:auto"></span></nav>' +
      '<div class="tab" id="t-console"><div class="card"><h3>DMX Monitor</h3><canvas id="mon" width="512" height="60"></canvas></div><div class="card"><h3>DMX Console</h3>Canal <input type="number" id="ch" value="1"> <button type="button">Noir</button> <button type="button">Plein</button></div></div>' +
      '<div class="tab" id="t-rdm"><div class="card"><h3>RDM Discovery</h3><button type="button" id="rdmGo">Démarrer</button> <button type="button">Arrêter</button><div id="rdmList">Inactif - Cliquez sur Démarrer</div></div></div>' +
      '<div class="tab on" id="t-dmx"><div class="card"><h3>Paramètres DMX</h3><label>Protocole <select data-k="protocol"><option value="sacn">sACN (E1.31)</option><option value="artnet">Art-Net</option></select></label></div>' +
      '<div id="ports"></div>' +
      '<div class="card"><h3>Sortie réseau (global)</h3><label>Mode sortie <select data-k="outMode"><option value="fixed">Continue</option><option value="change">Sur changement</option><option value="fixed_always">Continu (sans arrêt)</option></select></label>' +
      '<label>FPS max <input type="number" min="16" max="44" data-k="fps"></label></div></div>' +
      '<div class="tab" id="t-net"><div class="card"><h3>Paramètres Réseau</h3><h4>Configuration IP</h4><label>IP Actuelle <input readonly data-k="ipNow"></label>' +
      '<label>Mode <select data-k="ipMode"><option value="static">IP Statique</option><option value="dhcp">DHCP</option></select></label>' +
      '<label>IP statique <input data-k="ip"></label><label>Masque <input data-k="mask"></label></div></div>' +
      '<div class="tab" id="t-sys"><div class="card"><h3>Système &amp; Sécurité</h3><h4>Identité</h4><label>Nom long <input maxlength="63" data-k="longName"></label><label>Nom court <input maxlength="17" data-k="shortName"></label>' +
      '<label>Firmware <input readonly data-k="firmware"></label><label>Série <input readonly data-k="serial"></label>' +
      '<h4>Sécurité</h4><label>Page login <select data-k="loginPage"><option value="0">Désactivée</option><option value="1">Activée</option></select></label>' +
      '<label>Utilisateur <input data-k="login"></label><label>Mot de passe <input type="password" data-k="pass"></label>' +
      '<button type="button" id="reset">Reset usine</button> <button type="button" id="dfu">DFU</button></div></div>' +
      '<div style="padding:0 12px 12px"><button type="button" id="apply">Appliquer</button><span id="msg"></span></div>' +
      '<script>(function(){' +
      'var hid=!window.__simIp&&window.parent&&window.parent!==window&&window.parent.downloadWebFileBinary&&window.parent.getDevice;' +
      'function dec(b){return JSON.parse(new TextDecoder().decode(b));}' +
      'function api(p){if(window.__simIp)return Promise.resolve(window.parent.__simApi(window.__simIp,p));if(hid)return window.parent.downloadWebFileBinary(window.parent.getDevice(),p).then(dec);return fetch("/"+p).then(function(r){return r.json();});}' +
      'var ports=document.getElementById("ports");var cfg=null;' +
      'document.querySelectorAll("nav button[data-t]").forEach(function(b){b.onclick=function(){document.querySelectorAll("nav button").forEach(function(x){x.classList.toggle("on",x===b)});document.querySelectorAll(".tab").forEach(function(t){t.classList.toggle("on",t.id==="t-"+b.dataset.t)});};});' +
      'function get(k){var m=/^p(\\d)\\.(\\w+)$/.exec(k);if(m){var p=cfg.ports[+m[1]];if(m[2]==="univOutS")return p.univOut+(cfg.protocol==="sacn"?0:1);if(m[2]==="univInS")return p.univIn+(cfg.protocol==="sacn"?0:1);return p[m[2]];}if(k==="loginPage")return cfg.loginPage?"1":"0";return cfg[k];}' +
      'function fill(){document.querySelectorAll("[data-k]").forEach(function(el){var v=get(el.dataset.k);if(el.tagName==="SELECT"){for(var i=0;i<el.options.length;i++)if(el.options[i].value===String(v))el.selectedIndex=i;}else el.value=v==null?"":v;});document.getElementById("hip").textContent=cfg.ipNow;' +
      'document.querySelectorAll(".an").forEach(function(x){x.style.display=cfg.protocol==="sacn"?"none":"";});document.querySelectorAll(".sa").forEach(function(x){x.style.display=cfg.protocol==="sacn"?"":"none";});}' +
      'function load(){return api("api/get").then(function(c){cfg=c;if(!ports.children.length){var h="";for(var i=0;i<c.ports.length;i++)h+=PORT(i);ports.innerHTML=h;}fill();});}' +
      'var PORT=function(i){return ' + JSON.stringify(portSec(0)) + '.replace(/p0\\./g,"p"+i+".").replace("Configuration DMX 1","Configuration DMX "+(i+1)).replace(\'id="port0"\',\'id="port\'+i+\'"\');};' +
      'function q(k,v){return encodeURIComponent(k)+"="+encodeURIComponent(v);}' +
      'document.getElementById("apply").onclick=function(){var proto=document.querySelector("[data-k=protocol]").value;var sets=[];document.querySelectorAll("[data-k]").forEach(function(el){if(el.readOnly)return;var k=el.dataset.k,v=el.value;var m=/^p(\\d)\\.(univOutS|univInS)$/.exec(k);if(m){if(proto!=="sacn")return;sets.push(q("p"+m[1]+"."+(m[2]==="univOutS"?"univOut":"univIn"),+v));return;}if(/^p\\d\\.(univOut|univIn|castIp)$/.test(k)&&proto==="sacn")return;' +
      'if(String(get(k))!==String(v))sets.push(q(k,v));});var chain=Promise.resolve();var batch=[];sets.forEach(function(s){if((batch.concat(s).join("&")).length>40){var b=batch.join("&");chain=chain.then(function(){return api("api/set?"+b);});batch=[];}batch.push(s);});' +
      'if(batch.length){var b2=batch.join("&");chain=chain.then(function(){return api("api/set?"+b2);});}chain.then(load).then(function(){document.getElementById("msg").textContent="Paramètres appliqués";});};' +
      'document.getElementById("reset").onclick=function(){if(confirm("Reset usine ?"))api("api/set?action=reset").then(load);};' +
      'document.getElementById("dfu").onclick=function(){if(confirm("Redémarrer en mode DFU ?"))api("api/set?action=dfu");};' +
      'document.getElementById("rdmGo").onclick=function(){api("api/rdm").then(function(r){document.getElementById("rdmList").textContent=r.devices.map(function(d){return d.uid+" "+d.name+" @"+d.address}).join(", ");});};' +
      'load();})();<\/script></body></html>';
  };

  // ------------------------------------------------------------ périphérique DFU simulé
  class SimDfu {
    constructor(node) {
      this.node = node;
      this.state = 2; this.status = 0; this.buf = []; this.busy = 0; this.gone = false;
      this.transferSize = 1024;
    }
    descriptors() {
      return U.fromHex('1201000200000040c91f5400000101020001' + '09021b00010100c032' + '0904000000fe010204' + '09210b ff00 0004 1001'.replace(/ /g, ''));
    }
    control(type, req, value, index, dataOrLen) {
      if (this.gone) throw new Error('périphérique USB déconnecté');
      const IN = type === 0xA1;
      if (req === 3 && IN) { // GETSTATUS
        let st = this.state, poll = 2;
        if (this.state === 3) { this.state = 4; st = 4; }
        else if (this.state === 4) { this.state = 5; st = 5; }
        else if (this.state === 6) { this.state = 7; st = 7; poll = 20; }
        else if (this.state === 7) {
          const fw = this.finish();
          if (!fw) { this.state = 10; this.status = 2; st = 10; }
          else { this.state = 8; st = 8; setTimeout(() => this.reboot(fw), 40); }
        }
        return new Uint8Array([this.status, poll, 0, 0, st, 0]);
      }
      if (req === 5 && IN) return new Uint8Array([this.state]);
      if (req === 4) { this.status = 0; this.state = 2; return 0; }
      if (req === 6) { if (this.state !== 10) this.state = 2; return 0; }
      if (req === 1) { // DNLOAD
        const d = dataOrLen;
        if (!d.length) {
          if (this.state !== 5) { this.state = 10; this.status = 9; throw new Error('requête refusée (stall)'); }
          this.state = 6; return 0;
        }
        if (this.state !== 2 && this.state !== 5) { this.state = 10; this.status = 15; throw new Error('requête refusée (stall)'); }
        if (value !== this.buf.length) { this.state = 10; this.status = 9; throw new Error('requête refusée (stall)'); }
        this.buf.push(Uint8Array.from(d));
        this.state = 3;
        return d.length;
      }
      throw new Error('requête ' + req + ' non gérée');
    }
    finish() {
      const all = U.concat(this.buf);
      const txt = String.fromCharCode.apply(null, all.subarray(0, Math.min(all.length, 4096)));
      const m = /ECNODE-FW:([^\0\n]+)/.exec(txt);
      return m ? m[1].trim() : null;
    }
    reboot(fw) {
      this.gone = true;
      this.node.fw = fw;
      this.node.mode = 'app';
      this.node._params = null;
      if (this.node.onModeChange) this.node.onModeChange('app');
    }
  }

  /** Fichier de firmware de démonstration (DFU 1.1 avec suffixe) */
  SimNode.demoFirmware = function (date, size) {
    const body = new Uint8Array(size || 20000);
    for (let i = 0; i < body.length; i++) body[i] = (i * 31 + 7) & 255;
    body.set(U.utf8('ECNODE-FW:' + date + '\n'), 64);
    const suf = new Uint8Array(16);
    suf.set([0xff, 0xff, 0xff, 0xff, 0xc9, 0x1f, 0x10, 0x01, 0x55, 0x46, 0x44, 16], 0);
    const all = U.concat([body, suf]);
    const crc = U.crc32(all, 0, all.length - 4, true);
    all[all.length - 4] = crc & 255; all[all.length - 3] = (crc >>> 8) & 255; all[all.length - 2] = (crc >>> 16) & 255; all[all.length - 1] = (crc >>> 24) & 255;
    return all;
  };

  const Sim = { SimNode, SimDfu };

  /** Parc de démonstration */
  Sim.demoFleet = function () {
    return [
      new SimNode({ model: 4, serial: 'EC240412', fw: 'Mar 3 2025', state: { ipMode: 'static', ip: '2.0.0.11', longName: 'Node Jardin Face', shortName: 'JAR-FACE', ports: [{ univOut: 0 }, { univOut: 1 }, { univOut: 2 }, { univOut: 3 }] } }),
      new SimNode({ model: 4, serial: 'EC240413', fw: 'Oct 10 2024', state: { ipMode: 'static', ip: '2.0.0.12', longName: 'Node Cour Face', shortName: 'COUR-FACE', ports: [{ univOut: 4 }, { univOut: 5 }, { univOut: 6 }, { univOut: 7 }] } }),
      new SimNode({ model: 2, serial: 'EC250201', fw: 'Mar 3 2025', state: { ipMode: 'static', ip: '2.0.0.21', longName: 'Node Perches', shortName: 'PERCHES', ports: [{ univOut: 8 }, { univOut: 9 }] } }),
      new SimNode({ model: 2, serial: 'EC250202', fw: 'Mar 3 2025', artAddress: false, ipProg: false, state: { ipMode: 'static', ip: '2.0.0.22', longName: 'Node Lointain', shortName: 'LOINTAIN', loginPage: true, login: 'admin', pass: 'regie', ports: [{ univOut: 10 }, { dir: 'in', univIn: 10 }] } }),
      new SimNode({ model: 1, serial: 'EC250105', fw: 'Mar 3 2025', state: { ipMode: 'static', ip: '2.0.0.31', longName: 'Node Face Salle', shortName: 'SALLE', ports: [{ univOut: 12 }] } }),
      new SimNode({ model: 1, serial: 'EC240107', fw: 'Jan 15 2024', hasDfu: true, state: { ipMode: 'static', ip: '2.0.0.32', longName: 'Node Rampe', shortName: 'RAMPE', ports: [{ univOut: 12 }] } }),
      new SimNode({ model: 4, family: '2026', serial: 'EC260401', fw: 'Jul 15 2026', state: { ipMode: 'static', ip: '2.0.0.41', longName: 'Node Plateau 2026', shortName: 'PLATEAU', protocol: 'sacn', outMode: 'fixed', fps: 40, ports: [{ univOut: 13 }, { univOut: 14 }, { univOut: 15 }, { univOut: 16 }] } }),
      new SimNode({ model: 1, serial: 'EC250199', fw: 'Mar 3 2025', state: { ipMode: 'dhcp', longName: 'Electroconcept Node 1', shortName: 'Node1', ports: [{ univOut: 0 }] } })
    ];
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = Sim;
  else root.Sim = Sim;
})(typeof self !== 'undefined' ? self : this);
