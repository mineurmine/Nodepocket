/*
 * Node Pocket — gestion des nodes DMX (Art-Net / sACN) depuis Android.
 * Développé par 3DP.
 */
package fr.nodepocket;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Accès USB : liste des périphériques, autorisations, HID (protocole dmx-tools d'Electroconcept)
 * et transferts de contrôle bruts (mise à jour DFU).
 * Chaque périphérique ouvert a son propre fil d'exécution : les échanges restent dans l'ordre.
 */
final class UsbHub {

    interface Events {
        void onUsbEvent(String type, JSONObject detail);
    }

    static final String ACTION_PERMISSION = "fr.nodepocket.USB_PERMISSION";

    private final Context ctx;
    private final UsbManager mgr;
    private final Events events;
    private final Map<Integer, Link> links = new HashMap<>();
    private int nextHandle = 1;
    private String lastError = "";

    /** Un périphérique ouvert */
    static final class Link {
        UsbDevice device;
        UsbDeviceConnection conn;
        UsbInterface iface;
        UsbEndpoint in;
        UsbEndpoint out;
        boolean hid;
        final ExecutorService worker = Executors.newSingleThreadExecutor();
    }

    private final BroadcastReceiver permissionReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            UsbDevice d = deviceExtra(i);
            boolean granted = i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
            JSONObject o = new JSONObject();
            try {
                o.put("name", d != null ? d.getDeviceName() : "");
                o.put("granted", granted);
            } catch (Exception ignored) {
            }
            events.onUsbEvent("permission", o);
        }
    };

    private final BroadcastReceiver plugReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            UsbDevice d = deviceExtra(i);
            if (d == null) return;
            boolean attached = UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(i.getAction());
            if (!attached) closeDevice(d.getDeviceName());
            events.onUsbEvent(attached ? "attached" : "detached", describe(d, false));
        }
    };

    UsbHub(Context ctx, Events events) {
        this.ctx = ctx;
        this.events = events;
        this.mgr = (UsbManager) ctx.getSystemService(Context.USB_SERVICE);
        IntentFilter fp = new IntentFilter(ACTION_PERMISSION);
        IntentFilter fu = new IntentFilter();
        fu.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        fu.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if (Build.VERSION.SDK_INT >= 33) {
            ctx.registerReceiver(permissionReceiver, fp, Context.RECEIVER_NOT_EXPORTED);
            ctx.registerReceiver(plugReceiver, fu, Context.RECEIVER_EXPORTED);
        } else {
            ctx.registerReceiver(permissionReceiver, fp);
            ctx.registerReceiver(plugReceiver, fu);
        }
    }

    @SuppressWarnings("deprecation")
    static UsbDevice deviceExtra(Intent i) {
        if (i == null) return null;
        if (Build.VERSION.SDK_INT >= 33) return i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice.class);
        return i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
    }

    String lastError() {
        return lastError;
    }

    boolean available() {
        return mgr != null;
    }

    // ------------------------------------------------------------ liste

    JSONObject describe(UsbDevice d, boolean withStrings) {
        JSONObject o = new JSONObject();
        try {
            o.put("name", d.getDeviceName());
            o.put("vid", d.getVendorId());
            o.put("pid", d.getProductId());
            o.put("cls", d.getDeviceClass());
            o.put("sub", d.getDeviceSubclass());
            o.put("proto", d.getDeviceProtocol());
            boolean perm = mgr != null && mgr.hasPermission(d);
            o.put("permission", perm);
            if (withStrings) {
                try {
                    o.put("manufacturer", d.getManufacturerName());
                    o.put("product", d.getProductName());
                    o.put("version", d.getVersion());
                    if (perm) o.put("serial", d.getSerialNumber());
                } catch (Exception ignored) {
                    // lecture des textes refusée sans autorisation
                }
            }
            JSONArray ifs = new JSONArray();
            for (int i = 0; i < d.getInterfaceCount(); i++) {
                UsbInterface f = d.getInterface(i);
                JSONObject fi = new JSONObject();
                fi.put("id", f.getId());
                fi.put("alt", f.getAlternateSetting());
                fi.put("cls", f.getInterfaceClass());
                fi.put("sub", f.getInterfaceSubclass());
                fi.put("proto", f.getInterfaceProtocol());
                if (withStrings) {
                    try {
                        fi.put("label", f.getName());
                    } catch (Exception ignored) {
                    }
                }
                JSONArray eps = new JSONArray();
                for (int e = 0; e < f.getEndpointCount(); e++) {
                    UsbEndpoint ep = f.getEndpoint(e);
                    JSONObject eo = new JSONObject();
                    eo.put("addr", ep.getAddress());
                    eo.put("type", ep.getType());
                    eo.put("dir", ep.getDirection() == UsbConstants.USB_DIR_IN ? "in" : "out");
                    eo.put("max", ep.getMaxPacketSize());
                    eps.put(eo);
                }
                fi.put("endpoints", eps);
                ifs.put(fi);
            }
            o.put("interfaces", ifs);
        } catch (Exception ignored) {
        }
        return o;
    }

    String list() {
        JSONArray a = new JSONArray();
        if (mgr == null) return a.toString();
        for (UsbDevice d : mgr.getDeviceList().values()) a.put(describe(d, true));
        return a.toString();
    }

    private UsbDevice find(String name) {
        if (mgr == null || name == null) return null;
        for (UsbDevice d : mgr.getDeviceList().values()) if (name.equals(d.getDeviceName())) return d;
        return null;
    }

    boolean requestPermission(String name) {
        UsbDevice d = find(name);
        if (d == null) return false;
        if (mgr.hasPermission(d)) {
            JSONObject o = new JSONObject();
            try {
                o.put("name", name);
                o.put("granted", true);
            } catch (Exception ignored) {
            }
            events.onUsbEvent("permission", o);
            return true;
        }
        Intent i = new Intent(ACTION_PERMISSION);
        i.setPackage(ctx.getPackageName());
        int flags = Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0;
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 0, i, flags | PendingIntent.FLAG_UPDATE_CURRENT);
        mgr.requestPermission(d, pi);
        return true;
    }

    // ------------------------------------------------------------ ouverture

    /** Ouvre l'interface HID d'un périphérique ; renvoie un numéro (>0) ou -1 (voir lastError) */
    synchronized int openHid(String name) {
        UsbDevice d = find(name);
        if (d == null) return fail("périphérique absent");
        if (!mgr.hasPermission(d)) return fail("autorisation USB manquante");
        UsbInterface hidIf = null;
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface f = d.getInterface(i);
            if (f.getInterfaceClass() == UsbConstants.USB_CLASS_HID) {
                hidIf = f;
                break;
            }
        }
        if (hidIf == null) return fail("aucune interface HID");
        UsbDeviceConnection c = mgr.openDevice(d);
        if (c == null) return fail("ouverture refusée par Android");
        if (!c.claimInterface(hidIf, true)) {
            c.close();
            return fail("interface HID occupée");
        }
        Link l = new Link();
        l.device = d;
        l.conn = c;
        l.iface = hidIf;
        l.hid = true;
        for (int e = 0; e < hidIf.getEndpointCount(); e++) {
            UsbEndpoint ep = hidIf.getEndpoint(e);
            if (ep.getType() != UsbConstants.USB_ENDPOINT_XFER_INT && ep.getType() != UsbConstants.USB_ENDPOINT_XFER_BULK) continue;
            if (ep.getDirection() == UsbConstants.USB_DIR_IN && l.in == null) l.in = ep;
            if (ep.getDirection() == UsbConstants.USB_DIR_OUT && l.out == null) l.out = ep;
        }
        if (l.in == null) {
            c.releaseInterface(hidIf);
            c.close();
            return fail("pas d'entrée HID");
        }
        int h = nextHandle++;
        links.put(h, l);
        return h;
    }

    /** Ouvre une interface pour des transferts de contrôle (DFU) */
    synchronized int openRaw(String name, int ifaceId) {
        UsbDevice d = find(name);
        if (d == null) return fail("périphérique absent");
        if (!mgr.hasPermission(d)) return fail("autorisation USB manquante");
        UsbDeviceConnection c = mgr.openDevice(d);
        if (c == null) return fail("ouverture refusée par Android");
        UsbInterface f = null;
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            if (d.getInterface(i).getId() == ifaceId) {
                f = d.getInterface(i);
                break;
            }
        }
        if (f != null && !c.claimInterface(f, true)) {
            c.close();
            return fail("interface occupée");
        }
        Link l = new Link();
        l.device = d;
        l.conn = c;
        l.iface = f;
        int h = nextHandle++;
        links.put(h, l);
        return h;
    }

    private int fail(String why) {
        lastError = why;
        return -1;
    }

    synchronized String rawDescriptors(int h) {
        Link l = links.get(h);
        if (l == null) return "";
        byte[] b = l.conn.getRawDescriptors();
        return b == null ? "" : Hex.enc(b, b.length);
    }

    synchronized void close(int h) {
        Link l = links.remove(h);
        if (l != null) shut(l);
    }

    private void shut(Link l) {
        l.worker.shutdownNow();
        try {
            if (l.iface != null) l.conn.releaseInterface(l.iface);
        } catch (Exception ignored) {
        }
        try {
            l.conn.close();
        } catch (Exception ignored) {
        }
    }

    synchronized void closeDevice(String name) {
        Integer[] keys = links.keySet().toArray(new Integer[0]);
        for (Integer k : keys) {
            Link l = links.get(k);
            if (l != null && l.device.getDeviceName().equals(name)) {
                links.remove(k);
                shut(l);
            }
        }
    }

    synchronized void closeAll() {
        for (Link l : links.values()) shut(l);
        links.clear();
    }

    void destroy() {
        closeAll();
        try {
            ctx.unregisterReceiver(permissionReceiver);
        } catch (Exception ignored) {
        }
        try {
            ctx.unregisterReceiver(plugReceiver);
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------ transferts

    interface Result {
        void done(String hexOrNull, String error);
    }

    /** Envoie un rapport HID de 64 octets puis attend le rapport d'entrée suivant */
    void hidXfer(int h, final byte[] req, final int timeoutMs, final Result cb) {
        final Link l;
        synchronized (this) {
            l = links.get(h);
        }
        if (l == null || !l.hid) {
            cb.done(null, "périphérique USB fermé");
            return;
        }
        try {
            l.worker.execute(() -> {
                try {
                    byte[] out = new byte[64];
                    System.arraycopy(req, 0, out, 0, Math.min(64, req.length));
                    int w;
                    if (l.out != null) {
                        w = l.conn.bulkTransfer(l.out, out, out.length, timeoutMs);
                    } else {
                        // pas d'endpoint de sortie : SET_REPORT (sortie, rapport 0)
                        w = l.conn.controlTransfer(0x21, 0x09, 0x0200, l.iface.getId(), out, out.length, timeoutMs);
                    }
                    if (w < 0) {
                        cb.done(null, "écriture USB impossible");
                        return;
                    }
                    int size = Math.max(64, l.in.getMaxPacketSize());
                    byte[] in = new byte[size];
                    long t0 = System.currentTimeMillis();
                    int r;
                    do {
                        r = l.conn.bulkTransfer(l.in, in, in.length, timeoutMs);
                    } while (r == 0 && System.currentTimeMillis() - t0 < timeoutMs);
                    if (r <= 0) {
                        cb.done(null, "timeout : le node ne répond pas");
                        return;
                    }
                    cb.done(Hex.enc(in, r), null);
                } catch (Exception e) {
                    cb.done(null, "erreur USB : " + e.getMessage());
                }
            });
        } catch (Exception e) {
            cb.done(null, "périphérique USB fermé");
        }
    }

    /** Vide les rapports d'entrée en attente (après une réponse perdue) */
    void hidFlush(int h, final Result cb) {
        final Link l;
        synchronized (this) {
            l = links.get(h);
        }
        if (l == null) {
            cb.done("", null);
            return;
        }
        try {
            l.worker.execute(() -> {
                byte[] in = new byte[Math.max(64, l.in.getMaxPacketSize())];
                int n = 0;
                while (n < 64 && l.conn.bulkTransfer(l.in, in, in.length, 15) > 0) n++;
                cb.done(String.valueOf(n), null);
            });
        } catch (Exception e) {
            cb.done("", null);
        }
    }

    /** Transfert de contrôle brut ; type & 0x80 = lecture de "length" octets */
    void control(int h, final int type, final int request, final int value, final int index,
                 final byte[] data, final int length, final int timeoutMs, final Result cb) {
        final Link l;
        synchronized (this) {
            l = links.get(h);
        }
        if (l == null) {
            cb.done(null, "périphérique USB fermé (déconnecté)");
            return;
        }
        try {
            l.worker.execute(() -> {
                try {
                    boolean in = (type & 0x80) != 0;
                    byte[] buf = in ? new byte[Math.max(0, length)] : (data == null ? new byte[0] : data);
                    int r = l.conn.controlTransfer(type, request, value, index, buf, buf.length, timeoutMs);
                    if (r < 0) {
                        cb.done(null, "transfert USB refusé (-1)");
                        return;
                    }
                    cb.done(in ? Hex.enc(buf, r) : String.valueOf(r), null);
                } catch (Exception e) {
                    cb.done(null, "erreur USB : " + e.getMessage());
                }
            });
        } catch (Exception e) {
            cb.done(null, "périphérique USB fermé (déconnecté)");
        }
    }

    /** Petit utilitaire hexadécimal */
    static final class Hex {
        private static final char[] D = "0123456789abcdef".toCharArray();

        static String enc(byte[] b, int n) {
            char[] c = new char[n * 2];
            for (int i = 0; i < n; i++) {
                c[i * 2] = D[(b[i] >> 4) & 15];
                c[i * 2 + 1] = D[b[i] & 15];
            }
            return new String(c);
        }

        static byte[] dec(String s) {
            if (s == null) return new byte[0];
            int n = s.length() / 2;
            byte[] b = new byte[n];
            for (int i = 0; i < n; i++) b[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
            return b;
        }
    }
}
