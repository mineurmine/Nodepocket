/*
 * Node Pocket — gestion des nodes DMX (Art-Net / sACN) depuis Android.
 * Développé par 3DP.
 */
package fr.nodepocket;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Insets;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Écran unique : une WebView qui affiche l'interface (assets/index.html) et le pont "AndroidBridge"
 * vers l'USB (HID, DFU), le réseau (Art-Net, sACN, HTTP), les pages web des nodes et les fichiers.
 * Les résultats reviennent dans la page par window.NP.*.
 */
public class MainActivity extends Activity implements UsbHub.Events, NetIO.Events, PageHost.Events {
    /** Signature du développeur */
    static final String AUTHOR = "Développé par 3DP";


    private static final int REQ_SAVE = 51;
    private static final int REQ_OPEN = 52;

    private FrameLayout root;
    private WebView web;
    private UsbHub usb;
    private NetIO net;
    private PageHost pages;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private boolean pageReady = false;
    private final List<String> pendingJs = new ArrayList<>();
    private volatile boolean textInputActive = false;
    private boolean immersive = false;
    private byte[] pendingSave = null;
    private int pendingOpenId = 0;
    private String launchUsb = null;

    private final float[] lastAxes = new float[AXES.length];
    private static final int[] AXES = {
            MotionEvent.AXIS_X, MotionEvent.AXIS_Y, MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ,
            MotionEvent.AXIS_HAT_X, MotionEvent.AXIS_HAT_Y, MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_RTRIGGER
    };
    private static final String[] AXIS_NAMES = {"X", "Y", "Z", "RZ", "HAT_X", "HAT_Y", "LT", "RT"};

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(14, 15, 18));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(14, 15, 18));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        // Android 15 : affichage bord à bord forcé -> on décale le contenu des barres système
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
                return insets;
            });
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        WebView.setWebContentsDebuggingEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                for (String js : pendingJs) web.evaluateJavascript(js, null);
                pendingJs.clear();
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        usb = new UsbHub(this, this);
        net = new NetIO(this, this);
        pages = new PageHost(this, root, this);
        handleIntent(getIntent());
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    /** Lancée par le branchement d'un node en USB : on le signale à l'interface */
    private void handleIntent(Intent i) {
        if (i == null || !UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(i.getAction())) return;
        UsbDevice d = UsbHub.deviceExtra(i);
        if (d == null) return;
        launchUsb = d.getDeviceName();
        onUsbEvent("attached", usb.describe(d, false));
    }

    @Override
    protected void onPause() {
        if (pageReady) web.evaluateJavascript("window.NP&&NP.flush&&NP.flush()", null);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        usb.destroy();
        net.destroy();
        pages.destroy();
        web.removeJavascriptInterface("AndroidBridge");
        web.destroy();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && immersive) applyImmersive(true);
    }

    // ------------------------------------------------------------ vers l'interface

    private void js(final String code) {
        ui.post(() -> {
            if (pageReady) web.evaluateJavascript(code, null);
            else pendingJs.add(code);
        });
    }

    private static String q(String s) {
        return s == null ? "null" : JSONObject.quote(s);
    }

    private void cb(int id, String err, String resultJson) {
        js("window.NP&&NP.cb(" + id + "," + q(err) + "," + (resultJson == null ? "null" : resultJson) + ")");
    }

    @Override
    public void onUsbEvent(String type, JSONObject detail) {
        js("window.NP&&NP.usbEvent(" + q(type) + "," + detail + ")");
    }

    @Override
    public void onUdp(String b64, String srcIp, int srcPort) {
        js("window.NP&&NP.udp(" + q(b64) + "," + q(srcIp) + "," + srcPort + ")");
    }

    @Override
    public void onNetStatus(String state, String detail) {
        js("window.NP&&NP.netStatus(" + q(state) + "," + q(detail) + ")");
    }

    @Override
    public void onPageEvent(String sid, String type, JSONObject detail) {
        js("window.NP&&NP.pageEvent(" + q(sid) + "," + q(type) + "," + detail + ")");
    }

    @Override
    public void onEvalResult(int id, String value) {
        // value est déjà du JSON (résultat de evaluateJavascript)
        cb(id, null, value == null ? "null" : value);
    }

    // ------------------------------------------------------------ boutons physiques (console portable)

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        int action = e.getAction();
        if (action != KeyEvent.ACTION_DOWN && action != KeyEvent.ACTION_UP) return super.dispatchKeyEvent(e);
        String shown = pages.visibleSid();
        if (shown != null) {
            // page du node affichée : B = retour / fermer, le reste fonctionne normalement
            if (code == KeyEvent.KEYCODE_BUTTON_B) {
                if (action == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0 && !pages.goBack(shown)) pages.show(shown, false, null);
                return true;
            }
            return super.dispatchKeyEvent(e);
        }
        int src = e.getSource();
        InputDevice dev = e.getDevice();
        boolean physical = dev != null && !dev.isVirtual();
        boolean pad = (src & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                || (src & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK;
        boolean dpad = (src & InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD;
        boolean forward = KeyEvent.isGamepadButton(code) || (physical && (pad || dpad) && code != KeyEvent.KEYCODE_BACK);
        if (textInputActive && !KeyEvent.isGamepadButton(code)) forward = false;
        if (forward) {
            js("window.NP&&NP.hwKey(" + code + "," + q(KeyEvent.keyCodeToString(code)) + ","
                    + (action == KeyEvent.ACTION_DOWN ? 1 : 0) + "," + e.getRepeatCount() + ")");
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent ev) {
        int src = ev.getSource();
        if (pages.visibleSid() == null && (src & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                && ev.getAction() == MotionEvent.ACTION_MOVE) {
            StringBuilder sb = new StringBuilder("{");
            boolean changed = false;
            for (int i = 0; i < AXES.length; i++) {
                float v = ev.getAxisValue(AXES[i]);
                if (Math.abs(v - lastAxes[i]) > 0.01f) changed = true;
                lastAxes[i] = v;
                if (i > 0) sb.append(',');
                sb.append('"').append(AXIS_NAMES[i]).append("\":").append(Math.round(v * 100f) / 100f);
            }
            sb.append('}');
            if (changed) js("window.NP&&NP.hwAxes(" + sb + ")");
            return true;
        }
        return super.dispatchGenericMotionEvent(ev);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        String sid = pages.visibleSid();
        if (sid != null) {
            if (!pages.goBack(sid)) pages.show(sid, false, null);
            return;
        }
        if (!pageReady) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript("window.NP?NP.onBack():false", value -> {
            if (!"true".equals(value)) MainActivity.super.onBackPressed();
        });
    }

    @SuppressWarnings("deprecation")
    private void applyImmersive(boolean on) {
        immersive = on;
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c == null) return;
            if (on) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            } else c.show(WindowInsets.Type.systemBars());
        } else {
            View d = getWindow().getDecorView();
            d.setSystemUiVisibility(on ? (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN) : 0);
        }
    }

    // ------------------------------------------------------------ fichiers

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Uri uri = data != null ? data.getData() : null;
        if (requestCode == REQ_SAVE) {
            byte[] content = pendingSave;
            pendingSave = null;
            if (resultCode != RESULT_OK || uri == null || content == null) return;
            try {
                OutputStream os;
                try {
                    os = getContentResolver().openOutputStream(uri, "wt");
                } catch (Exception ex) {
                    os = getContentResolver().openOutputStream(uri, "w");
                }
                if (os == null) throw new Exception("flux indisponible");
                os.write(content);
                os.close();
                js("window.NP&&NP.toast('Fichier enregistré')");
            } catch (Exception ex) {
                js("window.NP&&NP.toast(" + q("Enregistrement impossible : " + ex.getMessage()) + ")");
            }
        } else if (requestCode == REQ_OPEN) {
            int id = pendingOpenId;
            pendingOpenId = 0;
            if (resultCode != RESULT_OK || uri == null) {
                cb(id, "annulé", null);
                return;
            }
            try {
                String name = "fichier";
                try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
                    if (c != null && c.moveToFirst()) {
                        int col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        if (col >= 0) name = c.getString(col);
                    }
                }
                InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) throw new Exception("flux indisponible");
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] b = new byte[16384];
                int n;
                while ((n = is.read(b)) > 0) {
                    bo.write(b, 0, n);
                    if (bo.size() > 16 * 1024 * 1024) throw new Exception("fichier trop gros");
                }
                is.close();
                JSONObject o = new JSONObject();
                o.put("name", name);
                o.put("b64", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP));
                cb(id, null, o.toString());
            } catch (Exception ex) {
                cb(id, "lecture impossible : " + ex.getMessage(), null);
            }
        }
    }

    private File stateFile() {
        return new File(getFilesDir(), "state.json");
    }

    // ------------------------------------------------------------ pont JavaScript

    final class Bridge {

        // ---- état de l'appli (fichier interne, écriture atomique)
        @JavascriptInterface
        public String loadState() {
            File f = stateFile();
            if (!f.exists()) f = new File(getFilesDir(), "state.bak");
            if (!f.exists()) return "";
            try (FileInputStream in = new FileInputStream(f)) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] b = new byte[16384];
                int n;
                while ((n = in.read(b)) > 0) bo.write(b, 0, n);
                return bo.toString("UTF-8");
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean saveState(String json) {
            try {
                File tmp = new File(getFilesDir(), "state.tmp");
                try (FileOutputStream out = new FileOutputStream(tmp)) {
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                    out.getFD().sync();
                }
                File cur = stateFile();
                File bak = new File(getFilesDir(), "state.bak");
                if (cur.exists()) {
                    //noinspection ResultOfMethodCallIgnored
                    bak.delete();
                    //noinspection ResultOfMethodCallIgnored
                    cur.renameTo(bak);
                }
                return tmp.renameTo(cur);
            } catch (Exception e) {
                return false;
            }
        }

        // ---- appareil
        @SuppressWarnings("deprecation")
        @JavascriptInterface
        public String getAppVersion() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "?";
            }
        }

        @JavascriptInterface
        public String getDeviceInfo() {
            return Build.MANUFACTURER + " " + Build.MODEL + " — Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")";
        }

        @JavascriptInterface
        public String getAuthor() {
            return AUTHOR;
        }

        @JavascriptInterface
        public boolean hasGamepad() {
            for (int id : InputDevice.getDeviceIds()) {
                InputDevice d = InputDevice.getDevice(id);
                if (d == null || d.isVirtual()) continue;
                int src = d.getSources();
                if ((src & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                        || (src & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) return true;
            }
            return false;
        }

        @JavascriptInterface
        public String launchUsbDevice() {
            String s = launchUsb;
            launchUsb = null;
            return s == null ? "" : s;
        }

        @SuppressWarnings("deprecation")
        @JavascriptInterface
        public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(Math.max(1, ms), VibrationEffect.DEFAULT_AMPLITUDE));
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void setKeepScreenOn(final boolean on) {
            ui.post(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void setImmersive(final boolean on) {
            ui.post(() -> applyImmersive(on));
        }

        @JavascriptInterface
        public void setOrientation(final String mode) {
            ui.post(() -> {
                int o = ActivityInfo.SCREEN_ORIENTATION_FULL_USER;
                if ("landscape".equals(mode)) o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
                else if ("portrait".equals(mode)) o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT;
                setRequestedOrientation(o);
            });
        }

        @JavascriptInterface
        public void setTextInputActive(boolean on) {
            textInputActive = on;
        }

        @JavascriptInterface
        public void toast(final String msg) {
            ui.post(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void exitApp() {
            ui.post(MainActivity.this::finishAndRemoveTask);
        }

        // ---- fichiers
        @JavascriptInterface
        public void saveFile(final String content, final String name, final String mime, final boolean base64) {
            ui.post(() -> {
                pendingSave = base64 ? Base64.decode(content, Base64.DEFAULT) : content.getBytes(StandardCharsets.UTF_8);
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                i.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(i, REQ_SAVE);
                } catch (Exception e) {
                    pendingSave = null;
                    Toast.makeText(MainActivity.this, "Aucune app de fichiers", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void pickFile(final int id, final String mime) {
            ui.post(() -> {
                if (pendingOpenId != 0) cb(pendingOpenId, "annulé", null);
                pendingOpenId = id;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime == null || mime.isEmpty() ? "*/*" : mime);
                try {
                    startActivityForResult(i, REQ_OPEN);
                } catch (Exception e) {
                    pendingOpenId = 0;
                    cb(id, "aucune app de fichiers", null);
                }
            });
        }

        @JavascriptInterface
        public void shareText(final String text, final String subject) {
            ui.post(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                if (subject != null) i.putExtra(Intent.EXTRA_SUBJECT, subject);
                try {
                    startActivity(Intent.createChooser(i, "Partager"));
                } catch (Exception ignored) {
                }
            });
        }

        // ---- réseau
        @JavascriptInterface
        public String netInfo() {
            return NetIO.netInfo();
        }

        @JavascriptInterface
        public void udpStart() {
            net.startUdp();
        }

        @JavascriptInterface
        public void udpSend(String ip, int port, String b64) {
            net.sendUdp(ip, port, Base64.decode(b64, Base64.DEFAULT));
        }

        @JavascriptInterface
        public void monitor(boolean on, String sacnCsv) {
            net.monitor(on, sacnCsv);
        }

        @JavascriptInterface
        public String monitorSnapshot() {
            return net.monitorSnapshot();
        }

        @JavascriptInterface
        public void http(final int id, String method, String url, String headersJson, String bodyB64, int timeoutMs) {
            byte[] body = bodyB64 == null || bodyB64.isEmpty() ? null : Base64.decode(bodyB64, Base64.DEFAULT);
            net.http(method, url, headersJson, body, timeoutMs, (status, headers, b64, err) -> {
                JSONObject o = new JSONObject();
                try {
                    o.put("status", status);
                    o.put("headers", new JSONObject(headers));
                    o.put("b64", b64);
                } catch (Exception ignored) {
                }
                cb(id, err, o.toString());
            });
        }

        @JavascriptInterface
        public void tcpProbe(final int id, String ip, int port, int timeoutMs) {
            net.tcpProbe(ip, port, timeoutMs, (open, ms, err) -> cb(id, null, "{\"open\":" + open + ",\"ms\":" + ms + "}"));
        }

        // ---- USB
        @JavascriptInterface
        public boolean usbAvailable() {
            return usb.available() && getPackageManager().hasSystemFeature("android.hardware.usb.host");
        }

        @JavascriptInterface
        public String usbList() {
            return usb.list();
        }

        @JavascriptInterface
        public boolean usbPermission(String name) {
            return usb.requestPermission(name);
        }

        @JavascriptInterface
        public int hidOpen(String name) {
            return usb.openHid(name);
        }

        @JavascriptInterface
        public String usbLastError() {
            return usb.lastError();
        }

        @JavascriptInterface
        public void hidXfer(final int id, int h, String hex, int timeoutMs) {
            usb.hidXfer(h, UsbHub.Hex.dec(hex), timeoutMs, (res, err) -> cb(id, err, res == null ? null : q(res)));
        }

        @JavascriptInterface
        public void hidFlush(final int id, int h) {
            usb.hidFlush(h, (res, err) -> cb(id, err, q(res)));
        }

        @JavascriptInterface
        public int usbOpenRaw(String name, int iface) {
            return usb.openRaw(name, iface);
        }

        @JavascriptInterface
        public String usbRawDescriptors(int h) {
            return usb.rawDescriptors(h);
        }

        @JavascriptInterface
        public void usbControl(final int id, int h, int type, int req, int value, int index, String hex, int length, int timeoutMs) {
            usb.control(h, type, req, value, index, UsbHub.Hex.dec(hex), length, timeoutMs, (res, err) -> cb(id, err, res == null ? null : q(res)));
        }

        @JavascriptInterface
        public void usbClose(int h) {
            usb.close(h);
        }

        // ---- pages web des nodes
        @JavascriptInterface
        public void pageOpen(final String sid, final String url, final String user, final String pass) {
            ui.post(() -> pages.open(sid, url, user, pass));
        }

        @JavascriptInterface
        public void pageEval(final int id, final String sid, final String code) {
            ui.post(() -> pages.eval(id, sid, code));
        }

        @JavascriptInterface
        public void pageShow(final String sid, final boolean visible, final String title) {
            ui.post(() -> pages.show(sid, visible, title));
        }

        @JavascriptInterface
        public void pageClose(final String sid) {
            ui.post(() -> pages.close(sid));
        }
    }
}
