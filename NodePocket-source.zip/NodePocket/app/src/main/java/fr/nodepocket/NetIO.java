/*
 * Node Pocket — gestion des nodes DMX (Art-Net / sACN) depuis Android.
 * Développé par 3DP.
 */
package fr.nodepocket;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Réseau : Art-Net (UDP 6454), écoute sACN (UDP 5568 multicast), HTTP et test de présence.
 * Les paquets Art-Net de service (ArtPollReply, ArtIpProgReply…) partent vers l'interface ;
 * les flux DMX (ArtDmx, sACN) restent ici et alimentent le moniteur, interrogé quelques fois par seconde.
 */
final class NetIO {

    interface Events {
        void onUdp(String b64, String srcIp, int srcPort);

        void onNetStatus(String state, String detail);
    }

    private final Context ctx;
    private final Events events;
    private final ExecutorService io = Executors.newCachedThreadPool();
    private volatile DatagramSocket artSock;
    private volatile MulticastSocket sacnSock;
    private Thread artThread, sacnThread;
    private WifiManager.MulticastLock lock;
    private volatile boolean monitorOn = false;
    private final Set<Integer> sacnGroups = new HashSet<>();

    /** Dernier état d'un univers vu sur le réseau */
    static final class Univ {
        String proto;
        int univ;
        String src = "";
        String name = "";
        int prio = -1;
        byte[] data = new byte[0];
        long last;
        int frames;
        long since;
        Set<String> sources = new HashSet<>();
    }

    private final Map<String, Univ> universes = new HashMap<>();

    NetIO(Context ctx, Events events) {
        this.ctx = ctx;
        this.events = events;
    }

    // ------------------------------------------------------------ interfaces

    static String netInfo() {
        JSONArray a = new JSONArray();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress ad = ia.getAddress();
                    if (!(ad instanceof Inet4Address)) continue;
                    JSONObject o = new JSONObject();
                    o.put("name", ni.getName());
                    o.put("ip", ad.getHostAddress());
                    o.put("prefix", ia.getNetworkPrefixLength());
                    InetAddress b = ia.getBroadcast();
                    o.put("broadcast", b != null ? b.getHostAddress() : "");
                    a.put(o);
                }
            }
        } catch (Exception ignored) {
        }
        return a.toString();
    }

    // ------------------------------------------------------------ Art-Net

    synchronized void startUdp() {
        if (artSock != null) return;
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null && lock == null) {
                lock = wm.createMulticastLock("nodepocket");
                lock.setReferenceCounted(false);
                lock.acquire();
            }
        } catch (Exception ignored) {
        }
        DatagramSocket s = null;
        String detail = "port 6454";
        try {
            s = new DatagramSocket(null);
            s.setReuseAddress(true);
            s.setBroadcast(true);
            s.bind(new InetSocketAddress(6454));
        } catch (Exception e) {
            try {
                if (s != null) s.close();
                s = new DatagramSocket();
                s.setBroadcast(true);
                detail = "port 6454 occupé : réponses limitées (port " + s.getLocalPort() + ")";
            } catch (Exception e2) {
                events.onNetStatus("error", "UDP impossible : " + e2.getMessage());
                return;
            }
        }
        artSock = s;
        final DatagramSocket sock = s;
        artThread = new Thread(() -> {
            byte[] buf = new byte[1500];
            while (!sock.isClosed()) {
                try {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    sock.receive(p);
                    handleArt(p);
                } catch (Exception e) {
                    if (sock.isClosed()) break;
                }
            }
        }, "artnet-rx");
        artThread.setDaemon(true);
        artThread.start();
        events.onNetStatus("ready", detail);
    }

    private void handleArt(DatagramPacket p) {
        byte[] b = p.getData();
        int n = p.getLength();
        if (n < 10 || b[0] != 'A' || b[1] != 'r' || b[2] != 't' || b[3] != '-') return;
        int op = (b[8] & 255) | ((b[9] & 255) << 8);
        String src = p.getAddress().getHostAddress();
        if (op == 0x5000) { // ArtDmx : moniteur
            if (!monitorOn || n < 18) return;
            int uni = (b[14] & 255) | ((b[15] & 0x7f) << 8);
            int len = Math.min(512, Math.min(((b[16] & 255) << 8) | (b[17] & 255), n - 18));
            byte[] d = new byte[Math.max(0, len)];
            System.arraycopy(b, 18, d, 0, d.length);
            store("artnet", uni, src, "", -1, d);
            return;
        }
        if (op == 0x2000 || op == 0x5200 || op == 0x5100) return; // ArtPoll des consoles, ArtSync, ArtNzs
        byte[] copy = new byte[n];
        System.arraycopy(b, 0, copy, 0, n);
        events.onUdp(Base64.encodeToString(copy, Base64.NO_WRAP), src, p.getPort());
    }

    private void store(String proto, int uni, String src, String name, int prio, byte[] d) {
        String k = proto + ":" + uni;
        synchronized (universes) {
            Univ u = universes.get(k);
            long now = System.currentTimeMillis();
            if (u == null) {
                u = new Univ();
                u.proto = proto;
                u.univ = uni;
                u.since = now;
                universes.put(k, u);
            }
            if (prio < 0 || prio >= u.prio || now - u.last > 2500) {
                u.data = d;
                u.src = src;
                u.name = name;
                u.prio = prio;
            }
            u.sources.add(src + (name.isEmpty() ? "" : " (" + name + ")"));
            u.last = now;
            u.frames++;
        }
    }

    void sendUdp(final String ip, final int port, final byte[] data) {
        final DatagramSocket s = artSock;
        if (s == null) {
            events.onNetStatus("error", "UDP non démarré");
            return;
        }
        io.execute(() -> {
            try {
                s.send(new DatagramPacket(data, data.length, InetAddress.getByName(ip), port));
            } catch (Exception e) {
                events.onNetStatus("send-error", ip + " : " + e.getMessage());
            }
        });
    }

    // ------------------------------------------------------------ moniteur (Art-Net + sACN)

    synchronized void monitor(boolean on, String sacnCsv) {
        monitorOn = on;
        if (!on) {
            stopSacn();
            synchronized (universes) {
                universes.clear();
            }
            return;
        }
        Set<Integer> want = new HashSet<>();
        if (sacnCsv != null) {
            for (String s : sacnCsv.split(",")) {
                try {
                    int u = Integer.parseInt(s.trim());
                    if (u >= 1 && u <= 63999) want.add(u);
                } catch (Exception ignored) {
                }
            }
        }
        if (want.isEmpty()) {
            stopSacn();
            return;
        }
        try {
            if (sacnSock == null) {
                MulticastSocket ms = new MulticastSocket(null);
                ms.setReuseAddress(true);
                ms.bind(new InetSocketAddress(5568));
                sacnSock = ms;
                final MulticastSocket sock = ms;
                sacnThread = new Thread(() -> {
                    byte[] buf = new byte[700];
                    while (!sock.isClosed()) {
                        try {
                            DatagramPacket p = new DatagramPacket(buf, buf.length);
                            sock.receive(p);
                            handleSacn(p);
                        } catch (Exception e) {
                            if (sock.isClosed()) break;
                        }
                    }
                }, "sacn-rx");
                sacnThread.setDaemon(true);
                sacnThread.start();
            }
            Iterator<Integer> it = sacnGroups.iterator();
            while (it.hasNext()) {
                int u = it.next();
                if (!want.contains(u)) {
                    try {
                        sacnSock.leaveGroup(new InetSocketAddress(group(u), 0), null);
                    } catch (Exception ignored) {
                    }
                    it.remove();
                }
            }
            for (int u : want) {
                if (sacnGroups.contains(u)) continue;
                try {
                    sacnSock.joinGroup(new InetSocketAddress(group(u), 0), null);
                    sacnGroups.add(u);
                } catch (Exception e) {
                    events.onNetStatus("sacn-error", "univers sACN " + u + " : " + e.getMessage());
                }
            }
        } catch (Exception e) {
            events.onNetStatus("sacn-error", "écoute sACN impossible : " + e.getMessage());
        }
    }

    private static InetAddress group(int u) throws Exception {
        return InetAddress.getByName("239.255." + ((u >> 8) & 255) + "." + (u & 255));
    }

    private void stopSacn() {
        MulticastSocket s = sacnSock;
        sacnSock = null;
        sacnGroups.clear();
        if (s != null) s.close();
    }

    private void handleSacn(DatagramPacket p) {
        byte[] b = p.getData();
        int n = p.getLength();
        if (n < 126 || b[4] != 'A' || b[5] != 'S' || b[6] != 'C') return;
        if (b[21] != 4 || b[43] != 2) return;
        int uni = ((b[113] & 255) << 8) | (b[114] & 255);
        int prio = b[108] & 255;
        if (b[125] != 0) return; // seulement les niveaux DMX (start code 0)
        int count = (((b[123] & 255) << 8) | (b[124] & 255)) - 1;
        int len = Math.max(0, Math.min(512, Math.min(count, n - 126)));
        StringBuilder name = new StringBuilder();
        for (int i = 44; i < 108 && b[i] != 0; i++) name.append((char) (b[i] & 255));
        byte[] d = new byte[len];
        System.arraycopy(b, 126, d, 0, len);
        store("sacn", uni, p.getAddress().getHostAddress(), name.toString(), prio, d);
    }

    String monitorSnapshot() {
        JSONArray a = new JSONArray();
        long now = System.currentTimeMillis();
        synchronized (universes) {
            for (Univ u : universes.values()) {
                try {
                    JSONObject o = new JSONObject();
                    o.put("proto", u.proto);
                    o.put("univ", u.univ);
                    o.put("src", u.src);
                    o.put("name", u.name);
                    o.put("prio", u.prio);
                    o.put("age", now - u.last);
                    o.put("frames", u.frames);
                    o.put("since", now - u.since);
                    o.put("sources", new JSONArray(u.sources));
                    o.put("data", Base64.encodeToString(u.data, Base64.NO_WRAP));
                    a.put(o);
                } catch (Exception ignored) {
                }
            }
        }
        return a.toString();
    }

    // ------------------------------------------------------------ HTTP et présence

    interface HttpResult {
        void done(int status, String headersJson, String bodyB64, String error);
    }

    void http(final String method, final String url, final String headersJson, final byte[] body,
              final int timeoutMs, final HttpResult cb) {
        io.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestMethod(method == null || method.isEmpty() ? "GET" : method);
                c.setConnectTimeout(timeoutMs);
                c.setReadTimeout(timeoutMs);
                c.setInstanceFollowRedirects(true);
                c.setUseCaches(false);
                if (headersJson != null && !headersJson.isEmpty()) {
                    JSONObject h = new JSONObject(headersJson);
                    Iterator<String> it = h.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        c.setRequestProperty(k, h.optString(k));
                    }
                }
                if (body != null && body.length > 0) {
                    c.setDoOutput(true);
                    OutputStream os = c.getOutputStream();
                    os.write(body);
                    os.close();
                }
                int status = c.getResponseCode();
                InputStream is = status >= 400 ? c.getErrorStream() : c.getInputStream();
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                if (is != null) {
                    byte[] buf = new byte[8192];
                    int r;
                    while ((r = is.read(buf)) > 0 && bo.size() < 4 * 1024 * 1024) bo.write(buf, 0, r);
                    is.close();
                }
                JSONObject hs = new JSONObject();
                for (Map.Entry<String, List<String>> e : c.getHeaderFields().entrySet()) {
                    if (e.getKey() != null && e.getValue() != null && !e.getValue().isEmpty()) hs.put(e.getKey().toLowerCase(), e.getValue().get(0));
                }
                cb.done(status, hs.toString(), Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP), null);
            } catch (Exception e) {
                cb.done(0, "{}", "", e.getClass().getSimpleName() + " : " + e.getMessage());
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    interface ProbeResult {
        void done(boolean open, int ms, String error);
    }

    /** Le node répond-il sur ce port TCP (80 = page web) ? */
    void tcpProbe(final String ip, final int port, final int timeoutMs, final ProbeResult cb) {
        io.execute(() -> {
            long t0 = System.currentTimeMillis();
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(ip, port), timeoutMs);
                cb.done(true, (int) (System.currentTimeMillis() - t0), null);
            } catch (Exception e) {
                cb.done(false, (int) (System.currentTimeMillis() - t0), e.getClass().getSimpleName());
            }
        });
    }

    synchronized void stop() {
        if (artSock != null) artSock.close();
        artSock = null;
        stopSacn();
        if (lock != null && lock.isHeld()) lock.release();
        lock = null;
    }

    void destroy() {
        stop();
        io.shutdownNow();
    }
}
