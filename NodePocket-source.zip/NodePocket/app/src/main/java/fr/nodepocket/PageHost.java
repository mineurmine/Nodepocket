/*
 * Node Pocket — gestion des nodes DMX (Art-Net / sACN) depuis Android.
 * Développé par 3DP.
 */
package fr.nodepocket;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.HttpAuthHandler;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Pages web des nodes : une WebView par node, invisible quand l'appli lit/écrit les réglages
 * dans la page, plein écran quand on veut voir la page d'origine du node.
 */
final class PageHost {

    interface Events {
        void onPageEvent(String sid, String type, JSONObject detail);

        void onEvalResult(int id, String value);
    }

    static final class Page {
        String sid;
        WebView web;
        LinearLayout frame;
        TextView title;
        String user = "", pass = "";
        int authTries = 0;
        boolean visible = false;
    }

    private final Activity act;
    private final FrameLayout root;
    private final Events events;
    private final Map<String, Page> pages = new HashMap<>();

    PageHost(Activity act, FrameLayout root, Events events) {
        this.act = act;
        this.root = root;
        this.events = events;
        CookieManager.getInstance().setAcceptCookie(true);
    }

    private void emit(String sid, String type, String k, Object v) {
        JSONObject o = new JSONObject();
        try {
            if (k != null) o.put(k, v);
        } catch (Exception ignored) {
        }
        events.onPageEvent(sid, type, o);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private Page create(final String sid) {
        final Page p = new Page();
        p.sid = sid;
        p.web = new WebView(act);
        WebSettings s = p.web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(p.web, true);
        p.web.setBackgroundColor(Color.WHITE);
        p.web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                emit(sid, "started", "url", url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (p.title != null) p.title.setText(view.getTitle() + "  —  " + url);
                emit(sid, "finished", "url", url);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req != null && req.isForMainFrame()) emit(sid, "error", "message", String.valueOf(err.getDescription()));
            }

            @Override
            public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler, String host, String realm) {
                if (p.authTries++ < 1 && p.user != null && !p.user.isEmpty()) {
                    handler.proceed(p.user, p.pass);
                } else {
                    handler.cancel();
                    emit(sid, "auth", "realm", realm);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return false;
            }
        });
        p.web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                emit(sid, "alert", "message", message);
                if (p.visible) return false;
                result.confirm();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                emit(sid, "confirm", "message", message);
                if (p.visible) return false;
                result.confirm();
                return true;
            }
        });

        // cadre plein écran : barre du haut + page
        p.frame = new LinearLayout(act);
        p.frame.setOrientation(LinearLayout.VERTICAL);
        p.frame.setBackgroundColor(Color.rgb(16, 17, 20));
        LinearLayout bar = new LinearLayout(act);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(16, 8, 8, 8);
        p.title = new TextView(act);
        p.title.setTextColor(Color.rgb(220, 220, 220));
        p.title.setTypeface(Typeface.DEFAULT_BOLD);
        p.title.setSingleLine(true);
        p.title.setTextSize(13);
        bar.addView(p.title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button reload = new Button(act);
        reload.setText("↻");
        reload.setOnClickListener(v -> p.web.reload());
        bar.addView(reload);
        Button close = new Button(act);
        close.setText("Fermer");
        close.setOnClickListener(v -> show(sid, false, null));
        bar.addView(close);
        p.frame.addView(bar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        p.frame.addView(p.web, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        // invisible mais mis en page (taille d'écran de tablette pour que la page se dessine normalement)
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(1280, 900);
        root.addView(p.frame, 0, lp);
        p.frame.setVisibility(View.INVISIBLE);
        pages.put(sid, p);
        return p;
    }

    void open(String sid, String url, String user, String pass) {
        Page p = pages.get(sid);
        if (p == null) p = create(sid);
        p.user = user == null ? "" : user;
        p.pass = pass == null ? "" : pass;
        p.authTries = 0;
        p.web.loadUrl(url);
    }

    void eval(final int id, String sid, String js) {
        Page p = pages.get(sid);
        if (p == null) {
            events.onEvalResult(id, null);
            return;
        }
        p.web.evaluateJavascript(js, value -> events.onEvalResult(id, value));
    }

    boolean show(String sid, boolean visible, String title) {
        Page p = pages.get(sid);
        if (p == null) return false;
        p.visible = visible;
        if (visible) {
            if (title != null) p.title.setText(title);
            p.frame.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            p.frame.setVisibility(View.VISIBLE);
            p.frame.bringToFront();
            p.web.requestFocus();
        } else {
            p.frame.setVisibility(View.INVISIBLE);
            p.frame.setLayoutParams(new FrameLayout.LayoutParams(1280, 900));
            root.removeView(p.frame);
            root.addView(p.frame, 0);
            emit(sid, "hidden", null, null);
        }
        return true;
    }

    /** Page affichée en plein écran (pour la touche Retour) */
    String visibleSid() {
        for (Page p : pages.values()) if (p.visible) return p.sid;
        return null;
    }

    boolean goBack(String sid) {
        Page p = pages.get(sid);
        if (p != null && p.web.canGoBack()) {
            p.web.goBack();
            return true;
        }
        return false;
    }

    void close(String sid) {
        Page p = pages.remove(sid);
        if (p == null) return;
        root.removeView(p.frame);
        p.web.stopLoading();
        p.web.destroy();
    }

    void destroy() {
        for (String sid : pages.keySet().toArray(new String[0])) close(sid);
    }
}
