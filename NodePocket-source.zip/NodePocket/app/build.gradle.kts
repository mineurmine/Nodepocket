plugins {
    id("com.android.application")
}

// Numéro de version = numéro de compilation GitHub (1 en local)
val buildNumber = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()

android {
    namespace = "fr.nodepocket"
    compileSdk = 35

    defaultConfig {
        applicationId = "fr.nodepocket"
        minSdk = 26
        targetSdk = 35
        versionCode = buildNumber
        versionName = "1.0.$buildNumber"
    }

    // Clé de signature fixe : permet d'installer les nouvelles versions par-dessus les anciennes
    signingConfigs {
        create("perso") {
            storeFile = file("signing/nodepocket.jks")
            storePassword = "nodepocket"
            keyAlias = "nodepocket"
            keyPassword = "nodepocket"
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("perso")
        }
        getByName("debug") {
            signingConfig = signingConfigs.getByName("perso")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}
